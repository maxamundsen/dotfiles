;; 2021-08-23

(defvar xahemacs-major-mode-leader-key nil "Global leader key for major modes. Value should be what `kbd' returns.")
(setq xahemacs-major-mode-leader-key (kbd "<f9>"))

