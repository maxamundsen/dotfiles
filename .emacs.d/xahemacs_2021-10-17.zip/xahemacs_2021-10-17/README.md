# What is XahEmacs Distro

A simple emacs config set, with a minimal bundled packages.

The salient feature is most efficient key operation, fastest, pure functionality (by science, not by hacker pref), no user interface prettification (unless it proves to be functional superior), and max use of builtin emacs features, minimal external packages.

Main thing is: xah fly keys. Read this to learn:
Emacs: Xah Fly Keys http://ergoemacs.org/misc/ergoemacs_vi_mode.html

then, all bundled major mode has a default leader key F9.

# Requirement

Requires emacs 26.

# Intallation instruction

create a file name at

~/.emacs.d/init.el

in that file, put this line:

(load-file "full_path_to_XahEamcs_dir/xahemacs_init.el")

Your own elisp code can come before or after this line.
