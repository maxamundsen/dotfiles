;; -*- coding: utf-8; lexical-binding: t; -*-

(when (< emacs-major-version 27) (package-initialize))

(require 'ido)

;; HHH___________________________________________________________________
; loading custom commands and functions

(defun xah-get-fullpath (RelativePath)
  "Return the full path of RelativePath, relative to caller's file location.
Version 2017-07-19 2021-07-17"
  (concat (file-name-directory (or load-file-name buffer-file-name)) RelativePath))

;; HHH___________________________________________________________________

(load (xah-get-fullpath "xahemacs_settings"))

(load (xah-get-fullpath "xahemacs_keys"))

;; HHH___________________________________________________________________

(add-to-list 'load-path (xah-get-fullpath ""))
(add-to-list 'load-path (xah-get-fullpath "packages/" ))

;; HHH___________________________________________________________________

(require 'xah-get-thing)
(require 'xah-replace-pairs)
;; (require 'xeu_elisp_util)
(require 'smex)

(progn
  (require 'xah-fly-keys)
  (xah-fly-keys-set-layout "qwerty")
  (xah-fly-keys 1))

(require 'xah-elisp-mode)
(require 'xah-insert-random-id)
(require 'xah-css-mode)

(progn
  (require 'htmlize)
  (setq htmlize-convert-nonascii-to-entities nil)
  (setq htmlize-html-charset "utf-8")
  (setq htmlize-untabify nil)
  (setq htmlize-generate-hyperlinks nil))

(require 'xah-html-mode)
(require 'xah-js-mode)
(require 'xah-find)
(require 'xah-dired)
(require 'xah-lookup)
(require 'xah-math-input)
(require 'xah-powershell-mode)
(require 'xah-wolfram-mode)

(global-xah-math-input-mode 1)
