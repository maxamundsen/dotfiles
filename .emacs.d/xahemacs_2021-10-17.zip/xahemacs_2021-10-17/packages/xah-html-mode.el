;;; xah-html-mode.el --- Major mode for editing html. -*- coding: utf-8; lexical-binding: t; -*-

;; Copyright © 2013-2021, by Xah Lee

;; Author: Xah Lee ( http://xahlee.info/ )
;; Version: 16.6.20211008001737
;; Created: 12 May 2012
;; Package-Requires: ((emacs "26.1"))
;; Keywords: languages, html, web
;; License: GPL v3
;; Homepage: http://ergoemacs.org/emacs/xah-html-mode.html

;; This file is not part of GNU Emacs.

;;; Commentary:
;; Major mode for editing HTML files.
;; home page: http://ergoemacs.org/emacs/xah-html-mode.html

;; part of emacs
(require 'ido)
(require 'sgml-mode)
(require 'newcomment)
(require 'browse-url)
(require 'url-util)
(require 'thingatpt)
(require 'seq)
(require 'subr-x)

(require 'xah-replace-pairs)
(require 'xah-get-thing)
(require 'xah-css-mode)
(require 'htmlize)

(defvar xah-html-mode-hook nil "Standard hook for `xah-html-mode'")

;; HHH___________________________________________________________________

(defvar xah-html-tag-names nil
  "A alist of HTML5 tag names.
For each element, the key is tag name, value is a vector of one element of string:
c means character.
w means word.
l means line.
b means block.
s means self-closing tag such as br.
Others are placeholder for unknown. The purpose of the value is to indicate the default way to wrap the tag around cursor. "
; todo: need to go the the list and look at the type carefully. Right now it's just quickly done. lots are “z”, for unkown. Also, some are self closing tags, current has mark of “n”.
)

(setq
 xah-html-tag-names
 '(("a" . ["l"])
   ("abbr" . ["w"])
   ("address" . ["w"])
   ("applet" . ["l"])
   ("area" . ["l"])
   ("article" . ["b"])
   ("aside" . ["b"])
   ("audio" . ["l"])
   ("b" . ["w"])
   ("base" . ["l"])
   ("basefont" . ["l"])
   ("bdi" . ["w"])
   ("bdo" . ["w"])
   ("blockquote" . ["b"])
   ("body" . ["b"])
   ("br" . ["s"])
   ("button" . ["w"])
   ("canvas" . ["b"])
   ("caption" . ["l"])
   ("cite" . ["l"])
   ("code" . ["l"])
   ("col" . ["n"])
   ("colgroup" . ["l"])
   ("command" . ["z"])
   ("datalist" . ["z"])
   ("dd" . ["z"])
   ("del" . ["z"])
   ("details" . ["z"])
   ("dfn" . ["z"])
   ("div" . ["b"])
   ("dl" . ["b"])
   ("dt" . ["l"])
   ("em" . ["w"])
   ("embed" . ["l"])
   ("fieldset" . ["z"])
   ("figcaption" . ["l"])
   ("figure" . ["b"])
   ("footer" . ["b"])
   ("form" . ["l"])
   ("h1" . ["l"])
   ("h2" . ["l"])
   ("h3" . ["l"])
   ("h4" . ["l"])
   ("h5" . ["l"])
   ("h6" . ["l"])
   ("head" . ["b"])
   ("header" . ["b"])
   ("hr" . ["s"])
   ("html" . ["b"])
   ("i" . ["w"])
   ("iframe" . ["z"])
   ("img" . ["l"])
   ("input" . ["l"])
   ("ins" . ["z"])
   ("kbd" . ["c"])
   ("keygen" . ["z"])
   ("label" . ["z"])
   ("legend" . ["z"])
   ("li" . ["l"])
   ("link" . ["z"])
   ("main" . ["b"])
   ("map" . ["z"])
   ("mark" . ["w"])
   ("marquee" . ["l"])
   ("menu" . ["z"])
   ("menuitem" . ["z"])
   ("meta" . ["z"])
   ("meter" . ["z"])
   ("nav" . ["b"])
   ("noscript" . ["l"])
   ("object" . ["z"])
   ("ol" . ["b"])
   ("optgroup" . ["z"])
   ("option" . ["z"])
   ("output" . ["z"])
   ("p" . ["b"])
   ("param" . ["z"])
   ("picture" . ["z"])
   ("pre" . ["b"])
   ("progress" . ["z"])
   ("q" . ["w"])
   ("rp" . ["l"])
   ("rt" . ["w"])
   ("ruby" . ["l"])
   ("s" . ["w"])
   ("samp" . ["z"])
   ("script" . ["b"])
   ("section" . ["b"])
   ("select" . ["z"])
   ("small" . ["w"])
   ("source" . ["z"])
   ("span" . ["w"])
   ("strong" . ["w"])
   ("style" . ["b"])
   ("sub" . ["c"])
   ("summary" . ["z"])
   ("sup" . ["c"])
   ("table" . ["b"])
   ("tbody" . ["z"])
   ("td" . ["l"])
   ("textarea" . ["z"])
   ("tfoot" . ["z"])
   ("th" . ["z"])
   ("thead" . ["z"])
   ("time" . ["w"])
   ("title" . ["l"])
   ("tr" . ["b"])
   ("track" . ["b"])
   ("u" . ["w"])
   ("ul" . ["b"])
   ("var" . ["w"])
   ("video" . ["l"])
   ("wbr" . ["z"])))

(defvar xah-html-tag-list nil "Keys of `xah-html-tag-names'.")
(setq xah-html-tag-list (mapcar (lambda (x) (car x)) xah-html-tag-names))

(defvar xah-html-svg-tag-names nil "A alist of svg tag names. For each element, the key is tag name, value is ignored." )
(setq
 xah-html-svg-tag-names
 '(("circle" . 2)
   ("defs" . 2)
   ("ellipse" . 2)
   ("g" . 2)
   ("line" . 2)
   ("path" . 2)
   ("polygon" . 2)
   ("rect" . 2)
   ("svg" . 2)
   ("text" . 2)
   ("use" . 2)))

(defvar xah-html-svg-tag-list nil "Keys of `xah-html-svg-tag-names'")
(setq xah-html-svg-tag-list (mapcar (lambda (x) (car x)) xah-html-svg-tag-names))

(defvar xah-html-attribute-names nil "HTML attribute names." )
(setq xah-html-attribute-names '(
"action"
"alt"
"charset"
"class"
"cols"
"content"
"enctype"
"for"
"height"
"href"
"http-equiv"
"id"
"lang"
"list"
"max"
"maxlength"
"media"
"method"
"min"
"name"
"poster"
"preload"
"rel"
"rows"
"size"
"src"
"srcset"
"step"
"style"
"target"
"title"
"type"
"value"
"width"
))

(defvar xah-html-boolean-attribute-names nil "HTML boolean attribute names." )
(setq xah-html-boolean-attribute-names '(
"async"
"autoplay"
"checked"
"controls"
"defer"
"loop"
"multiple"
"selected"
))

(defvar xah-html-selfclose-tags nil "List of HTML5 self-closing tag name. " )
(setq xah-html-selfclose-tags '(
"area"
"base"
"br"
"col"
"command"
"embed"
"hr"
"img"
"input"
"keygen"
"link"
"meta"
"param"
"source"
"track"
"wbr"
"!doctype"
))
;; todo. fix the !doctype. it's not exactly a selfclose tag.

;; HHH___________________________________________________________________

(defvar xah-html-webroot-list nil "A list of web root full paths.
This is used by `xah-html-get-webroot'.")

(defun xah-html-get-webroot (Path)
  "Return the webroot of Path.
Webroot dir are defined in `xah-html-webroot-list'.
Version 2018-05-08"
  (interactive)
  (seq-find
   (lambda (x)
     (string-match
      (concat "^" x)
      Path ))
   xah-html-webroot-list
   nil
   ))

(defun xah-html-local-link-p (HrefVal)
  "Return true if it's likely a local file link, else false.
None local link may start with these:
 http://
 https://
 mailto:
 irc:
 ftp:
 javascript:
 //
Version 2020-07-16 2021-08-11"
  (cond
   ((> (length HrefVal) 250) nil)
   ((eq (length HrefVal) 0) nil)
   ((string-match "[ ,<>]" HrefVal ) nil)
   ((string-match "^//" HrefVal) nil)
   ((string-match "^http://" HrefVal) nil)
   ((string-match "^https://" HrefVal) nil)
   ((string-match "^mailto:" HrefVal) nil)
   ((string-match "^irc:" HrefVal) nil)
   ((string-match "^ftp:" HrefVal) nil)
   ((string-match "^javascript:" HrefVal) nil)
   (t t)))

(defun xah-html-local-url-to-file-path (LocalFileUrl)
  "Turn a localhost file URL such as file:///C:/Users/xah/cat.html to file path.
LocalFileUrl must be a full path.

basically, remove the prefix of
file:///
file://localhost
file://

For example, the following string shown in browser URL field:
; On Windows Vista 2009-06
 [C:\\Users\\jj\\index.html]  IE
 [file:///C:/Users/jj/index.html]  Firefox, Google Chrome, Safari
 [file://localhost/C:/Users/jj/index.html]  Opera
 becomes
 [C:/Users/jj/index.html]

 On Mac 2009-06
 [file:///Users/jj/index.html]  Safari, Firefox
 [file://localhost/Users/jj/index.html]  Opera
 becomes
 [/Users/jj/index.html]

 On Ubuntu Linux, 2011-05
 [file:///media/HP/Users/jj/index.html] firefox
 becomes
 [/media/HP/Users/jj/index.html]
Version 2009-06-01 2021-01-12"
  (let ((case-fold-search nil))
    (xah-replace-regexp-pairs-in-string
     LocalFileUrl
     [
      ["\\`file://localhost" ""]
      ["\\`file://" ""]
      ["\\`/\\([A-Za-z]\\):" "\\1:"] ; Windows C:\\
      ["\\`C:" "c:"] ; need because a bug in `file-relative-name', it doesn't work when path C: is cap
      ["\\\\" "/"]   ; Windows \ → /
      ]
     t
     )))

(defun xah-html-get-relative-path-to-webroot (Path)
  "Return the relative path of Path with respect to its webroot.
 Path should be full path here.
Webroot dir are defined in `xah-html-webroot-list'.
If Path is not there, return relative path to parent dir.
Version 2018-05-08"
  (interactive)
  (let (($webroot (xah-html-get-webroot Path))
        ($currentDir (file-name-directory (or (buffer-file-name) default-directory))))
    (if $webroot
        (concat (file-relative-name $webroot $currentDir)
                (file-relative-name Path $webroot))
      (file-relative-name Path $currentDir))))

(defun xah-html-display-hr-as-line ()
  "Display hr tag as a line.
Version 2020-09-05 2021-08-11 2021-09-10"
  (interactive)
  (let ($p1 $p2 ($buffModifiedQ (buffer-modified-p)))
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward "<hr>\\|<hr */>" nil t)
        (setq $p1 (match-beginning 0) $p2 (match-end 0))
        (put-text-property
         $p1 $p2 'display
         (format "%s%s" (match-string-no-properties 0) "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"))))
    (set-buffer-modified-p $buffModifiedQ)))

;; HHH___________________________________________________________________

;; naming convention (nomenclature, jargon, terminology)
;; tagBegin: ▮<p> or ▮</p> or ▮<!-- or ▮<!doctype
;; openingTagBegin: ▮<p>
;; openingTagEnd: <p>▮
;; closingTagBegin: ▮</p>
;; closingTagEnd: </p>▮

;; ob → OpeningBegin
;; oe → OpeningEnd
;; cb → ClosingBegin
;; ce → ClosingEnd

;; Self closing tags are img br hr etc. They may have a slash <br /> with or without space before slash

(defun xah-html-skip-tag-forward ()
  "Move cursor to the closing tag.
Version 2021-08-30"
  (sgml-skip-tag-forward 1))

(defun xah-html-skip-tag-backward ()
  "Move cursor to the beginning tag.
Version 2021-08-30"
  (sgml-skip-tag-backward 1))

(defun xah-html--goto-prev-tag-begin (&optional Bound NoError)
  "Move cursor to the begin tag: ▮< and make sure it's a open/closing tag or comment or doctype, is not just a less than sign that's not escaped to entity. Return its position.
This code make sure, to some degree, the result position's < is not just unencoded entity, legal in html5.
Version 2021-09-25"
  (if (search-backward "<" Bound NoError)
      (if (looking-at "<\\([A-Za-z]\\|/[A-Za-z]\\|!--\\)")
          (point)
        (xah-html--goto-prev-tag-begin Bound NoError))
    nil
    ))

(defun xah-html--goto-closing-tag-end (TagBegin)
  "Move cursor to the end of matching closing tag: </x>▮. Return its position.
TagBegin must be on the left of begin tag: ▮<x…>.
Version 2021-08-30 2021-09-06"
  (goto-char TagBegin)
  (when (not (eq (char-after ) ?<)) (error "TagBegin not on left of <."))
  (forward-char )
  (xah-html-skip-tag-forward)
  (point))

(defun xah-html--goto-closing-tag-begin (TagBegin)
  "Move cursor to the begin of matching closing tag: ▮</x>. Return its position.
TagBegin must be on the left of begin tag: ▮<x…>.
Version 2021-08-21"
  (xah-html--goto-closing-tag-end TagBegin)
  (search-backward "<"))

(defun xah-html--goto-matching-tag (TagBegin)
  "Move cursor to the begin opening tag or end closing, of matching tag.
TagBegin must be on the left of angle bracket: ▮< .
Result cursor position is on left of tag: ▮<name…>.
For self-closing tag, do nothig.
Version 2021-08-16 2021-08-22"
  (when (not (eq (char-after ) ?<)) (error "Cursor not on left of <." ))
  (if (xah-html--opening-tag-p (point))
      (if (xah-html--tag-self-closing-p (xah-html--get-tag-name (point)))
          TagBegin
        (progn
          (forward-char )
          (xah-html-skip-tag-forward)))
    (progn
      (forward-char )
      (xah-html-skip-tag-backward))))

(defun xah-html--doctype-tag-p (TagBegin)
  "Return t if tag is a doctype tag ▮<!doctype, else nil.
TagBegin must be on the left of angle bracket: ▮< .
Version 2021-09-01"
  (when (not (char-equal (char-after TagBegin) ?<)) (error "TagBegin not on the left of <" ))
  (let ( (case-fold-search nil))
    (save-excursion
      (goto-char TagBegin)
      (looking-at "<!doctype"))))

(defun xah-html--comment-tag-p (TagBegin)
  "Return t if tag is a comment tag ▮<!--, else nil.
TagBegin must be on the left of angle bracket: ▮< .
Version 2021-09-01"
  (when (not (char-equal (char-after TagBegin) ?<)) (error "TagBegin not on the left of <" ))
  (save-excursion
    (goto-char TagBegin)
    (looking-at "<!--")))

(defun xah-html--opening-tag-p (TagBegin)
  "Return t if tag is opening tag or self closing, else nil.
TagBegin must be on the left of angle bracket: ▮< , can be opening or closing tag.
Version 2021-06-22 2021-08-16 2021-08-30"
  (when (not (char-equal (char-after TagBegin) ?<)) (error "TagBegin not on the left of <" ))
  (not (char-equal (char-after (1+ TagBegin)) ?/)))

(defun xah-html--get-tag-name (TagBegin)
  "Return the tag name.
TagBegin must be on the left of angle bracket: ▮< , can be opening or closing tag.
The function returns the element name immediately to the right.
Version 2021-06-22 2021-09-10"
  (when (not (char-equal (char-after TagBegin) ?<)) (error "TagBegin not on the left of <"))
  (save-excursion
    (let ($p1 $p2)
      (goto-char TagBegin)
      (forward-char 1)
      (when (looking-at "/") (forward-char 1))
      (setq $p1 (point))
      (skip-chars-forward "A-Za-z")
      (setq $p2 (point))
      (buffer-substring-no-properties $p1 $p2))))

(defun xah-html--tag-self-closing-p (TagName)
  "Return t if the tag is a self-closing tag such as img, hr, br."
  (member TagName xah-html-selfclose-tags))

(defun xah-html--get-attribute (Attr OpeningTagBegin &optional OpeningTagEnd)
  "Return the attribute Attr value.
OpeningTagBegin must on the begin position of a opening tag: ▮<name …>.
OpeningTagEnd must be: <name …>▮.

This function does not work for boolean attributes. It must have the form name=\"…\".
If no Attr found, return nil.
Version 2021-08-25"
  (save-excursion
    (goto-char OpeningTagBegin)
    (when (not (eq (char-after) ?<)) (error "Cursor not on left of <."))
    (let (($tagEndPos (if OpeningTagEnd OpeningTagEnd (search-forward ">"))))
      (goto-char OpeningTagBegin)
      (if (re-search-forward (concat Attr " *= *\"\\([^\"]+\\)\"") $tagEndPos)
          (match-string-no-properties 1)
        (if (re-search-forward (concat Attr " *= *'\\([^']+\\)'") $tagEndPos)
            (match-string-no-properties 1)
          nil)))))

(defun xah-html--get-innertext-bounds (OpeningTagBegin)
  "Return (cons innerTextBeginPos innerTextEndPos).
OpeningTagBegin must be on the left of begin tag: ▮<name…>.

Version 2021-08-16 2021-08-21"
  (save-excursion
    (let ($p1
          ($p2 (xah-html--goto-closing-tag-begin OpeningTagBegin)))
      (setq $p1 (progn (goto-char OpeningTagBegin) (search-forward ">" )))
      (cons $p1 $p2))))

(defun xah-html--cursor-in-tag-p (Pos)
  "Return t if Pos is between angle brackets <…▮…>.
Version 2021-09-01"
  (save-excursion
    (let (($p0 Pos) $prevL $prevR $nextL $nextR)
      (progn
        (goto-char $p0)
        (setq $prevL (if (search-backward "<" nil t) (point) nil))
        (goto-char $p0)
        (setq $prevR (if (search-backward ">" nil t) (point) nil)))
      (if (and $prevL $prevR)
          (not (< $prevL $prevR))
        (progn
          (goto-char $p0)
          (setq $nextL (if (search-forward "<" nil t) (point) nil))
          (goto-char $p0)
          (setq $nextR (if (search-forward ">" nil t) (point) nil))
          (if (and $nextL $nextR)
              (not (< $prevL $prevR))))))))

(defun xah-html--cursor-in-link-p ()
  "Return true if curser is inside a string of src or href.
Version 2020-01-15 2021-08-17"
  (let (($inStringQ (nth 3 (syntax-ppss))))
    (if $inStringQ
        (save-excursion
          (skip-chars-backward "^\"")
          (backward-char)
          (if (char-equal (char-before) ?=)
              (progn
                (backward-char 1)
                (if (or
                     (string-match "href" (current-word))
                     (string-match "src" (current-word))
                     (string-match "poster" (current-word))
                     (string-match "content" (current-word)))
                    (progn t)
                  (progn nil)))
            nil))
      nil
      )))

(defun xah-html--get-youtube-id (Url)
  "Return the ID string inside a YouTube Url string.
If not found, error.
YouTube ID looks like this: gjiAjtGzC64
URL variations:
https://www.youtube.com/watch?v=gjiAjtGzC64
https://youtu.be/gjiAjtGzC64
https://www.youtube.com/embed/gjiAjtGzC64

Version 2020-08-27 2021-07-31 2021-08-24"
  (cond
   ((eq 11 (length Url))
    Url)
   ((string-match "v=\\(.\\{11\\}\\)" Url)
    (match-string-no-properties 1 Url))
   ((string-match "youtu\\.be/\\(.\\{11\\}\\)" Url)
    (match-string-no-properties 1 Url))
   ((string-match "youtube.com/embed/\\(.\\{11\\}\\)" Url)
    (match-string-no-properties 1 Url))
   (t (error "YouTube video ID cannot be found in: %s" Url))))

(defun xah-html--get-youtube-timestamp (Url)
  "Return the timestamp parameter value in YouTube Url string.
Return a string, or nil.
The timestamp in YouTube url is like these:
?start=2358
?t=2358
Version 2021-08-25"
  (cond
   ((string-match "\\?start=\\([0-9]+\\)" Url )
    (match-string-no-properties 1 Url))
   ((string-match "\\?t=\\([0-9]+\\)" Url )
    (match-string-no-properties 1 Url))
   (t nil)))

(defun xah-html--youtube-id-to-url (Id &optional TimeStampSecs)
  "Return a YouTube url from Id string.
Return in this format:
https://youtu.be/gjiAjtGzC64?t=2358
This format is the result when you copy link via YouTube site user interface.
Normal YouTube url is in this format:
https://www.youtube.com/watch?v=gjiAjtGzC64

Version 2021-08-24 2021-08-25"
  (concat "https://youtu.be/" Id (if TimeStampSecs (format "?t=%s" TimeStampSecs ) "" )))

(defun xah-html--iframe-to-text (ElBegin ElEnd)
  "Change <iframe …>…</iframe> to its src text.
For example
<iframe width=\"640\" height=\"480\" src=\"xyz\" allowfullscreen></iframe>
becomes xyz
If the src value is a YouTube embed url, it'll be changed to standard YouTube url. For example:
https://www.youtube.com/embed/Q_LcL2ond4I?start=1080
becomes
https://youtu.be/Q_LcL2ond4I?t=1080

Version 2021-08-24 2021-08-25"
  (goto-char ElBegin)
  (re-search-forward "src=\"\\([^\"]+?\\)\"" ElEnd)
  (let ( ($srcVal (match-string-no-properties 1)))
    (delete-region ElBegin ElEnd )
    (insert (if (string-match "com/embed/" $srcVal )
                (xah-html--youtube-id-to-url
                 (xah-html--get-youtube-id $srcVal)
                 (xah-html--get-youtube-timestamp $srcVal))
              $srcVal))))

(defun xah-html--img-to-text (Ob &optional Oe)
  "Change <img …> to its src string.
Version 2020-12-02 2021-05-16 2021-08-26"
  (let ( $srcVal )
    (when (not Oe)
      (goto-char Ob) (setq Oe (search-forward ">" )))
    (goto-char Ob)
    (re-search-forward "src=\"\\([^\"]*?\\)\"" Oe)
    (setq $srcVal (match-string-no-properties 1))
    (delete-region Ob Oe)
    (goto-char Ob)
    (insert (format "[%s]" $srcVal))))

(defun xah-html--link-to-text (Ob &optional Oe Cb Ce)
  "Change link <a …>…</a> to text in region.
Result has this format [link text]( URL )
or
( URL )

Version 2020-12-02 2021-08-31 2021-10-13"
  (progn
    (let ($innerText $hrefVal)
      (when (not Oe) (goto-char Ob) (setq Oe (search-forward ">")))
      (when (not Cb)
        (goto-char Oe)
        (search-forward "</a>")
        (setq Cb (match-beginning 0) Ce (match-end 0)))
      (setq $innerText (buffer-substring-no-properties Oe Cb))
      (goto-char Ob)
      (re-search-forward "href=\"\\([^\"]*?\\)\"" Oe)
      (setq $hrefVal (match-string-no-properties 1))
      (delete-region Ob Ce)
      (goto-char Ob)
      (insert (if (string-equal $hrefVal $innerText)
                  (format "( %s )" $hrefVal)
                (format "[%s] ( %s )" $innerText $hrefVal))))))

;; HHH___________________________________________________________________

(defun xah-html-encode-ampersand-region (Begin End)
  "Replace chars & < > to named entities in region.

URL `http://ergoemacs.org/emacs/elisp_replace_html_entities_command.html'
Version 2018-10-08 2021-08-26"
  (interactive "r")
  (xah-replace-pairs-region Begin End '( ["&" "&amp;"] ["<" "&lt;"] [">" "&gt;"] )))

(defun xah-html-decode-ampersand-region (Begin End)
  "Replace entities &amp; &lt; &gt; to chars in region.

URL `http://ergoemacs.org/emacs/elisp_replace_html_entities_command.html'
Version 2018-10-08 2021-08-26"
  (interactive "r")
  (xah-replace-pairs-region Begin End '( ["&lt;" "<"] ["&gt;" ">"] ["&amp;" "&"])))

;; HHH___________________________________________________________________

(defun xah-html-select-element ()
  "Select previous element before cursor.
Repeated call will extend selection to previous element, possibly parent.
After this command is called, press space to repeat it.

URL `http://ergoemacs.org/emacs/emacs_html_select_current_element.html'
Version 2021-06-19 2021-08-08 2021-08-22 2021-08-30"
  (interactive)
  (let ($p1 $p2 $tagPos1 $tagPos4)
    (if (eq this-command last-command)
        (progn
          (setq $p1 (region-beginning) $p2 (region-end))
          (goto-char $p1)
          (setq $tagPos1 (re-search-backward "<[a-z0-9]+\\|</[a-z0-9]+" nil t))
          (if (xah-html--tag-self-closing-p (xah-html--get-tag-name $tagPos1))
              (progn
                (push-mark $tagPos1 t t)
                (goto-char $p2))
            (progn
              (if (xah-html--opening-tag-p $tagPos1)
                  (progn
                    (goto-char (1+ $tagPos1))
                    (xah-html-skip-tag-forward)
                    (search-backward "<" nil t)
                    (search-forward ">" nil t)
                    (setq $tagPos4 (point))
                    (push-mark $tagPos1 t t)
                    (goto-char $tagPos4))
                (progn
                  (goto-char (1+ $tagPos1))
                  (xah-html-skip-tag-backward)
                  (push-mark (point) t t)
                  (goto-char $p2))))))
      (progn
        (setq $p1 (re-search-backward "<[a-z0-9]+\\|</[a-z0-9]+"))
        (setq $p2 (search-forward ">"))
        (if (xah-html--tag-self-closing-p (xah-html--get-tag-name $p1))
            (progn
              (push-mark $p2 t t)
              (goto-char $p1))
          (if (xah-html--opening-tag-p $p1)
              (progn
                (goto-char (1+ $p1))
                (xah-html-skip-tag-forward)
                (push-mark $p1 t t))
            (progn
              (goto-char (1+ $p1))
              (xah-html-skip-tag-backward)
              (push-mark (point) t t)
              (goto-char $p2)))))))
  (set-transient-map (let (($kmap (make-sparse-keymap))) (define-key $kmap (kbd "SPC") 'xah-html-select-element) $kmap)))

(defun xah-html-delete-tag-pair ()
  "Remove the previous tag(s) under cursor.
The tags removed is the first angle bracketed tag to the left of cursor. Both begin and end tags are removed, or the whole tag such as self-closing tag img hr br or comment <!-- xyz --> or <!doctype html>.

After this command is called, press space to repeat it.

URL `http://ergoemacs.org/emacs/emacs_html_delete_tags.html'
Version 2021-01-03 2021-08-24 2021-09-01 2021-09-10"
  (interactive)
  (let* (($p1 (xah-html--goto-prev-tag-begin))
         ($p2 (search-forward ">"))
         $inOpeningTagQ $ob $oe $isSelfCloseTag $cb $ce )
    (cond
     ((xah-html--comment-tag-p $p1) (delete-region (goto-char $p1) (search-forward "-->" )))
     ((xah-html--doctype-tag-p $p1) (delete-region (goto-char $p1) (search-forward ">" )))
     (t (progn
          (setq $inOpeningTagQ (xah-html--opening-tag-p $p1))
          (if $inOpeningTagQ
              (progn
                (setq $ob $p1 $oe $p2)
                (setq $isSelfCloseTag (xah-html--tag-self-closing-p (xah-html--get-tag-name $ob)))
                (if $isSelfCloseTag
                    nil
                  (progn
                    (setq $ce (xah-html--goto-closing-tag-end $ob))
                    (setq $cb (search-backward "<" )))))
            (progn
              (setq $cb $p1 $ce $p2)
              (goto-char (1+ $cb))
              (xah-html-skip-tag-backward)
              (setq $ob (point))
              (setq $oe (search-forward ">" ))))
          (let (($tagName (xah-html--get-tag-name $ob)))
            (goto-char $p2)
            (cond
             ((string-equal $tagName "a") (xah-html--link-to-text $ob $oe $cb $ce))
             ((string-equal $tagName "img") (xah-html--img-to-text $ob $oe ))
             ((string-equal $tagName "iframe") (xah-html--iframe-to-text $ob $ce))
             (t (progn
                  (when (not $isSelfCloseTag) (delete-region $cb $ce))
                  (delete-region $ob $oe)))))))))
  (set-transient-map (let (($kmap (make-sparse-keymap))) (define-key $kmap (kbd "SPC") 'xah-html-delete-tag-pair ) $kmap)))

;; HHH___________________________________________________________________

(defun xah-html--datetimestamp-p (Str)
  "Return t if Str is a date/time stamp, else nil.
This is based on heuristic, so it's not 100% correct.
If the string contains any month names, weekday names, or of the form dddd-dd-dd, dddd-dd-dddd, dddd-dd-dd, or using slash, then it's considered a date.

2015-09-27 issue: if a sentence “You May Do So”, it's be thought as date. Similar for containing word “March”.
Version 2017-11-22"
  (let* ((case-fold-search t)
         ($monthNames '( "January" "February" "March" "April" "May" "June" "July" "August" "September" "October" "November" "December"))
         ($monthAbbrevs (mapcar (lambda (x) (substring x 0 3)) $monthNames))
         ($weekDayNames '("Monday" "Tuesday" "Wednesday" "Thursday" "Friday" "Saturday" "Sunday"))
         ($words '(" a " " is " " that" " have" "with" " you"  )))
    (cond
     ((> (length Str) 37) nil)
     ((string-match (regexp-opt $words 'words) Str) nil))
    (cond
     ((string-match (regexp-opt (append $monthNames $monthAbbrevs $weekDayNames) 'words) Str) t)
     ;; mm/dd/yyyy
     ((string-match "\\b[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]\\b" Str) t)
     ;; yyyy/mm/dd
     ((string-match "\\b[0-9][0-9][0-9][0-9]/[0-9][0-9]/[0-9][0-9]\\b" Str) t)
     ;; mm/dd/yy
     ((string-match "\\b[0-9][0-9]/[0-9][0-9]/[0-9][0-9]\\b" Str) t)
     ;; mm-dd-yyyy
     ((string-match "\\b[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]\\b" Str) t)
     ;; yyyy-mm-dd
     ((string-match "\\b[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]\\b" Str) t)
     ;; mm-dd-yy
     ((string-match "\\b[0-9][0-9]-[0-9][0-9]-[0-9][0-9]\\b" Str) t)
     ((string-match "\\b[0-9][0-9][0-9][0-9]\\b" Str) t)
     (t nil))))

;; HHH___________________________________________________________________

(defun xah-html--get-tag-type (TagName)
  "Return the wrap-type info of TagName in `xah-html-tag-names'
Version 2018-11-02"
  (elt (cdr (assoc TagName xah-html-tag-names) ) 0))

(defvar xah-html-langcode-map nil "A alist that maps lang name. Each element has this form
 (‹lang code› . [‹emacs major mode name› ‹file extension›])
For example:
 (\"emacs-lisp\" . [\"xah-elisp-mode\" \"el\"])
Version 2019-04-08
")

(setq
 xah-html-langcode-map
 '(("WolframLang" . ["xah-wolfram-mode" "m"])
   ("ahk" . ["ahk-mode" "ahk"])
   ("apl" . ["gnu-apl-mode" "apl"])
   ("bash" . ["sh-mode" "sh"])
   ("shell" . ["sh-mode" "sh"])
   ("bbcode" . ["xbbcode-mode" "bbcode"])
   ("c" . ["c-mode" "c"])
   ("clojure" . ["xah-clojure-mode" "clj"])
   ("cmd" . ["dos-mode" "bat"])
   ("code" . ["fundamental-mode" "txt"])
   ("common-lisp" . ["lisp-mode" "lisp"])
   ("cpp" . ["c++-mode" "cpp"])
   ("csharp" . ["csharp-mode" "cs"])
   ("css" . ["xah-css-mode" "css"])
   ("dart" . ["dart-mode" "dart"])
   ("emacs-lisp" . ["xah-elisp-mode" "el"])
   ("erlang" . ["erlang-mode" "erl"])
   ("golang" . ["go-mode" "go"])
   ("haml" . ["haml-mode" "haml"])
   ("haskell" . ["haskell-mode" "hs"])
   ("html" . ["xah-html-mode" "html"])
   ("html6" . ["xah-html6-mode" "html6"])
   ("java" . ["java-mode" "java"])
   ("js" . ["xah-js-mode" "js"])
   ("latex" . ["latex-mode" "txt"])
   ("lsl" . ["xlsl-mode" "lsl"])
   ("lyrics_xl" . ["text-mode" "txt"])
   ("markdown" . ["markdown-mode" "md"])
   ("math" . ["fundamental-mode" "txt"])
   ("mysql" . ["sql-mode" "sql"])
   ("nodejs" . ["xah-js-mode" "js"])
   ("ocaml" . ["tuareg-mode" "ml"])
   ("org-mode" . ["org-mode" "org"])
   ("output" . ["fundamental-mode" "txt"])
   ("perl" . ["cperl-mode" "pl"])
   ("php" . ["xah-php-mode" "php"])
   ("poem_xl" . ["text-mode" "txt"])
   ("povray" . ["pov-mode" "pov"])
   ("powershell" . ["xah-powershell-mode" "ps1"])
   ("prolog" . ["prolog-mode" "prolog"])
   ("python" . ["python-mode" "py"])
   ("python3" . ["python-mode" "py3"])
   ("qi" . ["shen-mode" "qi"])
   ("racket" . ["racket-mode" "rkt"])
   ("ruby" . ["ruby-mode" "rb"])
   ("sass" . ["sass-mode" "sass"])
   ("scala" . ["scala-mode" "scala"])
   ("scheme" . ["scheme-mode" "scm"])
   ("scss" . ["xah-css-mode" "css"])
   ("slim" . ["slim-mode" "slim"])
   ("text" . ["text-mode" "txt"])
   ("typescript" . ["xah-js-mode" "ts"])
   ("unix-config" . ["conf-space-mode" "conf"])
   ("vbs" . ["visual-basic-mode" "vbs"])
   ("vimrc" . ["vimrc-mode" "vim"])
   ("visualbasic" . ["visual-basic-mode" "vbs"])
   ("xml" . ["sgml-mode" "xml"])
   ("yaml" . ["yaml-mode" "yaml"])
   ("yasnippet" . ["snippet-mode" "yasnippet"])
   ;;
   ))

(defvar xah-html-major-modes nil "List of supported language major mode names as strings.")
(setq xah-html-major-modes (mapcar (lambda (x) (aref (cdr x) 0)) xah-html-langcode-map))

;; HHH___________________________________________________________________

(defun xah-html-image-dimensions (Filepath)
  "Returns a vector [width height] of a image's dimension.
The elements are integer datatype.
Support png jpg svg gif and any image type emacs supports.
If it's svg, and dimension cannot be determined, it returns [0 0].
If it's webp, calls `xah-html-image-dimensions-imk'.

URL `http://ergoemacs.org/emacs/elisp_image_tag.html'
Version 2017-01-11 2021-09-01"
  (let ($x $y)
    (cond
     ((string-match "\.svg$" Filepath)
      (progn
        (with-temp-buffer
          ;; hackish. grab the first occurence of width height in file
          (insert-file-contents Filepath)
          (goto-char (point-min))
          (when (re-search-forward "width=\"\\([0-9]+\\).*\"" nil 1)
            (setq $x (match-string-no-properties 1 )))
          (goto-char (point-min))
          (if (re-search-forward "height=\"\\([0-9]+\\).*\"" nil 1)
              (setq $y (match-string-no-properties 1 ))))
        (if (and $x $y)
            (vector (string-to-number $x) (string-to-number $y))
          [0 0])))
     ((string-match "\.webp$" Filepath)
      (xah-html-image-dimensions-imk Filepath))
     (t
      (let ($xy )
        (progn
          (clear-image-cache t)
          (setq $xy (image-size
                     (create-image
                      (if (file-name-absolute-p Filepath)
                          Filepath
                        (concat default-directory Filepath)))
                     t)))
        (vector (car $xy) (cdr $xy)))))))

(defun xah-html-image-dimensions-imk (Filepath)
  "Returns a image file's width and height as a vector.
This function requires “magick identify” shell command.
See also: `xah-get-image-dimensions'.

URL `http://ergoemacs.org/emacs/elisp_image_tag.html'
Version 2015-05-12 2021-09-01"
  (let (($widthHeight
         (split-string
          (shell-command-to-string
           (concat "magick identify -format \"%w %h\" " Filepath)))))
    (vector
     (string-to-number (elt $widthHeight 0))
     (string-to-number (elt $widthHeight 1)))))

(defun xah-html-fix-datetime (Begin End)
  "Change timestamp under cursor into a yyyy-mm-dd format.
If there's a text selection, use that as input, else use current line.
Replace the text in selection or current line.

Any “day of week”, or “time” info, or any other parts of the string, are discarded.
For example:
 TUESDAY, FEB 15, 2011 05:16 ET → 2011-02-15
 November 28, 1994              → 1994-11-28
 Nov. 28, 1994                  → 1994-11-28
 11/28/1994                     → 1994-11-28
 1994/11/28                     → 1994-11-28

URL `http://ergoemacs.org/emacs/elisp_datetime_parser.html'
Version 2020-09-08"
  (interactive
   (list
    (if (region-active-p) (region-beginning))
    (if (region-active-p) (region-end))))
  (require 'parse-time)
  (let ($p1 $p2 $in)
    (if Begin
        (setq $p1 Begin $p2 End)
      (setq $p1 (line-beginning-position) $p2 (line-end-position)))
    (setq $in (replace-regexp-in-string "^ *\\(.+\\) *$" "\\1" (buffer-substring-no-properties $p1 $p2)))
  ; remove white spaces
    (setq
     $in
     (cond
      ;; yyyy/mm/dd
      ((string-match "\\([0-9][0-9][0-9][0-9]\\)/\\([0-9][0-9]\\)/\\([0-9][0-9]\\)" $in)
       (concat (match-string-no-properties 1 $in) "-" (match-string-no-properties 2 $in) "-" (match-string-no-properties 3 $in)))

      ;; mm/dd/yyyy
      ((string-match "\\([0-9][0-9]\\)/\\([0-9][0-9]\\)/\\([0-9][0-9][0-9][0-9]\\)" $in)
       (concat (match-string-no-properties 3 $in) "-" (match-string-no-properties 1 $in) "-" (match-string-no-properties 2 $in)))
      ;; m/dd/yyyy
      ((string-match "\\([0-9]\\)/\\([0-9][0-9]\\)/\\([0-9][0-9][0-9][0-9]\\)" $in)
       (concat (match-string-no-properties 3 $in) "-0" (match-string-no-properties 1 $in) "-" (match-string-no-properties 2 $in)))

      ;; USA convention of mm/dd/yy
      ((string-match "\\([0-9][0-9]\\)/\\([0-9][0-9]\\)/\\([0-9][0-9]\\)" $in)
       (concat (format-time-string "%C") (match-string-no-properties 3 $in) "-" (match-string-no-properties 1 $in) "-" (match-string-no-properties 2 $in)))
      ;; USA convention of m/dd/yy
      ((string-match "\\([0-9]\\)/\\([0-9][0-9]\\)/\\([0-9][0-9]\\)" $in)
       (concat (format-time-string "%C") (match-string-no-properties 3 $in) "-0" (match-string-no-properties 1 $in) "-" (match-string-no-properties 2 $in)))

      ;; some ISO 8601. yyyy-mm-ddThh:mm
      ((string-match "\\([0-9][0-9][0-9][0-9]\\)-\\([0-9][0-9]\\)-\\([0-9][0-9]\\)T[0-9][0-9]:[0-9][0-9]" $in)
       (concat (match-string-no-properties 1 $in) "-" (match-string-no-properties 2 $in) "-" (match-string-no-properties 3 $in)))
      ;; some ISO 8601. yyyy-mm-dd
      ((string-match "\\([0-9][0-9][0-9][0-9]\\)-\\([0-9][0-9]\\)-\\([0-9][0-9]\\)" $in)
       (concat (match-string-no-properties 1 $in) "-" (match-string-no-properties 2 $in) "-" (match-string-no-properties 3 $in)))
      ;; some ISO 8601. yyyy-mm
      ((string-match "\\([0-9][0-9][0-9][0-9]\\)-\\([0-9][0-9]\\)" $in)
       (concat (match-string-no-properties 1 $in) "-" (match-string-no-properties 2 $in)))

      ;; else
      (t
       (progn
         (setq $in (replace-regexp-in-string "January " "Jan. " $in))
         (setq $in (replace-regexp-in-string "February " "Feb. " $in))
         (setq $in (replace-regexp-in-string "March " "Mar. " $in))
         (setq $in (replace-regexp-in-string "April " "Apr. " $in))
         (setq $in (replace-regexp-in-string "May " "May. " $in))
         (setq $in (replace-regexp-in-string "June " "Jun. " $in))
         (setq $in (replace-regexp-in-string "July " "Jul. " $in))
         (setq $in (replace-regexp-in-string "August " "Aug. " $in))
         (setq $in (replace-regexp-in-string "September " "Sep. " $in))
         (setq $in (replace-regexp-in-string "October " "Oct. " $in))
         (setq $in (replace-regexp-in-string "November " "Nov. " $in))
         (setq $in (replace-regexp-in-string "December " "Dec. " $in))

         (setq $in (replace-regexp-in-string "\\([0-9]+\\)st" "\\1" $in))
         (setq $in (replace-regexp-in-string "\\([0-9]+\\)nd" "\\1" $in))
         (setq $in (replace-regexp-in-string "\\([0-9]+\\)rd" "\\1" $in))
         (setq $in (replace-regexp-in-string "\\([0-9]\\)th" "\\1" $in))

         (let ($dateList $year $month $date $yyyy $mm $dd)
           (setq $dateList (parse-time-string $in))
           (setq $year (nth 5 $dateList))
           (setq $month (nth 4 $dateList))
           (setq $date (nth 3 $dateList))

           (setq $yyyy (number-to-string $year))
           (setq $mm (if $month (format "%02d" $month) ""))
           (setq $dd (if $date (format "%02d" $date) ""))
           (concat $yyyy "-" $mm "-" $dd))))))
    (delete-region $p1 $p2)
    (insert $in)))

(defun xah-html-fix-datetime-string (Datetime)
  "Return a new string of Datetime in yyyy-mm-dd format.
Other datetime info such as hours, minutes, time zone, are discarded. This function calls `xah-html-fix-datetime' to do work.

URL `http://ergoemacs.org/emacs/elisp_datetime_parser.html'
Version 2020-09-08"
  (with-temp-buffer
    (insert Datetime)
    (xah-html-fix-datetime (point-min) (point-max))
    (buffer-substring-no-properties (point-min) (point-max))))

(defun xah-html-is-html (Begin End)
  "Return true if region BEGIN END is htmlized code.
“htmlized” means the text contains &gt; or &lt; or &amp; or <span class=\"...\">.
WARNING: it just check if it contains span tags.
Version 2020-08-05 2021-05-12 2021-08-01"
  (save-excursion
    (cond
     ( (progn (goto-char Begin) (search-forward "&gt;" End t)) t )
     ( (progn (goto-char Begin) (search-forward "&lt;" End t)) t )
     ( (progn (goto-char Begin) (search-forward "&amp;" End t)) t )
     ( (progn (goto-char Begin) (re-search-forward "<span class=\"" End t)) t
       )
     (t nil))))

(defun xah-html-dehtml2 (Begin End)
  "Delete all span tags and convert entities in region.
Version 2018-10-08 2021-07-08 2021-08-14"
  (interactive
   (progn
     (re-search-backward "<pre *[^>]*>" nil t)
     (list (match-beginning 0) (match-end 0))))
  (save-restriction
    (narrow-to-region Begin End)
    (xah-replace-pairs-region (point-min) (point-max) '( ["<span>" ""] ["</span>" ""] ))
    (xah-replace-regexp-pairs-region (point-min) (point-max) '(["<span \\([^>]+?\\)>" ""]))
    (xah-html-decode-ampersand-region (point-min) (point-max))
    (xah-html-code-tag-to-brackets (point-min) (point-max))))

(defun xah-html-pre-code-back ()
  "Put the current temp file back to a html page in pre code.
For example, if current file is
xx,notes.html,20210829161728.go
it'll open the file notes.html of same dir, add the the buffer content to at a place where it mentions
xx,notes.html,20210829161728.go
replacing it.
Also, delete current temp file and buffer.

keybinding: \\[xah-html-pre-code-back]

See:
`xah-html-pre-code-to-new-file'
`xah-html-pre-code-back'

Version 2021-08-29 2021-08-30"
  (interactive)
  (let* (($bContent (progn
                      (widen)
                      (buffer-substring-no-properties (point-min) (point-max))))
         ($bName (buffer-name ))
         ($bPath (buffer-file-name))
         ($fname (file-name-nondirectory $bPath))
         ($dadFname (nth 1 (split-string $fname ",")))
         $p1 $p2
         )
    (set-buffer-modified-p nil)
    (find-file $dadFname)
    (widen)
    (goto-char (point-min))
    (search-forward $fname )
    (setq $p1 (match-beginning 0) $p2 (match-end 0))
    (delete-region $p1 $p2)
    (goto-char $p1)
    (insert $bContent)
    (kill-buffer $bName)
    (delete-file $bPath)))

(defun xah-html-pre-code-to-new-file ()
  "Create a new file in current dir with content from current pre element.
For example, if the cursor is somewhere in innerText of pre tag:
<pre class=\"golang\">▮3+4</pre>
after calling, a temp file is created in current dir, named like this
xx,‹fname›,‹dateTimeStamp›.‹ext›
For example:
xx,notes.html,20210829161728.go
with content “3+4”.
If file already exist, overwrite it.

if the code is java, the file name is the java class name.

In the new buffer, when done editing, call `xah-html-pre-code-back' to put content back to the original html file and delete the temp buffer.

Version 2019-04-29 2021-08-29 2021-09-22"
  (interactive)
  (let* (($preBegin (search-backward "<pre "))
         ($p1 (search-forward ">"))
         ($p2 (xah-html--goto-closing-tag-begin $preBegin))
         ($langCode (xah-html--get-attribute "class" $preBegin $p1))
         ($textContent (buffer-substring-no-properties $p1 $p2))
         ($fileExt (elt (cdr (assoc $langCode xah-html-langcode-map)) 1))
         ($tempFname (format "xx,%s,%s.%s"
                             (file-name-nondirectory (buffer-file-name))
                             (format-time-string "%Y%m%d%H%M%S")
                             $fileExt))
         ($majorMode (elt (cdr (assoc $langCode xah-html-langcode-map)) 0))
         ($buf (generate-new-buffer "untitled")))
    (when (null $majorMode) (message "no major mode found for class [%s]." $langCode))
    (split-window-below)
    (delete-region $p1 $p2 )
    (goto-char $p1)
    (insert $tempFname)
    (progn
      (switch-to-buffer $buf)
      (buffer-disable-undo)
      (if $majorMode (funcall (intern-soft $majorMode)) (fundamental-mode))
      (insert $textContent)
      (when (xah-html-is-html (point-min) (point-max)) (xah-html-dehtml2 (point-min) (point-max)))
      (write-file
       (if (string-equal $fileExt "java")
           (progn
             (goto-char (point-min))
             (if (re-search-forward "class \\([A-Za-z0-9]+\\)[\n ]*{" nil t)
                 (format "%s.java" (match-string-no-properties 1))
               $tempFname))
         $tempFname)
       t)
      (goto-char (point-min))
      (buffer-enable-undo)
      (local-set-key (kbd "<f9> <f9>") 'xah-html-pre-code-back)
      (message "When done, press <f9> <f9> for `xah-html-pre-code-back'" )
      (setq buffer-offer-save t))))

;; HHH___________________________________________________________________

(defun xah-html-langcode-to-mode-name (LangCode )
  "Get the `major-mode' name associated with LangCode.
Lookup in `xah-html-langcode-map'.
Return a string. If none found, return nil.
Version 2017-01-10 2021-08-14 2021-09-22"
  (elt (cdr (assoc LangCode xah-html-langcode-map)) 0))

;; HHH___________________________________________________________________

(defun xah-html-htmlize-string (Str MajorMode)
  "Take Str and return a htmlized version using MajorMode.
The purpose is to syntax color source code in HTML.

If MajorMode is string. It'll be converted to symbol and if is not in `obarray', `fundamental-mode' is used.

This function requires the `htmlize-buffer' from htmlize.el by Hrvoje Niksic.

Version 2018-09-28 2020-09-27 2021-08-27"
  (let ($outputBuff $result ($majorModeSym (intern-soft MajorMode)))
    ;; put code in a temp buffer, set the mode, fontify
    (with-temp-buffer
      (insert Str)
      (if (fboundp $majorModeSym) (funcall $majorModeSym) (fundamental-mode))
      (font-lock-ensure)
      (setq $outputBuff (htmlize-buffer)))
    ;; extract the fontified source code in htmlize output
    (setq $result
          (with-current-buffer $outputBuff
            (buffer-substring-no-properties
             (search-forward "<pre>")
             (progn (search-forward "</pre>") (match-beginning 0)))))
    (kill-buffer $outputBuff)
    $result))

(defun xah-html-htmlize-region (P1 P2 MajorMode)
  "Htmlized region P1 P2 using `major-mode' MajorMode.
Version 2016-12-18 2021-02-19"
  (interactive
   (list (region-beginning)
         (region-end)
         (ido-completing-read "Chose mode for coloring:" xah-html-major-modes)))
  (let* (($input (buffer-substring-no-properties P1 P2))
         ($outStr (string-trim (xah-html-htmlize-string $input MajorMode))))
    (if (string-equal $input $outStr)
        nil
      (progn
        (delete-region P1 P2)
        (insert $outStr)))))

(defun xah-html-dehtmlize-pre-buffer ()
  "Remove html markup for all <pre class=\"‹langCode›\">...<pre> in current buffer.
Returns 0 if nothing is done. Else a positive integer of the count of <pre class=lang>.
Version 2018-10-03 2021-08-14 2021-09-22"
  (interactive)
  (let ($p1 $p2 ($count 0))
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward "<pre class=\"\\([-A-Za-z0-9]+\\)\">" nil 1)
        (when (xah-html-langcode-to-mode-name (match-string-no-properties 1))
          (progn
            (setq $p1 (point))
            (backward-char 1)
            (xah-html-skip-tag-forward)
            (search-backward "</pre>")
            (setq $p2 (point))
            (save-restriction
              (narrow-to-region $p1 $p2)
              (xah-html-dehtml2 (point-min) (point-max))
              (setq $count (1+ $count)))))))
    $count
    ))

(defun xah-html-dehtmlize-pre-code-buffer ()
  "Remove htmlized text inside any code block in current buffer.
More specifically, any text inside

<pre class=\"‹langCode›\">…<pre>

Returns 0 if nothing is done. Else a positive integer of the count of <pre class=lang>.
Version 2018-10-11 2021-08-16"
  (interactive)
  (let (($count 0))
    (setq $count (xah-html-dehtmlize-pre-buffer))
    (message "dehtmlized %s code blocks" $count)
    $count
    ))

(defun xah-html-toggle-syntax-color-tags ()
  "Add/remove html markup for syntax color source code in current pre element.
Cursor must be in innertext: <pre …>…▮…</pre>.
Version 2019-06-13 2021-07-08 2021-09-07 2021-09-22"
  (interactive)
  (let* (($preBegin (search-backward "<pre "))
         ($p1 (search-forward ">"))
         ($p2 (xah-html--goto-closing-tag-begin $preBegin)))
    (if (xah-html-is-html $p1 $p2)
        (progn
          (xah-html-dehtml2 $p1 $p2)
          (message "Syntax color markup removed."))
      (let* (($classVal (xah-html--get-attribute "class" $preBegin $p1))
             ($majorMode (xah-html-langcode-to-mode-name $classVal)))
        (xah-html-htmlize-region $p1 $p2 $majorMode)
        (message "Syntax color markup added.")))))

(defun xah-html-redo-syntax-coloring-file (FilePath)
  "Redo all syntax color markup in pre tags of current file.
Returns 0 if nothing is done. Else a positive integer of the count of <pre class=lang>.
Version 2017-01-11 2021-08-14"
  (interactive (read-file-name "file path:" nil nil t))
  (let (($result 0))
    (with-temp-buffer
      (insert-file-contents FilePath)
      (goto-char (point-min))
      (xah-html-mode)
      (setq $result (xah-html-redo-syntax-coloring-buffer))
      (when (> $result 0)
        (let (($backupPath
               (concat FilePath "~htmlize" (format-time-string "%Y%m%dT%H%M%S") "~")))
          (copy-file FilePath $backupPath t))
        (write-region (point-min) (point-max) FilePath)))
    $result
    ))

(defun xah-html-redo-syntax-coloring-buffer ()
  "Redo all <pre class=\"...\"> syntax coloring in current HTML page.
Returns 0 if nothing is done. Else a positive integer of the count of <pre class=lang>.
Version 2019-06-13 2021-09-22"
  (interactive)
  (let ($langCode $p1 $p2 ($count 0) $majorMode)
    (save-excursion
      (goto-char (point-min))
      (while
          (re-search-forward "<pre class=\"\\([-A-Za-z0-9]+\\)\">" nil 1)
        (setq $langCode (match-string-no-properties 1))
        (setq $majorMode (xah-html-langcode-to-mode-name $langCode))
        (when $majorMode
          (progn
            (setq $p1 (point))
            (backward-char 1)
            (xah-html-skip-tag-forward)
            (search-backward "</pre>")
            (setq $p2 (point))
            (save-restriction
              (narrow-to-region $p1 $p2)
              (when (xah-html-is-html (point-min) (point-max)) (xah-html-dehtml2 (point-min) (point-max)))
              (xah-html-htmlize-region (point-min) (point-max) $majorMode)
              (setq $count (1+ $count)))))))
    (message "xah-html-redo-syntax-coloring-buffer %s redone" $count)
    $count
    ))

;; HHH___________________________________________________________________

(defun xah-html-open-local-link ()
  "Open the link under cursor or insert newline.
If cursor is on a src=… or href=…, then if it a file path, open file, if http, open in browser.
If there the file is .js , it'll open .ts if exist.
Else call `newline'.
Version 2019-05-30 2021-07-23"
  (interactive)
  (if (xah-html--cursor-in-link-p)
      (let ($srcStr)
        (setq $srcStr (xah-html-remove-uri-fragment (xah-get-thing-at-point 'inDoubleQuote )))
        (if (string-match "^http:\\|^https:" $srcStr)
            (browse-url $srcStr)
          (if (file-exists-p $srcStr)
              (let ; open f.ts instead of f.js
                  ( ($ext (file-name-extension $srcStr))
                    ($fnamecore (file-name-sans-extension $srcStr)))
                (if (and (string-equal $ext "js")
                         (file-exists-p (concat $fnamecore ".ts")))
                    (find-file (concat $fnamecore ".ts"))
                  (progn (find-file $srcStr))))
            (when (y-or-n-p (format "file no exist at [%s]. Create new?" $srcStr))
              (find-file $srcStr)))))
    (newline)))

;; HHH___________________________________________________________________

(defvar xah-html-nav-tag-map nil "key map for tag navigation.")
(setq xah-html-nav-tag-map
      (let (($kmap (make-sparse-keymap)))
        (define-key $kmap (kbd "<left>") 'xah-html-prev-opening-tag )
        (define-key $kmap (kbd "<right>") 'xah-html-next-opening-tag )
        (define-key $kmap (kbd "<down>") 'xah-html-goto-matching-tag )
        $kmap))

(defun xah-html-prev-opening-tag ()
  "Move cursor to the previous begin tag.
Result cursor position is on beginning of open tag: ▮<name…>.
To repeat, press:\n
\\{xah-html-nav-tag-map}
Version 2021-08-09 2021-08-18"
  (interactive)
  (let (($p0 (point)))
    (xah-html--goto-prev-tag-begin)
    (while (and
            (not (xah-html--opening-tag-p (point)))
            (< (point) $p0)
            (> (point) (point-min)))
      (search-backward "<" nil 1)))
  (set-transient-map xah-html-nav-tag-map ))

(defun xah-html-next-opening-tag ()
  "Move cursor to the next begin tag.
Result cursor position is on beginning of open tag: ▮<name…>.
To repeat, press:\n
\\{xah-html-nav-tag-map}
Version 2021-08-15 2021-08-18"
  (interactive)
  (let (($p0 (point)))
    (forward-char )
    (search-forward "<")
    (while (and
            (not (xah-html--opening-tag-p (1- (point))))
            (> (point) $p0)
            (< (point) (point-max)))
      (search-forward "<" nil 1)))
  (backward-char )
  (set-transient-map xah-html-nav-tag-map ))

(defun xah-html-goto-matching-tag ()
  "Move cursor to the matching tag.
If cursor is not inside <…▮…>, move to previous < and try again.
Result cursor position is on beginning of open/close tag: ▮< .
To repeat, press:\n
\\{xah-html-nav-tag-map}
Version 2021-07-21 2021-08-16"
  (interactive)
  (when (not (eq (char-after ) ?<)) (xah-html--goto-prev-tag-begin))
  (xah-html--goto-matching-tag (point))
  (set-transient-map xah-html-nav-tag-map))

(defun xah-html--rename-opening-tag (TagBegin OldNameLength NewName)
  "Version 2021-08-19"
  (goto-char TagBegin)
  (forward-char 1)
  (delete-char OldNameLength)
  (insert NewName))

(defun xah-html--rename-closing-tag (TagBegin OldNameLength NewName)
  "Version 2021-08-19"
  (goto-char TagBegin)
  (forward-char 2)
  (delete-char OldNameLength)
  (insert NewName))

(defun xah-html-change-current-tag ()
  "Change the tag name of current tag.
The tag changed is the current element cusor is in: <…▮…>. If cursor not inside tag, change the first tag to the left of cursor.
version 2016-12-18 2021-08-19"
  (interactive)
  (let* (($tagP1 (xah-html--goto-prev-tag-begin))
         ($isOpenTag (xah-html--opening-tag-p $tagP1))
         ($oldName (xah-html--get-tag-name $tagP1))
         ($oldNameLength (length $oldName))
         ($isSelfClose (xah-html--tag-self-closing-p $oldName))
         ($newName (ido-completing-read "HTML tag:" xah-html-tag-list "PREDICATE" "REQUIRE-MATCH" nil xah-html-html-tag-input-history "span")))
    (if $isSelfClose
        (xah-html--rename-opening-tag $tagP1 $oldNameLength $newName)
      (let ($openingTagP1 $closingTagP1)
        (if $isOpenTag
            (progn
              (setq $openingTagP1 $tagP1)
              (goto-char $openingTagP1)
              (forward-char 1)
              (xah-html-skip-tag-forward)
              (xah-html--goto-prev-tag-begin)
              (setq $closingTagP1 (point)))
          (progn
            (setq $closingTagP1 $tagP1)
            (goto-char $closingTagP1)
            (forward-char 1)
            (xah-html-skip-tag-backward)
            (setq $openingTagP1 (point))))
        (xah-html--rename-closing-tag $closingTagP1 $oldNameLength $newName)
        (xah-html--rename-opening-tag $openingTagP1 $oldNameLength $newName)))))

(defun xah-html-escape-char-to-entity (&optional Begin End EntityToCharQ)
  "Replace HTML chars & < > to HTML entities on current block or selection.
The string replaced are:
 & → &amp;
 < → &lt;
 > → &gt;

Highlight changed places.
If `universal-argument' is called first, the replacement direction is reversed.

When called in lisp code, Begin End are region begin/end positions. If EntityToCharQ is true, reverse change direction.

URL `http://ergoemacs.org/emacs/elisp_replace_html_entities_command.html'
Version 2020-08-30 2021-03-25 2021-08-26 2021-09-15 2021-10-17"
  (interactive)
  (let* (($bds (if (and Begin End) nil (xah-get-bounds-of-thing-or-region 'block)))
         ($p1 (if Begin Begin (car $bds)))
         ($p2 (if End End (cdr $bds)))
         ($entToChar (if EntityToCharQ EntityToCharQ current-prefix-arg)))
    (xah-replace-pairs-region
     $p1 $p2
     (if $entToChar
         [ ["&amp;" "&"] ["&lt;" "<"] ["&gt;" ">"] ]
       [ ["&" "&amp;"] ["<" "&lt;"] [">" "&gt;"] ]
       )
     t t)))

(defun xah-html-escape-char-to-unicode (Begin End &optional ToAsciiQ)
  "Replace chars < > & to fullwidth version ＜ ＞ ＆ in current block or selection.

Highlight changed places.
If `universal-argument' is called first, the replacement direction is reversed.

When called in lisp code, Begin End are region begin/end positions. If ToAsciiQ is true, reverse change direction.

URL `http://ergoemacs.org/emacs/elisp_replace_html_entities_command.html'
Version 2020-08-30 2021-03-25 2021-08-26"
  (interactive
   (let ($p1 $p2)
     (let (($bds (xah-get-bounds-of-thing-or-region 'block))) (setq $p1 (car $bds) $p2 (cdr $bds)))
     (list $p1 $p2 current-prefix-arg)))
  (let (($replaceMap
         (if ToAsciiQ
             [ ["＆" "&"] [ "＜" "<"] [ "＞" ">"] ]
           [ ["&" "＆"] ["<" "＜"] [">" "＞"] ]
           )))
    (xah-replace-pairs-region Begin End $replaceMap nil t)))

(defun xah-html-named-entity-to-char (Begin End)
  "Replace named entity to Unicode character in current block or selection.
Changed places are highlighted.
For example, “&copy;” becomes “©”.
The following HTML Entities are not replaced: &amp; &lt; &gt;

When called in lisp code, Begin End are region begin/end positions.

URL `http://ergoemacs.org/emacs/elisp_replace_html_entities_command.html'
Version 2020-08-30 2021-09-04"
  (interactive
   (let* (($bds (xah-get-bounds-of-thing-or-region 'block))
          ($p1 (car $bds)) ($p2 (cdr $bds)))
     (list $p1 $p2)))
  (let (($replaceMap
         [
          ["&nbsp;" " "] ["&ensp;" " "] ["&emsp;" " "] ["&thinsp;" " "]
          ["&rlm;" "‏"] ["&lrm;" "‎"] ["&zwj;" "‍"] ["&zwnj;" "‌"]

          ["&iexcl;" "¡"] ["&cent;" "¢"] ["&pound;" "£"] ["&curren;" "¤"] ["&yen;" "¥"]
          ["&brvbar;" "¦"] ["&sect;" "§"] ["&uml;" "¨"] ["&copy;" "©"] ["&ordf;" "ª"]
          ["&laquo;" "«"] ["&not;" "¬"] ["&shy;" "­"] ["&reg;" "®"] ["&macr;" "¯"]
          ["&deg;" "°"] ["&plusmn;" "±"] ["&sup2;" "²"] ["&sup3;" "³"] ["&acute;" "´"]
          ["&micro;" "µ"] ["&para;" "¶"] ["&middot;" "·"] ["&cedil;" "¸"] ["&sup1;" "¹"]
          ["&ordm;" "º"] ["&raquo;" "»"] ["&frac14;" "¼"] ["&frac12;" "½"]
          ["&frac34;" "¾"] ["&iquest;" "¿"]

          ["&Agrave;" "À"] ["&Aacute;" "Á"] ["&Acirc;" "Â"] ["&Atilde;" "Ã"] ["&Auml;" "Ä"]
          ["&Aring;" "Å"] ["&AElig;" "Æ"] ["&Ccedil;" "Ç"] ["&Egrave;" "È"] ["&Eacute;" "É"]
          ["&Ecirc;" "Ê"] ["&Euml;" "Ë"] ["&Igrave;" "Ì"] ["&Iacute;" "Í"] ["&Icirc;" "Î"]
          ["&Iuml;" "Ï"] ["&ETH;" "Ð"] ["&Ntilde;" "Ñ"] ["&Ograve;" "Ò"] ["&Oacute;" "Ó"]
          ["&Ocirc;" "Ô"] ["&Otilde;" "Õ"] ["&Ouml;" "Ö"] ["&times;" "×"] ["&Oslash;" "Ø"]
          ["&Ugrave;" "Ù"] ["&Uacute;" "Ú"] ["&Ucirc;" "Û"] ["&Uuml;" "Ü"] ["&Yacute;" "Ý"]
          ["&THORN;" "Þ"] ["&szlig;" "ß"] ["&agrave;" "à"] ["&aacute;" "á"] ["&acirc;" "â"]
          ["&atilde;" "ã"] ["&auml;" "ä"] ["&aring;" "å"] ["&aelig;" "æ"] ["&ccedil;" "ç"]
          ["&egrave;" "è"] ["&eacute;" "é"] ["&ecirc;" "ê"] ["&euml;" "ë"] ["&igrave;" "ì"]
          ["&iacute;" "í"] ["&icirc;" "î"] ["&iuml;" "ï"] ["&eth;" "ð"] ["&ntilde;" "ñ"]
          ["&ograve;" "ò"] ["&oacute;" "ó"] ["&ocirc;" "ô"] ["&otilde;" "õ"] ["&ouml;" "ö"]

          ["&divide;" "÷"] ["&oslash;" "ø"] ["&ugrave;" "ù"] ["&uacute;" "ú"] ["&ucirc;" "û"]
          ["&uuml;" "ü"] ["&yacute;" "ý"] ["&thorn;" "þ"] ["&yuml;" "ÿ"] ["&fnof;" "ƒ"]

          ["&Alpha;" "Α"] ["&Beta;" "Β"] ["&Gamma;" "Γ"] ["&Delta;" "Δ"] ["&Epsilon;" "Ε"]
          ["&Zeta;" "Ζ"] ["&Eta;" "Η"] ["&Theta;" "Θ"] ["&Iota;" "Ι"] ["&Kappa;" "Κ"]
          ["&Lambda;" "Λ"] ["&Mu;" "Μ"] ["&Nu;" "Ν"] ["&Xi;" "Ξ"] ["&Omicron;" "Ο"]
          ["&Pi;" "Π"] ["&Rho;" "Ρ"] ["&Sigma;" "Σ"] ["&Tau;" "Τ"] ["&Upsilon;" "Υ"]
          ["&Phi;" "Φ"] ["&Chi;" "Χ"] ["&Psi;" "Ψ"] ["&Omega;" "Ω"] ["&alpha;" "α"]
          ["&beta;" "β"] ["&gamma;" "γ"] ["&delta;" "δ"] ["&epsilon;" "ε"] ["&zeta;" "ζ"]
          ["&eta;" "η"] ["&theta;" "θ"] ["&iota;" "ι"] ["&kappa;" "κ"] ["&lambda;" "λ"]
          ["&mu;" "μ"] ["&nu;" "ν"] ["&xi;" "ξ"] ["&omicron;" "ο"] ["&pi;" "π"]
          ["&rho;" "ρ"] ["&sigmaf;" "ς"] ["&sigma;" "σ"] ["&tau;" "τ"] ["&upsilon;" "υ"]
          ["&phi;" "φ"] ["&chi;" "χ"] ["&psi;" "ψ"] ["&omega;" "ω"] ["&thetasym;" "ϑ"]
          ["&upsih;" "ϒ"] ["&piv;" "ϖ"]

          ["&bull;" "•"] ["&hellip;" "…"] ["&prime;" "′"] ["&Prime;" "″"] ["&oline;" "‾"]
          ["&frasl;" "⁄"] ["&weierp;" "℘"] ["&image;" "ℑ"] ["&real;" "ℜ"] ["&trade;" "™"]
          ["&alefsym;" "ℵ"] ["&larr;" "←"] ["&uarr;" "↑"] ["&rarr;" "→"] ["&darr;" "↓"]
          ["&harr;" "↔"] ["&crarr;" "↵"] ["&lArr;" "⇐"] ["&uArr;" "⇑"] ["&rArr;" "⇒"]
          ["&dArr;" "⇓"] ["&hArr;" "⇔"] ["&forall;" "∀"] ["&part;" "∂"] ["&exist;" "∃"]
          ["&empty;" "∅"] ["&nabla;" "∇"] ["&isin;" "∈"] ["&notin;" "∉"] ["&ni;" "∋"]
          ["&prod;" "∏"] ["&sum;" "∑"] ["&minus;" "−"] ["&lowast;" "∗"] ["&radic;" "√"]
          ["&prop;" "∝"] ["&infin;" "∞"] ["&ang;" "∠"] ["&and;" "∧"] ["&or;" "∨"]
          ["&cap;" "∩"] ["&cup;" "∪"] ["&int;" "∫"] ["&there4;" "∴"] ["&sim;" "∼"]
          ["&cong;" "≅"] ["&asymp;" "≈"] ["&ne;" "≠"] ["&equiv;" "≡"] ["&le;" "≤"]
          ["&ge;" "≥"] ["&sub;" "⊂"] ["&sup;" "⊃"] ["&nsub;" "⊄"] ["&sube;" "⊆"]
          ["&supe;" "⊇"] ["&oplus;" "⊕"] ["&otimes;" "⊗"] ["&perp;" "⊥"] ["&sdot;" "⋅"]
          ["&lceil;" "⌈"] ["&rceil;" "⌉"] ["&lfloor;" "⌊"] ["&rfloor;" "⌋"] ["&lang;" "〈"]
          ["&rang;" "〉"] ["&loz;" "◊"] ["&spades;" "♠"] ["&clubs;" "♣"] ["&hearts;" "♥"]
          ["&diams;" "♦"] ["&quot;" "\""] ["&OElig;" "Œ"] ["&oelig;" "œ"] ["&Scaron;" "Š"]
          ["&scaron;" "š"] ["&Yuml;" "Ÿ"] ["&circ;" "ˆ"] ["&tilde;" "˜"] ["&ndash;" "–"]
          ["&mdash;" "—"] ["&lsquo;" "‘"] ["&rsquo;" "’"] ["&sbquo;" "‚"] ["&ldquo;" "“"]
          ["&rdquo;" "”"] ["&bdquo;" "„"] ["&dagger;" "†"] ["&Dagger;" "‡"] ["&permil;" "‰"]
          ["&lsaquo;" "‹"] ["&rsaquo;" "›"] ["&euro;" "€"]
          ]))
    (xah-replace-pairs-region Begin End $replaceMap nil t)))

(defun xah-html-get-html-file-title (Fname &optional NoError)
  "Return Fname <title> tag's text.
Assumes that the file contains the string “<title>…</title>”. If not, and if NoError is true, then return empty string.

Version 2018-06-06 2021-08-14"
  (with-temp-buffer
    (insert-file-contents Fname nil nil nil t)
    (goto-char (point-min))
    (if (search-forward "<title>" nil NoError)
        (buffer-substring-no-properties
         (point)
         (- (search-forward "</title>") 8))
      ""
      )))

(defun xah-html-lines-to-list ()
  "Make the current block or selection into a HTML list.
If there is no selection, make each line into a list item.
If there is selection, each text block becomes a list item. (text block is separated by blank lines.)
If `universal-argument' is called first, use ordered list ol instead of ul.

URL `http://ergoemacs.org/emacs/elisp_lines_to_list.html'
Version ~2013 2021-09-11"
  (interactive)
  (let* (($sep (if mark-active "\n\n+" "\n"))
         ($bds (xah-get-bounds-of-thing-or-region 'block))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($input (buffer-substring-no-properties $p1 $p2))
         ($items (split-string $input $sep t " +"))
         ($sList (mapcar (lambda (x) (format "<li>%s</li>" x)) $items))
         ($listStr (mapconcat 'identity $sList "\n")))
    (save-excursion
      (save-restriction
        (narrow-to-region $p1 $p2)
        (delete-region (point-min) (point-max))
        (insert (if current-prefix-arg
                    (concat "<ol>\n" $listStr "\n</ol>")
                  (concat "<ul>\n" $listStr "\n</ul>")))
        (goto-char (point-min))
        (while (re-search-forward "<li>[-.•*] " nil 1)
          (replace-match "<li>" t t))
        (progn
          (goto-char (point-min))
          (setq mark-active nil)
          (while (search-forward ".html<" nil 1)
            (backward-char)
            (xah-html-any-to-link))))))
  (skip-chars-forward " \t\n"))

(defun xah-html-lines-to-def-list ()
  "Make current block/selection into a definition list.
If there's no selection, current block is input, and each line is a item, and “. ” separates dt/dd.
If there's selection, blank lines separate list items, for each item, first line is the dt, rest lines are one dd.

Example, without selection:

cat. 4 legs
bird. has wings

becomes

<dl>
<dt>cat</dt><dd>4 legs</dd>
<dt>bird</dt><dd>has wings</dd>
</dl>

with text selection:

「cat
4 legs

bird
has wings」

result same thing.

If `universal-argument' is called first, ask user to enter a separater for dt and dd.

Version 2018-10-11 2021-05-13 2021-09-13"
  (interactive)
  (let* (($itemSep (if mark-active "\n\n+" "\n"))
         ($bds (xah-get-bounds-of-thing-or-region 'block))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($input (buffer-substring-no-properties $p1 $p2))
         ($items (split-string $input $itemSep t " +"))
         $sList)
    (setq
     $sList
     (let* (($dtSep (if current-prefix-arg
                        (read-string "Separator char between term and definition:")
                      (if mark-active "\n" "\\. +"))))
       (mapcar
        (lambda (x)
          (let* (($head (substring x 0 (string-match $dtSep x)))
                 ($tail (substring x (match-end 0))))
            (concat (format "<dt>%s</dt>" $head) "\n" (format "<dd>%s</dd>" $tail))))
        $items)))
    (delete-region $p1 $p2)
    (insert "<dl>\n" (mapconcat 'identity $sList "\n") "\n</dl>")))

(defun xah-html-lines-to-table ()
  "Transform the current block or selection into a HTML table.
For example:

a|b|c
1|2|3

becomes

<table class=\"nrm\">
<tr><td>a</td><td>b</td><td>c</td></tr>
<tr><td>1</td><td>2</td><td>3</td></tr>
</table>

URL `http://ergoemacs.org/emacs/elisp_make-html-table.html'
Version 2019-06-07 2021-07-21 2021-09-04"
  (interactive)
  (let* (($sep (read-string "String for column separation:" "|" nil "|"))
         ($bds (xah-get-bounds-of-thing-or-region 'block))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($input (buffer-substring-no-properties $p1 $p2))
         ($lines (split-string $input "\n" t " +"))
         ($rows
          (mapcar
           (lambda (x)
             (format "<tr><td>%s</td></tr>"
                     (mapconcat 'identity (split-string x $sep) "</td><td>")))
           $lines))
         ($resultStr
          (concat "<table class=\"nrm\">\n"
                  (mapconcat 'identity $rows "\n")
                  "\n</table>")))
    (delete-region $p1 $p2)
    (insert $resultStr)))

(defun xah-html-remove-table-tags ()
  "Change html table in current block to plain text.
The <table tag must appear somewhere to the left of cursor.
Version 2016-12-18 2021-01-07 2021-09-04"
  (interactive)
  (let (($p1 (search-backward "<table"))
        ($p2 (search-forward "</table>"))
        ($sep "|"))
    (save-restriction
      (narrow-to-region $p1 $p2)
      (goto-char (point-min))
      (while (search-forward $sep nil 1)
        (setq
         $sep
         (read-string
          (format "The text contains %s. Type a new char for column separator:" $sep)
          "🔴" nil "🔴")))
      (goto-char (point-min))
      (delete-char (point-min) (search-forward ">"))
      (xah-replace-pairs-region
       (point-min) (point-max)
       [
        ["<td>" "🖸"]
        ["</td>" "🖸"]
        ["<th>" "🖸"]
        ["</th>" "🖸"]
        ["<tr>" ""]
        ["</tr>" ""]
        ["</table>" ""]
        ]
       t t
       )
      (xah-replace-regexp-pairs-region
       (point-min) (point-max)
       (vector
        ["^🖸" ""]
        ["🖸$" ""]
        (vector "🖸🖸" $sep))
       t t
       ))))

(defun xah-html-join-tags ()
  "Join the elements before and after cursor.
The elements must be the same named element.

For example,
<p>cat</p>▮<p>dog</p>
becomes
<p>cat
▮dog</p>

After this command is called, press space to repeat it.

Version 2021-07-18 2021-09-10"
  (interactive)
  (let* (($p0 (point))
         ($p1 (xah-html--goto-prev-tag-begin))
         ($p2 (search-forward ">"))
         ($p4 (progn (goto-char $p0) (search-forward ">")))
         ($p3 (xah-html--goto-prev-tag-begin))
         ($tagBeforeIsOpenTag (xah-html--opening-tag-p $p1))
         ($tagAfterIsOpenTag (xah-html--opening-tag-p $p3))
         $tagBeforeName $tagAfterName)
    (when $tagBeforeIsOpenTag (user-error "Tag before is not closing tag."))
    (when (not $tagAfterIsOpenTag) (user-error "Tag after is not closing tag."))
    (setq $tagBeforeName (xah-html--get-tag-name $p1))
    (setq $tagAfterName (xah-html--get-tag-name $p3))
    (when (not (string-equal $tagBeforeName $tagAfterName)) (user-error "Tag before and after do not have the same name."))
    (progn
      (delete-region $p3 $p4)
      (delete-region $p1 $p2))
    (goto-char $p1)
    (delete-char (- (skip-chars-forward " \t\n")))
    (when (and (looking-back "[-_.,'\"*&#$%^@!(){}A-Za-z0-9]" 1)
               (looking-at "[-_.,'\"*&#$%^@!(){}A-Za-z0-9]"))
      (insert " ")))
  (set-transient-map (let (($kmap (make-sparse-keymap))) (define-key $kmap (kbd "SPC") 'xah-html-join-tags) $kmap)))

(defun xah-html-disable-script-tag ()
  "Disable script tags in current buffer or selection.
Respect `narrow-to-region'.

Change
<script…>…</script>
 tags to
<script2 style=\"display:none\" …>…</script2>

Version 2021-08-25 2021-08-26"
  (interactive)
  (let ($p1 $p2)
    (if (region-active-p)
        (setq $p1 (region-beginning) $p2 (region-end))
      (setq $p1 (point-min) $p2 (point-max)))
    (save-restriction
      (narrow-to-region $p1 $p2)
      (goto-char (point-min))
      (while (re-search-forward "<script\\([^>]*?\\)>" nil t)
        (replace-match "\n<script2 style=\"display:none\"\\1>" t))
      (goto-char (point-min))
      (while (search-forward "</script>" nil t)
        (replace-match "</script2>\n" t t)))))

(defun xah-html-remove-paragraph-tags ()
  "Remove paragraph p tags in current block or selection.
Version 2020-08-17 2020-09-08"
  (interactive)
  (let ($p1 $p2)
    (let (($bds (xah-get-bounds-of-thing-or-region 'block))) (setq $p1 (car $bds) $p2 (cdr $bds)))
    (save-restriction
      (narrow-to-region $p1 $p2)
      (goto-char (point-min))
      (while (search-forward "<p>" nil t) (replace-match ""))
      (goto-char (point-min))
      (while (search-forward "</p>" nil t) (replace-match "")))))

(defun xah-html-remove-list-tags ()
  "Remove ul/ol/li list tags in current block or selection.
Version 2020-07-15 2021-08-13"
  (interactive)
  (let* (($bds (xah-get-bounds-of-thing-or-region 'block))
         ($p1 (car $bds))
         ($p2 (cdr $bds)))
    (save-restriction
      (narrow-to-region $p1 $p2)
      (xah-html-remove-x-tag "ul" (point-min) (point-max))
      (xah-html-remove-x-tag "ol" (point-min) (point-max))
      (xah-html-remove-x-tag "li" (point-min) (point-max)))))

(defun xah-html-remove-x-tag (TagName Begin End)
  "Delete HTML TagName tags in region.
Version 2021-08-13"
  (interactive
   (let* (($bds (xah-get-bounds-of-thing-or-region 'block))
          ($p1 (car $bds))
          ($p2 (cdr $bds)))
     (list (read-string "Tag name:") $p1 $p2)))
  (save-restriction
    (narrow-to-region Begin End)
    (xah-replace-pairs-region
     (point-min) (point-max)
     (list
      (vector (format "<%s>" TagName) "")
      (vector (format "</%s>" TagName) "")
      (vector (format "<%s />" TagName) "")))
    (xah-replace-regexp-pairs-region
     (point-min) (point-max)
     (list (vector (format "<%s \\([^>]+?\\)>" TagName) "")))
    (goto-char (point-max))))

(defun xah-html-remove-wikipedia-link ()
  "Delet wikipedia link under cursor or after cursor position.
The link text remains, and is colored red.
Entire link is printed to messages buffer.

Returns the entire link text.

Version 2020-08-22"
  (interactive)
  (let ($p1 $p2 $wholeLink $p3 $p4 $p5 $p6 $linkTextBegin $linkTextEnd)
    (when (search-forward "</a>" nil 1)
      (progn
        (setq $p2 (point))
        (re-search-backward "<a .*href=")
        (setq $p1 (point))
        (setq $wholeLink (buffer-substring-no-properties $p1 $p2))
        (when (search-forward ".wikipedia.org/wiki/"  $p2 1)
          (progn
            ;; delete the beginning link tag
            (search-backward "<")
            (setq $p3 (point))
            (search-forward ">")
            (setq $p4 (point))
            (delete-region $p3 $p4)
            (setq $linkTextBegin (point))
            ;; delete the end link tag
            (search-forward ">")
            (setq $p5 (point))
            (search-backward "<")
            (setq $p6 (point))
            (delete-region $p5 $p6)
            (setq $linkTextEnd (point))
            (overlay-put (make-overlay $linkTextBegin $linkTextEnd)'font-lock-face '(:foreground "red"))
            (overlay-put (make-overlay $linkTextBegin $linkTextEnd)'face 'bold)
            $wholeLink
            ))))))

(defun xah-html-remove-all-wikipedia-link ()
  "Remove all wikipedia links in buffer of HTML.
Highlight the link text that remains.
Return and print the list of url removed.
Version 2020-08-22 2021-09-28"
  (interactive)
  (save-excursion
    (let ($url ($removedList '()))
      (goto-char (point-min))
      ;; remove url like this https://en.wikipedia.org/wiki/United_States
      ;; but not https://en.wikipedia.org/wiki/File:QWERTY-home-keys-position.svg
      (while (search-forward "wikipedia.org/wiki" nil 1)
        (setq $url (thing-at-point 'url))
        (when (and (not (string-match "File:" $url))
                   (not (string-match "Image:" $url)))
          (let ($p1 $p2 $wholeLink $linkTextBegin $linkTextEnd)
            (when (search-forward "</a>" nil 1)
              (progn
                (setq $p2 (point))
                (re-search-backward "<a .*href=")
                (setq $p1 (point))
                (setq $wholeLink (buffer-substring-no-properties $p1 $p2))
                (when (search-forward ".wikipedia.org/wiki/"  $p2 1)
                  (progn
                    (delete-region (search-backward "<") (search-forward ">"))
                    (setq $linkTextBegin (point))
                    (delete-region (search-forward ">") (search-backward "<"))
                    (setq $linkTextEnd (point))
                    (overlay-put (make-overlay $linkTextBegin $linkTextEnd)'font-lock-face '(:foreground "red"))
                    (overlay-put (make-overlay $linkTextBegin $linkTextEnd)'face 'bold)
                    $wholeLink
                    )))))
          (push $url $removedList)))
      (mapc (lambda (x) (princ x) (terpri)) (reverse $removedList))
      $removedList
      )))

(defun xah-html-code-tag-to-brackets (Begin End &optional EntityToChar)
  "Change HTML code tags to brackets in current block or selection.

• <code>…</code> and <code class=\"…\">…</code> are changed to 「…」
• <var class=\"…\">…</var> is changed to ‹…›
• The HTML entities &amp; &lt; &gt; are changed to & < >.

if `universal-argument' is called first, don't convert the HTML entities.

When done, the cursor is placed at End.

when called in lisp program,
Begin End are region begin/end.
If EntityToChar is true, convert HTML entities to char.
Version 2018-10-08"
  (interactive
   (let (($bds (xah-get-bounds-of-thing 'block)))
     (list (car $bds) (cdr $bds) (if current-prefix-arg nil t))))
  (save-restriction
    (narrow-to-region Begin End)
    (xah-replace-regexp-pairs-region (point-min) (point-max) '(["<code class=\"[^\"]+\">" "「"] ["<var class=\"[^\"]+\">" "‹"]))
    (xah-replace-pairs-region
     (point-min) (point-max)
     '(
       ["<code>" "「"]
       ["</code>" "」"]
       ["<var>" "‹"]
       ["</var>" "›"] ))
    (when EntityToChar
      (xah-html-decode-ampersand-region (point-min) (point-max)))
    (goto-char (point-max))))

;; '(
;; ["<!doctype html>" ""]
;; ["<meta charset=\"utf-8\" />" ""]
;; [" class=\"[-_a-z0-9]+\" *"  " "]
;; [" id=\"[-_a-z0-9]+\" *"  " "]
;; [" title=\"\\([^\"]+?\\)\" *"  " "]
;; [" data-accessed=\"[-0-9]+\" *"  " "]
;; [" width=\"[0-9]+%?\" *"  " "]
;; [" height=\"[0-9]+%?\" *"  " "]

;; ["<link rel=\"stylesheet\" href=\"\\([^\"]+?\\)\" />" ""]
;; ["<a +href=\"\\([^\"]+?\\)\" *>\\([^<]+?\\)</a>" "\\2"]
;; ["<img +src=\"\\([^\"]+?\\)\" +alt=\"\\([^\"]+?\\)\" */?>" ""]

;; ["<[a-z0-9]+ */?>" ""]
;; ["</[a-z0-9]+>" ""]
;; ["&amp;" "&"]
;; ["&lt;" "<"]
;; ["&gt;" ">"]
;; )

(defun xah-html-remove-tags (Begin End)
  "Delete HTML tags in in current block or selection.
Version 2018-11-27 2021-01-12 2021-08-18"
  (interactive
   (let ($p1 $p2)
     (let (($bds (xah-get-bounds-of-thing-or-region 'block)))
       (setq $p1 (car $bds) $p2 (cdr $bds)))
     (list $p1 $p2)))
  (save-restriction
    (narrow-to-region Begin End)
    (let ((case-fold-search t))
      (xah-replace-regexp-pairs-region
       (point-min) (point-max)
       '(
         ["<[a-z0-9]+>" ""]
         ["<[a-z0-9]+ */>" ""]
         ["</[a-z0-9]+>" ""]
         ["<script>\\([^\\<]+?\\)</script>" ""]
         ["<[^>]+?>" ""]
         ) t t t)))
  (skip-chars-forward "\n" ))

(defun xah-html-html-to-text ()
  "Convert HTML to plain text on current block or selection.
Version 2019-04-12 2021-08-21 2021-08-30 2021-09-21"
  ;; the tags that contains info are:
  ;; img src= or other src
  ;; a href= or other href
  ;; video src= poster=
  ;; audio src=
  ;; source

  ;; tags whose body is not visible or rather useless as text
  ;; style
  ;; script

  ;; tag with some sinificance in formatting, when converting to text
  ;; hr
  ;; br
  ;; table ul ol dl
  ;; em strong b i u s del sup sub dfn code var samp kbd q cite

  (interactive)
  (let* (($bds (xah-get-bounds-of-thing-or-region 'block))
         ($p1 (car $bds))
         ($p2 (cdr $bds)))
    (save-excursion
      (save-restriction
        (narrow-to-region $p1 $p2)

        (xah-html-decode-ampersand-region (point-min) (point-max))

        (goto-char (point-min))

        (while (search-forward "<!--" (point-max) t)
          (delete-region (match-beginning 0) (search-forward "-->")))

        (goto-char (point-min))
        (while (search-forward "<a " (point-max) t)
          (xah-html--link-to-text (match-beginning 0)))

        (goto-char (point-min))
        (while (search-forward "<img " (point-max) t)
          (xah-html--img-to-text (match-beginning 0)))

        (goto-char (point-min))
        (while (re-search-forward "src=\"\\([^\"]+?\\)\""  nil t)
          (let (($matchStr (match-string-no-properties 1)))
            (search-forward ">" nil nil 2)
            (insert (format " [ %s ] " $matchStr))))

        (goto-char (point-min))
        (let ((case-fold-search nil))
          (xah-replace-regexp-pairs-region
           (point-min)
           (point-max)
           [
            [" class=\"\\([A-Za-z0-9]+\\)\" " " "]
            ["<var class=\"d\">\\([^<]+?\\)</var>" "‹\\1›"]
            ["<script>\\([^\\<]+?\\)</script>" ""]

            ["<img +src=\"\\([^\"]+?\\)\" +alt=\"\\([^\"]+?\\)\" +width=\"[0-9]+\" +height=\"[0-9]+\" */?>" "[IMAGE “\\2” \\1 ]"]
            ]
           t)
          (xah-replace-pairs-region
           (point-min)
           (point-max)
           '(
             ;; todo. something wrong here. not supposed to be regex
             ["<li>" "<li>• " ]
             ["</li>" "" ]

             ["<code>" "「" ]
             ["<code class=\"elisp_f\">" "「" ]
             ["<code class=\"path_xl\">" "「" ]
             ["</code>" "」" ]

             ["<cite>" "〈" ]
             ["<cite class=\"book\">" "〈" ]
             ["</cite>" "〉" ]

             ["<h2>" "## " ]
             ["</h2>" "" ]
             ["<h3>" "### " ]
             ["</h3>" "" ]
             ["<h4>" "#### " ]
             ["</h4>" "" ]
             ["<h5>" "##### " ]
             ["</h5>" "" ]
             ["<h6>" "###### " ]
             ["</h6>" "" ]
             ["</td><td>" " | " ]
             ["</th><th>" " | " ]
             )))
        (xah-html-remove-tags (point-min) (point-max))))))

(defun xah-call-ImageMagick ( ArgsStr PathOld PathNew  )
  "Wrapper to ImageMagick' “convert” shell command.
ArgsStr is argument string passed to ImageMagick's “convert” command.
PathOld is image file full path.
PathNew is new image file full path.
Version 2021-01-11"
  (let ( $cmdStr )
    ;; relative paths used to get around Windows/Cygwin path remapping problem
    (setq $cmdStr
          (format
           "%s %s \"%s\" \"%s\""
           (if (string-equal system-type "windows-nt") "magick.exe convert" "convert" )
           ArgsStr
           (if (file-name-absolute-p PathOld ) (file-relative-name PathOld) PathOld )
           (if (file-name-absolute-p PathNew ) (file-relative-name PathNew) PathNew )))
    (shell-command $cmdStr)
    (message "Called:[%s]" $cmdStr)))

(defun xah-html-resize-img ()
  "Create a new resized image of image path under cursor.
In a html file, put cursor on a image file path, call the command,
a thumbnail will be created in the same dir, and path of the newly created file will be inserted before the img tag.
If `universal-argument' is called first, ask for jpeg quality (default is 90) and whether to sharpen. (default is sharpen 1.)
Version 2020-11-13 2021-03-27 2021-09-01"
  (interactive)
  (let* (($bds (xah-get-bounds-of-thing 'filepath ))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($inputPath (buffer-substring-no-properties $p1 $p2))
         ($fPath1 (expand-file-name $inputPath ))
         ($dir (file-name-directory $fPath1))
         ($fname (file-name-nondirectory $fPath1))
         ($coreName (file-name-sans-extension $fname))
         ($ext (file-name-extension $fname))
         ($sideLength (string-to-number (read-from-minibuffer "~width:" "250" )))
         ($thumbnailSizeArea (* $sideLength $sideLength))
         ($size (xah-html-image-dimensions $fPath1))
         ($w (aref $size 0))
         ($h (aref $size 1))
         ($fnameNew (format "%s-s%d.%s" $coreName $sideLength $ext ))
         ($fPathNew (concat $dir $fnameNew))
         ($isLossy-p (or (string-equal (downcase $ext) "jpg")
                         (string-equal (downcase $ext) "jpeg")
                         (string-equal (downcase $ext) "webp")))
         $args $doIt
         )
    (when (not (file-exists-p $inputPath))
      (user-error "File not exist: %s" $inputPath))
    (setq $args
          (format " -scale %s%% %s %s "
                  (round (* (sqrt (/ (float $thumbnailSizeArea) (float (* $w $h)))) 100))
                  (if $isLossy-p
                      (if current-prefix-arg
                          (format "-quality %s%%" (read-string "quality:" "90"))
                        "-quality 90%")
                    " "
                    )
                  (if current-prefix-arg
                      (if (y-or-n-p "sharpen?")
                          " -sharpen 1 "
                        ""
                        )
                    " -sharpen 1 ")))
    (if (file-exists-p $fPathNew)
        (setq $doIt (y-or-n-p (format "File exist [%s]. Replace it?" $fPathNew)))
      (setq $doIt t ))
    (when $doIt (xah-call-ImageMagick $args $fPath1 $fPathNew ))
    ;; (message "%s" $args)
    (xah-html--goto-prev-tag-begin)
    (insert $fPathNew "\n")
    (backward-word )))

(defun xah-html-convert-to-jpg ()
  "Convert the image file under cursor in a html file, from jpg, then, linkify it in html. Do not delete the original
Version 2019-12-17 2021-01-11 2021-08-29"
  (interactive)
  (let* (($path (xah-get-thing-at-point 'filepath))
         ($newName (format "%s.jpg" (file-name-sans-extension $path))))
    (xah-call-ImageMagick " " $path $newName)
    (xah-html--goto-prev-tag-begin)
    (insert $newName )
    (insert "\n")
    (backward-char 2)
    (xah-html-image-to-img-tag)))

(defun xah-html-rename-source-file-path ()
  "Rename HTML source file path.
Place cursor anywhere to the right of a href/src attribute:
<img src=\"img/▮cats.jpg\" >
Call this command, it prompt for a new path/name with one line for dir path and line for file name. The separate lines are for ease of editing.
When done editing, newline characters in path are removed, and comma or space replaced by _. The file name is renamed, and link also updated.

URL `http://ergoemacs.org/emacs/emacs_html_rename_source_file_path.html'

This command is for interactive use only.
Version 2019-10-05 2021-08-29"
  (interactive)
  (let* (($p1
          (progn
            (re-search-backward "href=\\|src=" )
            (goto-char (1+ (match-end 0)))))
         ($p2 (progn (search-forward "\"" ) (match-beginning 0)))
         ($curDir (file-name-directory (or (buffer-file-name) default-directory )))
         ($oldPath (expand-file-name (buffer-substring-no-properties $p1 $p2) $curDir))
         ($promptPath (concat (file-name-directory $oldPath) "\n" (file-name-nondirectory $oldPath)))
         ($newPath (replace-regexp-in-string " \\|\n\\|," "_" (replace-regexp-in-string "\n" "" (read-string "New name: " $promptPath nil $promptPath )))))
    (message "%s" $promptPath)
    (when (if (file-exists-p $newPath) (y-or-n-p "File exist. Replace?") t)
      (message "old path: %s\n new path: %s" $oldPath $newPath)
      (rename-file $oldPath $newPath t)
      (delete-region $p1 $p2)
      (goto-char $p1)
      (insert (file-relative-name $newPath)))))

(defun xah-html-clone-file-in-link ()
  "Make a copy of a html file the link cursor is on.
Explanation:
Current buffer is a html file.
Cursor is on a local href value, e.g. href=\"path▮\".
If cursor is not on a href value, use the the one before cursor.
Call this command.
This command make a copy of the file, prompting for new file name, then insert a link after the current link.
Version 2018-12-24 2021-08-26 2021-09-24 2021-10-02"
  (interactive)
  (save-excursion
    (let ($fromPath $toPath $buf $newfName   )
      (search-backward "href=\"")
      (goto-char (match-end 0))
      (setq $fromPath (expand-file-name (thing-at-point 'filename)))
      (when (> (length $fromPath) 200) (user-error "$fromPath is longer than 200 chars. maybe something is wrong: %s" $fromPath))
      (setq $toPath
            (replace-regexp-in-string
             " " "_" (read-string
                      "New file path (full or relative):"
                      (format "%s_2.%s"
                              (file-name-sans-extension $fromPath)
                              (file-name-extension $fromPath)) nil)))
      (setq $newfName (file-name-nondirectory $toPath))
      (when (file-exists-p $toPath) (user-error "%s" (format "$toPath 「%s」 exist." $toPath)))
      (progn
        (setq $buf (find-file $toPath))
        (erase-buffer)
        (insert-file-contents $fromPath)
        (progn
          (goto-char (point-min))
          (re-search-forward "<title>\\([^<]+?\\)</title>")
          (replace-match (format "<title>%s</title>" $newfName))
          (re-search-forward "<h1>\\([^<]+?\\)</h1>")
          (replace-match (format "<h1>%s</h1>" $newfName)))
        (save-buffer $buf)
        (kill-buffer $buf))
      (search-forward "</a>")
      (insert (format "\n<a href=\"%s\">%s</a>" $newfName $newfName)))))

(defun xah-html-extract-url (Begin End &optional NotFullPathQ)
  "Extract URLs in current block or selection to `kill-ring'.
When called interactively, copy result to `kill-ring', each URL in a line.
If the URL is a local file relative path, convert it to full path.
If `universal-argument' is called first, don't convert relative URL to full path.

This command extracts all text of the forms
 <‹letter› … href=‹path› …>
 <‹letter› … src=‹path› …>
The quote for ‹path› may be double or single quote.

When called in lisp code, Begin End are region begin/end positions.
Returns a list of strings.

URL `http://ergoemacs.org/emacs/elisp_extract_url_command.html'
Version 2021-02-20 2021-03-22 2021-04-30 2021-08-11"
  (interactive
   (let ($p1 $p2)
     (let (($bds (xah-get-bounds-of-thing-or-region 'block))) (setq $p1 (car $bds) $p2 (cdr $bds)))
     (list $p1 $p2 (not current-prefix-arg))))
  (let (($regionText (buffer-substring-no-properties Begin End))
        ($urlList (list)))
    (with-temp-buffer
      (insert $regionText)
      (goto-char (point-min))
      (while (search-forward "<" nil t)
        (replace-match "\n<" t t))
      (goto-char (point-min))
      (while (re-search-forward
              "<[A-Za-z]+.+?\\(href\\|src\\)[[:blank:]]*?=[[:blank:]]*?\\([\"']\\)\\([^\"']+?\\)\\2" nil t)
        (push (match-string-no-properties 3) $urlList)))
    (setq $urlList (reverse $urlList))
    (when NotFullPathQ
      (setq $urlList
            (mapcar
             (lambda ($x)
               (if (string-match "^http:\\|^https:" $x )
                   $x
                 (expand-file-name
                  $x
                  (file-name-directory
                   (if (buffer-file-name)
                       (buffer-file-name)
                     default-directory
                     )))))
             $urlList)))
    (when (called-interactively-p 'any)
      (let (($printedResult (mapconcat 'identity $urlList "\n")))
        (kill-new $printedResult)
        (message "%s" $printedResult)))
    $urlList ))

(defun xah-html-local-links-to-fullpath ()
  "Change all local links to fullpaths, in current block or selection.
See also:
`xah-html-local-links-to-fullpath'
`xah-html-local-links-to-relative-path'
Version 2021-04-09 2021-08-29 2021-09-24"
  (interactive)
  (require 'xah-get-thing)
  (let* (($bds (xah-get-bounds-of-thing-or-region 'block))
         ($p1 (car $bds))
         ($p2 (cdr $bds)))
    (save-restriction
      (narrow-to-region $p1 $p2)
      (goto-char (point-min))
      (while (re-search-forward " \\(href\\|src\\|poster\\)=\"" nil t)
        (let* (($bds (xah-get-bounds-of-thing 'filepath))
               ($p1 (car $bds))
               ($p2 (cdr $bds))
               ($hrefVal (buffer-substring-no-properties  $p1 $p2)))
          (if (string-match ":\\|//" $hrefVal)
              nil
            (progn
              (delete-region  $p1 $p2)
              (insert (concat "file:///" (expand-file-name $hrefVal))))))))))

(defun xah-html-local-links-to-relative-path ()
  "Change all local links to relative paths, in current block or selection.
See also:
`xah-html-local-links-to-fullpath'
`xah-html-local-links-to-relative-path'
Version 2021-04-09 2021-06-06 2021-08-13"
  (interactive)
  (require 'xah-get-thing)
  (require 'subr-x)
  (let ( ($blkBounds (xah-get-bounds-of-thing-or-region 'block)))
    (save-restriction
      (narrow-to-region (car $blkBounds) (cdr $blkBounds))
      (goto-char (point-min))
      (while (search-forward "<a href=\"" nil t)
        (let* (($bds (xah-get-bounds-of-thing 'filepath ))
               ($hrefVal (buffer-substring-no-properties (car $bds) (cdr $bds))))
          (when (string-match "file:///" $hrefVal )
            (delete-region (car $bds) (cdr $bds))
            (insert (file-relative-name (string-remove-prefix "file:///" $hrefVal)))))))))

(defun xah-html-update-title (Title)
  "Update the <title>…</title> of current buffer.

URL `http://ergoemacs.org/emacs/elisp_update-html-title.html'
Version 2019-01-11 2021-08-26"
  (interactive
   (let ($oldTitle)
     (save-excursion
       (goto-char (point-min))
       (re-search-forward "<title>\\([^<]+?\\)</title>")
       (setq $oldTitle (match-string-no-properties 1 )))
     (list (read-string "New title:" $oldTitle nil $oldTitle "INHERIT-INPUT-METHOD"))))
  (let ($p1 $p2)
    (save-excursion
      (goto-char (point-min))
      (setq $p1 (search-forward "<title>"))
      (search-forward "</title>")
      (setq $p2 (match-beginning 0))
      (delete-region $p1 $p2 )
      (goto-char $p1)
      (insert Title ))))

(defun xah-html-update-first-h1 (H1Text)
  "Update the first <h1>…</h1> of current buffer.
When called in elisp code, H1Text is new title, a string.

URL `http://ergoemacs.org/emacs/elisp_update-html-title.html'
Version 2019-01-11 2021-08-26"
  (interactive
   (let ($oldTitle)
     (save-excursion
       (goto-char (point-min))
       (re-search-forward "<h1>\\([^<]+?\\)</h1>")
       (setq $oldTitle (match-string-no-properties 1 )))
     (list (read-string "New title:" $oldTitle nil $oldTitle "INHERIT-INPUT-METHOD"))))
  (let ($p1 $p2)
    (save-excursion
      (goto-char (point-min))
      (when (search-forward "<h1>")
        (setq $p1 (point))
        (search-forward "</h1>")
        (setq $p2 (match-beginning 0))
        (delete-region $p1 $p2 )
        (goto-char $p1)
        (insert H1Text )))))

(defun xah-html-update-title-h1 (Title)
  "Update the <title>…</title> and first <h1>…</h1> of current buffer.
When called in elisp code, Title is new title, a string.

URL `http://ergoemacs.org/emacs/elisp_update-html-title.html'
Version 2019-01-11 2021-07-31"
  (interactive
   (let ($oldTitle)
     (save-excursion
       (goto-char (point-min))
       (re-search-forward "<title>\\([^<]+?\\)</title>")
       (setq $oldTitle (match-string-no-properties 1 )))
     (list (read-string "New title:" $oldTitle nil $oldTitle "INHERIT-INPUT-METHOD"))))
  (progn
    (xah-html-update-title Title)
    (xah-html-update-first-h1 Title)))

(defun xah-html-insert-date-section ()
  "Insert a section tag with date tag inside.
Like this:
<section>
<div class=\"date_xl\"><time>2021-01-11</time></div>
</section>
Version 2020-11-16"
  (interactive)
  (let ($p1 $p2)
    (if (region-active-p)
        (setq $p1 (region-beginning) $p2 (region-end))
      (setq $p1 (point) $p2 (point)))
    (save-restriction
      (narrow-to-region $p1 $p2)
      (goto-char (point-min))
      (insert "\n\n<section>\n\n"
              (format "<div class=\"date_xl\"><time>%s</time></div>\n\n" (format-time-string "%Y-%m-%d")))
      (goto-char (point-max))
      (insert "\n\n</section>\n\n")
      (search-backward "\n\n</section>" ))))

(defun xah-html-make-citation ()
  "Reformat current block into a canonical citation format.
For example, place cursor somewhere in the following block:

Why Utopian Communities Fail
https://areomagazine.com/2018/03/08/why-utopian-communities-fail/
2018-03-08
by Ewan Morrison

becomes

 [<cite>Why Utopian Communities Fail</cite> <time>2018-03-08</time> By Ewan Morrison. At <a href=\"https://areomagazine.com/2018/03/08/why-utopian-communities-fail/\" data-accessed=\"2018-03-24\">https://areomagazine.com/2018/03/08/why-utopian-communities-fail/</a> ]

The block needs a line for each of: title, url, date, author line with “by ”. Order does not matter. The command tries to figure it out. If one item is missing, result s red on that part.

If there is a selection, use it for input, otherwise the input is a text block between blank lines.

URL `http://ergoemacs.org/emacs/elisp_make-citation.html'
Version 2020-07-15 2021-08-29 2021-09-24"
  (interactive)
  (let* (($bds (xah-get-bounds-of-thing 'block))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($input (buffer-substring-no-properties $p1 $p2))
         ($lines (split-string $input "\n" t " *"))
         $title $author $date $url)
    (let ($x (case-fold-search t))
      (while (> (length $lines) 0)
        (setq $x (pop $lines))
        (cond
         ((string-match "https?://" $x) (setq $url $x))
         ((xah-html--datetimestamp-p $x) (setq $date $x))
         ((string-match "^ *[bB]y:* " $x) (setq $author $x))
         (t (setq $title $x)))))
    (let (($tit2
           (if (not $title)
               (progn "[title?]")
             (replace-regexp-in-string
              "^\"\\(.+\\)\"$" "\\1"
              (xah-replace-pairs-in-string $title '(["’" "'"] ["&" "＆"])))))
          ($da2 (if (not $date)
                    "[date?]"
                  (xah-html-fix-datetime-string $date)))
          ($au2 (if (not $author)
                    (progn "[author?]")
                  (replace-regexp-in-string "\\. " " " (replace-regexp-in-string "^ *[Bb]y:* +" "" (upcase-initials (downcase $author))))))
          ($ur2
           (if (not $url)
               (progn "[url?]")
             (progn
               (if (string-match "www\.amazon\.com/\\|//amzn\.to/" $input)
                   (with-temp-buffer (insert $url) (xah-html-amazon-url-to-link) (buffer-string))
                 (with-temp-buffer (insert $url) (xah-html-url-to-dated-link) (buffer-string)))))))
      (delete-region $p1 $p2)
      (insert (format
               "[<cite>%s</cite> <time>%s</time> By %s. At %s ]"
               $tit2
               $da2
               $au2
               $ur2))
      (let (($p3 (point)))
        (goto-char $p1)
        (search-forward "[title?]" $p3 t)
        (overlay-put (make-overlay (match-beginning 0) (match-end 0)) 'face 'font-lock-warning-face)
        (goto-char $p1)
        (search-forward "[date?]" $p3 t)
        (overlay-put (make-overlay (match-beginning 0) (match-end 0)) 'face 'font-lock-warning-face)
        (goto-char $p1)
        (search-forward "[url?]" $p3 t)
        (overlay-put (make-overlay (match-beginning 0) (match-end 0)) 'face 'font-lock-warning-face)))))

(defun xah-html-make-link-defunct ()
  "Make the HTML link under cursor to a defunct form.
Example:
If cursor is inside this tag
 <a href=\"‹url›\">…</a>
or
 <a href=\"‹url›\" data-accessed=\"‹access_date›\">…</a>
where ‹access_date› is of this format 2019-04-02

It becomes:
 <s data-accessed=\"‹access_date›\" data-defunct-date=\"‹now_date›\">‹url›</s>

The link: <a …>…</a> must be in a single line.

URL `http://ergoemacs.org/emacs/elisp_html_dead_link.html'
Version 2019-04-02 2021-08-18"
  (interactive)
  (let ($p1 $p2 $wholeLinkStr $resultStr $url $accessedDate)
    (save-excursion
      ;; get the boundary of opening tag
      (forward-char 3)
      (search-backward "<a " (line-beginning-position)) (setq $p1 (point))
      (search-forward "</a>" (line-end-position)) (setq $p2 (point))
      (setq $wholeLinkStr (buffer-substring-no-properties $p1 $p2))
      (with-temp-buffer
        ;; generate replacement text
        (insert $wholeLinkStr)
        (goto-char (point-min))
        (re-search-forward  "href=\"\\([^\"]+?\\)\"")
        (setq $url (match-string-no-properties 1))
        (setq $accessedDate
              (if (re-search-forward
                   "data-accessed=\"\\([0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]\\)\"" $p2 t)
                  (match-string-no-properties 1)
                ""
                ))
        (setq $resultStr
              (format "<s data-accessed=\"%s\" data-defunct-date=\"%s\">%s</s>" $accessedDate (format-time-string "%Y-%m-%d") $url ))))
    (delete-region $p1 $p2)
    (insert $resultStr)))

(defun xah-html-video-file-suffix-p (Path)
  "Returns t if Path has video file suffix e.g. mp4, else nil.
Version 2018-11-14 2021-09-24"
  (let ((case-fold-search t))
    (string-match
     "\\.mp4\\'\\|\\.mov\\'\\|\\.mkv\\'\\|\\.webm\\'\\|\\.m1v\\'\\|\\.m4v\\'" Path)))

(defun xah-html-audio-file-suffix-p (Path)
  "Returns t if Path has audio file suffix e.g. m4a, else nil.
Version 2018-11-14 2021-09-24"
  (let ((case-fold-search t))
    (string-match "\\.mp3\\'\\|\\.m4a\\'\\|\\.ogg\\'\\|\\.opus\\'\\|\\.oga\\'" Path)))

(defun xah-html--image-file-ext-p (Path)
  "Returns t if Path ends in .jpg .png .gif .svg, .webp else nil.
Version 2017-08-11 2021-09-01 2021-09-24"
  (let ((case-fold-search t))
    (string-match "\.jpg\\'\\|\.png\\'\\|\.gif\\'\\|\.webp\\'\\|\.svg\\'" Path)))

(defun xah-html-image-to-link (&optional Begin End)
  "Make image file path at cursor point into a img link.
Example: i/cat.jpg becomes <a class=\"bigImg\" href=\"i/cat.jpg\">4176×2366</a>
If there is a selection, use that region as file name.
Version 2020-06-24 2021-08-11"
  (interactive)
  (let (($p0 (point)) $p1 $p2 ($skipChars "^ \n\t")  $input $imgPath $dimension $width $height )
    (if Begin
        (setq $p1 Begin $p2 End)
      (if (region-active-p)
          (setq $p1 (region-beginning) $p2 (region-end))
        (save-excursion
          (skip-chars-backward $skipChars)
          (setq $p1 (point))
          (goto-char $p0)
          (skip-chars-forward $skipChars)
          (setq $p2 (point)))))
    (setq $input (buffer-substring-no-properties $p1 $p2))
    (when (not (xah-html--image-file-ext-p $input)) (user-error "file name [%s] does not have image file extension" $input))
    (setq $imgPath (xah-html-local-url-to-file-path $input))
    (setq $dimension (xah-html-image-dimensions $imgPath))
    (setq $width (number-to-string (elt $dimension 0)))
    (setq $height (number-to-string (elt $dimension 1)))
    (delete-region $p1 $p2)
    (insert (format "<a class=\"bigImg\" href=\"%s\">%s×%s</a>" (file-relative-name $imgPath) $width $height ))))

(defun xah-html--image-alt-string (Path)
  "return a image alt string based on Path.
Version 2021-09-01"
  (replace-regexp-in-string
   "_" " "
   (replace-regexp-in-string
    "\\.[A-Za-z]\\{3,4\\}$" "" (file-name-nondirectory Path) t t) t t))

(defun xah-html-image-to-img-tag (&optional Begin End Width Height AltString)
  "Replace image file path under cursor to HTML img tag.
Example:
 img/my_cats.jpg
become
 <img src=\"img/my_cats.jpg\" alt=\"my cats\" width=\"470\" height=\"456\" />

If there is a selection, use that as input path.

If `univers-argument' is called before, don't width and height attribute.
Returns the string used in the alt attribute.

URL `http://ergoemacs.org/emacs/elisp_image_tag.html'
Version 2021-09-01 2021-10-01"
  (interactive)
  (let* (($bds (if Begin nil (xah-get-bounds-of-thing-or-region 'filepath)))
         ($p1 (if Begin Begin (car $bds)))
         ($p2 (if End End (cdr $bds)))
         ($input (buffer-substring-no-properties $p1 $p2 ))
         ($imgPath
          (if (fboundp 'xahsite-web-path-to-filepath)
              (xahsite-web-path-to-filepath
               (xah-html-local-url-to-file-path
                $input))
            $input))
         $hrefValue $altText )
    (when (not (file-exists-p $imgPath)) (user-error "file not exist at %s" $imgPath))
    (setq $hrefValue
          (file-relative-name
           $imgPath
           (file-name-directory (or (buffer-file-name) default-directory))))
    (setq $altText (if AltString AltString (xah-html--image-alt-string $imgPath)))
    (if current-prefix-arg
        (progn
          (delete-region $p1 $p2)
          (insert (format "<img src=\"%s\" alt=\"%s\" />" $hrefValue $altText)))
      (let* (($WH (if Width nil (xah-html-image-dimensions $imgPath)))
             ($width (if Width Width (number-to-string (elt $WH 0))))
             ($height (if Height Height (number-to-string (elt $WH 1)))))
        (delete-region $p1 $p2)
        (insert
         (if (or (equal $width "0") (equal $height "0"))
             (format "<img src=\"%s\" alt=\"%s\" />" $hrefValue $altText)
           (format "<img src=\"%s\" alt=\"%s\" width=\"%s\" height=\"%s\" />" $hrefValue $altText $width $height)))))
    $altText
    ))

(defun xah-html-wrap-figure-tag (&optional Begin End Figcaption)
  "Wrap <figure> tag around Begin End, also add <figcaption>.
If no Begin End are given, use current line.

<figure>
<img src=\"cat.png\" alt=\"cat\" width=\"707\" height=\"517\" />
<figcaption>▮</figcaption>
</figure>

If there is a selection, use that as image path.

Version 2019-11-15 2021-08-27"
  (interactive)
  (let ($p1 $p2 ($figcapStr (if Figcaption Figcaption "" )))
    (if (and Begin End)
        (setq $p1 Begin $p2 End)
      (progn
        (setq $p1 (line-beginning-position) $p2 (line-end-position))))
    (goto-char $p2)
    (insert "\n<figcaption>\n")
    (insert $figcapStr "\n</figcaption>\n</figure>\n\n")
    (goto-char $p1)
    (insert "\n<figure>\n")
    (search-forward "</figcaption>" nil t)
    (goto-char (1- (match-beginning 0)))))

(defun xah-html-image-path-to-figure-tag ()
  "Replace a image file's path under cursor with a HTML img tag,
and wrap it with “figure” and “figcaption” tags.
Example,

i/cat.png

become

<figure>
<img src=\"cat.png\" alt=\"cat\" width=\"707\" height=\"517\" />
<figcaption>▮</figcaption>
</figure>

If there is a selection, use that as image path.
This function calls `xah-html-image-to-img-tag'.
Version 2019-11-15 2021-07-31 2021-09-01"
  (interactive)
  (let (($alt (xah-html-image-to-img-tag)))
    (search-backward "<img ")
    (insert "\n<figure>\n")
    (search-forward ">")
    (insert "\n<figcaption>\n")
    (insert $alt "\n</figcaption>\n</figure>\n\n")))

(defun xah-html-css-path-to-link ()
  "Make the path under cursor into a HTML link.
 e.g. ~/web/lit.css
becomes
<link rel=\"stylesheet\" href=\"lit.css\" />
Version 2018-01-30 2021-08-18"
  (interactive)
  (let* (
         ($bds (xah-get-bounds-of-thing-or-region 'filepath))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($inputStr (buffer-substring-no-properties $p1 $p2))
         ($src (if (string-match "^http" $inputStr ) $inputStr (file-relative-name $inputStr))))
    (delete-region $p1 $p2)
    (insert (format "<link rel=\"stylesheet\" href=\"%s\" />" $src))))

(defun xah-html-js-path-to-link ()
  "Make the path under cursor into a HTML link.
 eg <script src=\"xyz.js\"></script>
Version 2016-10-31"
  (interactive)
  (let* (
         ($bds (xah-get-bounds-of-thing-or-region 'filepath))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($inputStr (buffer-substring-no-properties $p1 $p2))
         ($src
          (if (string-match "^http" $inputStr )
              $inputStr
            (file-relative-name $inputStr))))
    (delete-region $p1 $p2)
    (insert (format "<script defer src=\"%s\"></script>" $src))))

(defun xah-html-pdf-path-to-embed ()
  "Make the path under cursor into a embedded pdf.
e.g. math.pdf
becomes
<embed src=\"%s\" type=\"application/pdf\" style=\"width:100%;height:95vh\" />
Version 2019-07-29 2021-08-11"
  (interactive)
  (let ( $p1 $p2 $input $src )
    (let (($bds (xah-get-bounds-of-thing-or-region 'filepath))) (setq $p1 (car $bds) $p2 (cdr $bds)))
    (setq $input (buffer-substring-no-properties $p1 $p2))
    (setq $src (if (string-match "^http" $input ) $input (file-relative-name $input)))
    (delete-region $p1 $p2)
    (insert (format "<embed src=\"%s\" type=\"application/pdf\" style=\"width:100%%;height:1000px\" />" $src))))

(defun xah-html-pdf-path-to-link ()
  "Make the pdf file path under cursor into a link.
e.g.
 doc/cat.pdf
becomes
 <a href=\"doc/cat.pdf\">cat.pdf</a>
Version 2017-09-13 2021-08-13"
  (interactive)
  (let ( $p1 $p2 $input $fname $src )
    (let (($bds (xah-get-bounds-of-thing-or-region 'filepath))) (setq $p1 (car $bds) $p2 (cdr $bds)))
    (setq $input (buffer-substring-no-properties $p1 $p2))
    (setq $fname (file-name-nondirectory $input))
    (setq $src (if (string-match "^http" $input ) $input (file-relative-name $input)))
    (delete-region $p1 $p2)
    (insert (format "<a href=\"%s\">%s</a>" $src $fname))))

(defun xah-html-audio-file-embed ( &optional Figure)
  "Make the path under cursor into a HTML audio tag link.
xyz.mp4 becomes <audio src=\"i/xyz.m4a\" controls loop></audio>
if Figure is not nil, wrap figure and figcaption tags around it.
Returns a alt string based on the file name.
Version 2020-01-19 2021-08-11"
  (interactive)
  (let ( $p1 $p2 $input $src)
    (let (($bds (xah-get-bounds-of-thing-or-region 'filepath))) (setq $p1 (car $bds) $p2 (cdr $bds)))
    (setq $input (buffer-substring-no-properties $p1 $p2 ))
    (setq $src
     (if (string-match "^http" $input )
         $input
       (if (file-exists-p $input)
           (file-relative-name $input)
         (user-error "file not found: [%s]" $input))))
    (delete-region $p1 $p2)
    (if Figure
        (progn
          (goto-char $p1)
          (insert "\n<figure>\n")
          (insert (format "<audio src=\"%s\" controls loop></audio>\n" $src))
          (insert "<figcaption>\n")
          (insert (replace-regexp-in-string "_" " " (file-name-sans-extension (file-name-nondirectory $src))))
          (insert "\n</figcaption>\n</figure>\n\n")
          (search-backward "</figcaption>" ))
      (progn
        (insert (format "<audio src=\"%s\" controls loop></audio>" $src))))))

(defun xah-html-video-file-embed ( &optional Figure)
  "Make the path under cursor into a HTML video tag link.
e.g. xyz.mp4
becomes
<video src=\"i/xyz.mp4\" controls loop></video>

Returns a alt string based on the file name.

Version 2020-01-19 2021-08-29"
  (interactive)
  (let* (
         ($bds (xah-get-bounds-of-thing 'filepath ))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($input (buffer-substring-no-properties $p1 $p2 ))
         ($src
          (if (string-match "^http" $input )
              $input
            (if (file-exists-p $input)
                (file-relative-name $input)
              (user-error "file not found: [%s]" $input)))))
    (delete-region $p1 $p2)
    (if Figure
        (progn
          (goto-char $p1)
          (insert "\n<figure>\n")
          (insert (format "<video src=\"%s\" controls loop></video>\n" $src))
          (insert "<figcaption>\n")
          (insert (replace-regexp-in-string "_" " " (file-name-sans-extension (file-name-nondirectory $src))))
          (insert "\n</figcaption>\n</figure>\n\n")
          (search-backward "</figcaption>" ))
      (progn
        (insert (format "<video src=\"%s\" controls loop></video>" $src))))))

(defun xah-html-word-to-wikipedia-link ()
  "Make the current word or selection into a Wikipedia link.
For Example:
 Emacs
becomes
 <a href=\"http://en.wikipedia.org/wiki/Emacs\">Emacs</a>

URL `http://ergoemacs.org/emacs/elisp_html_word_to_wikipedia_linkify.html'
Version 2015-07-27 2021-09-17"
  (interactive)
  (let* (($p0 (point))
         ($p1 (if (region-active-p)
                  (region-beginning)
                (progn (skip-chars-backward "^ \t\n") (point))))
         ($p2 (if (region-active-p)
                  (region-end)
                (progn (goto-char $p0)
                       (skip-chars-forward "^ \t\n")
                       (point))))
         ($input (buffer-substring-no-properties $p1 $p2))
         ($linkText (replace-regexp-in-string "_" " " $input)))
    (delete-region $p1 $p2)
    (insert
     (format "<a href=\"http://en.wikipedia.org/wiki/%s\">%s</a>" (replace-regexp-in-string " " "_" $linkText) $linkText))))

(defun xah-html-wolfram-ref-to-link ()
  "Make a Wolfram reference url to link with symbol name as link text.
For example
https://reference.wolfram.com/language/ref/Table.html
becomes
<span class=\"ref\"><a href=\"https://reference.wolfram.com/language/ref/Table.html\">Table</a></span>
Version 2021-07-25 2021-08-13"
  (interactive)
  (let ( $p1 $p2 $url $keyword)
    (let (($bds (xah-get-bounds-of-thing-or-region 'filepath))) (setq $p1 (car $bds) $p2 (cdr $bds)))
    (setq $url (buffer-substring-no-properties $p1 $p2))
    (setq $keyword
          (if (string-match "\\([A-Z][A-Za-z0-9]+\\)\\.html$" $url)
              (match-string-no-properties 1 $url)
            (user-error "cannot find the keyword in url [%s]" $url)))
    (delete-region $p1 $p2)
    (insert "<span class=\"ref\"><a href=\"" $url "\">" $keyword "</a></span>")))

(defun xah-html-wolfram-word-to-link ()
  "Make the current word into a link to Wolfram Language ref site.
For example, if the cursor is on the line:
Table
Then it'll become:
<span class=\"ref\"><a href=\"https://reference.wolfram.com/language/ref/Table.html\">Table</a></span>

Version 2021-07-25 2021-07-26"
  (interactive)
  (let ($bds $p1 $p2 $swd $url)
    (setq $bds (xah-get-bounds-of-thing-or-region ["$A-Za-z0-9" "$A-Za-z0-9"]))
    (setq $p1 (car $bds))
    (setq $p2 (cdr $bds))
    (setq $swd (buffer-substring-no-properties $p1 $p2))
    (setq $url (format "https://reference.wolfram.com/language/ref/%s.html" $swd))
    (delete-region $p1 $p2)
    (insert "<span class=\"ref\"><a href=\"" $url "\">" $swd "</a></span>")))

(defun xah-html-amazon-url-to-link (&optional TrackingID)
  "Make the current amazon URL or selection into a link.

Examples of amazon product URL formats
https://www.amazon.com/Cyborg-R-T-Gaming-Mouse/dp/B003CP0BHM/ref=pd_sim_e_1
https://www.amazon.com/gp/product/B003CP0BHM
https://www.amazon.com/exec/obidos/ASIN/B003CP0BHM/xahh-20
https://www.amazon.com/exec/obidos/tg/detail/-/B003CP0BHM/
https://www.amazon.com/dp/B003CP0BHM?tag=xahhome-20
https://amzn.to/1F5M1hA
https://alexa.design/2okfMcj

Example output:
<a href=\"https://www.amazon.com/dp/B003CP0BHM/?tag=xahh-20\" title=\"Cyborg R T Gaming Mouse\">amazon</a>

ASIN is a 10 character string that's a product id.

URL `http://ergoemacs.org/emacs/elisp_amazon-linkify.html'
Version 2020-01-15 2021-05-02 2021-08-29"
  (interactive)
  (let (($bds ( xah-get-bounds-of-thing 'url))
        $p1 $p2 $url $asin $thingName
        ($trackId (if TrackingID TrackingID "xahh-20" )))
    (if (region-active-p)
        (setq $p1 (region-beginning) $p2 (region-end))
      (setq $p1 (car $bds) $p2 (cdr $bds)))
    (setq $url (buffer-substring-no-properties $p1 $p2))
    (if (or (string-match "//amzn.to/" $url)
            (string-match "//alexa.design/" $url))
        (progn (delete-region $p1 $p2)
               (insert (format "<a class=\"amz_search\" href=\"%s\">amazon</a>" $url)))
      (progn
        (setq $asin
              (cond
               ((string-match "/dp/\\([[:alnum:]]\\{10\\}\\)/?" $url) (match-string-no-properties 1 $url))
               ((string-match "/dp/\\([[:alnum:]]\\{10\\}\\)\\?tag=" $url) (match-string-no-properties 1 $url))
               ((string-match "/gp/product/\\([[:alnum:]]\\{10\\}\\)" $url) (match-string-no-properties 1 $url))
               ((string-match "/ASIN/\\([[:alnum:]]\\{10\\}\\)" $url) (match-string-no-properties 1 $url))
               ((string-match "/tg/detail/-/\\([[:alnum:]]\\{10\\}\\)/" $url) (match-string-no-properties 1 $url))
               ((string-match "/\\([[:alnum:]]\\{10\\}\\)/" $url) (match-string-no-properties 1 $url))
               ((and
                 (equal 10 (length $url ))
                 (string-match "\\`\\([[:alnum:]]\\{10\\}\\)\\'" $url))
                $url)
               (t (error "no amazon ASIN found"))))
        (setq
         $thingName
         (replace-regexp-in-string
          "-" " "
          (if (string-match "amazon\.com/\\([^/]+?\\)/dp/" $url)
              (progn (match-string-no-properties 1 $url))
            (progn
              (message "no product name found" ))
            ""
            )))
        (delete-region $p1 $p2)
        (insert
         (format "<a class=\"amz\" href=\"https://www.amazon.com/dp/%s/?tag=%s\" title=\"%s\">Buy at amazon</a>" $asin $trackId $thingName))
        (search-backward "\">")))))

(defun xah-html-youtube-url-embed ()
  "Make the current line of youtube url into a embeded video.

The line can be any of

 https://www.youtube.com/watch?v=gjiAjtGzC64
 https://www.youtube.com/watch?v=gjiAjtGzC64?t=198
 https://youtu.be/gjiAjtGzC64
 https://www.youtube.com/embed/gjiAjtGzC64
 gjiAjtGzC64

Here's sample result:

<figure>
<iframe width=\"640\" height=\"480\" src=\"https://www.youtube.com/embed/gjiAjtGzC64\" allowfullscreen></iframe>
<figcaption>
</figcaption>
</figure>

URL `http://ergoemacs.org/emacs/elisp_embed_youtube_vid.html'
Version 2020-08-27 2021-08-25"
  (interactive)
  (let ( $p1 $p2 $input $id $timeStamp )
    (re-search-backward "[ \n]")
    (forward-char )
    (setq $p1 (point))
    (re-search-forward "[ \n]" )
    (setq $p2 (point))
    (setq $input (buffer-substring-no-properties $p1 $p2))
    (setq $timeStamp
          (if (or
               (string-match "t=\\([0-9]+\\)" $input )
               (string-match "time_continue=\\([0-9]+\\)" $input ))
              (match-string-no-properties 1 $input)
            ""))
    (setq $id (xah-html--get-youtube-id $input))
    (delete-region $p1 $p2)
    (insert
     (format "

<figure>
<iframe width=\"640\" height=\"480\" src=\"https://www.youtube.com/embed/%s%s\" allowfullscreen></iframe>
<figcaption>
</figcaption>
</figure>

"
             $id
             (if (string-equal $timeStamp "")
                 ""
               (concat "?start=" $timeStamp))))
    (search-backward "</figcaption>" )
    (backward-char 1)))

(defun xah-html-local-file-to-link (&optional Begin End)
  "Make the path under cursor into a link with relative path.

For Example,
 ../emacs/emacs.html
becomes
 <a href=\"../emacs/emacs.html\">Emacs Tutorial</a>
The link text is from the title tag of the file if exists.

If there is selection, use it as file path.
The input file path can be a full path or relative path.

Version 2017-12-20 2021-10-17"
  (interactive)
  (let* (($bds (if (and Begin End) nil (xah-get-bounds-of-thing-or-region 'filepath)))
         ($p1 (if Begin Begin (car $bds)))
         ($p2 (if End End (cdr $bds)))
         ($input
          (xah-html-local-url-to-file-path (buffer-substring-no-properties $p1 $p2)))
         ($inputParts (xah-html-split-uri-hashmark $input))
         ($pt1 (aref $inputParts 0))
         ($fragPart (aref $inputParts 1))
         ($fPath (expand-file-name $pt1 default-directory)))
    (if (file-exists-p $fPath)
        (let* (($rPath (file-relative-name $fPath (file-name-directory (or (buffer-file-name) default-directory))))
               ($title
                (if (string-match-p ".+html\\'" $fPath)
                    (concat (xah-html-get-html-file-title $fPath t) $fragPart)
                  (file-name-nondirectory $fPath)))
               ($result
                (format "<a href=\"%s\">%s</a>"
                        (concat $rPath $fragPart)
                        (if (string-equal $title "") $rPath $title))))
          (delete-region $p1 $p2)
          (insert $result))
      (progn (message "Error ZNh85. File not exit: [%s]" $fPath)))))

(defun xah-html-wikipedia-url-to-link ()
  "Change Wikipedia URL under cursor into a HTML link.
If there is a selection, use that as input.

Example:
http://en.wikipedia.org/wiki/Emacs
becomes
<a href=\"http://en.wikipedia.org/wiki/Emacs\" data-accessed=\"2015-09-14\">Emacs</a>.

Works the same way for links to wiktionary, e.g. https://en.wiktionary.org/wiki/%E4%BA%86

URL `http://ergoemacs.org/emacs/elisp_html_wikipedia_url_linkify.html'
Version 2020-03-24 2021-05-02 2021-08-10"
  (interactive)
  (let ( $p1 $p2 $input $linkText $output )
    (if (region-active-p)
         (setq $p1 (region-beginning) $p2 (region-end))
      (progn
        (let ($p0)
          (progn
            (setq $p0 (point))
            (skip-chars-backward "^ \t\n<>[]")
            (setq $p1 (point))
            (goto-char $p0)
            (skip-chars-forward "^ \t\n<>[]")
            (setq $p2 (point))))))
    (setq $input (buffer-substring-no-properties $p1 $p2))
    (require 'url-util)
    (setq $linkText
          (replace-regexp-in-string
           "_" " "
           (decode-coding-string (url-unhex-string (file-name-nondirectory $input)) 'utf-8)))
    (setq $output
          (format
           "<a href=\"%s\" data-accessed=\"%s\">%s</a>"
           (url-encode-url $input)
           (format-time-string "%Y-%m-%d")
           $linkText
           ))
    (progn
      (delete-region $p1 $p2)
      (insert $output))))

(defun xah-html-emacs-ref-to-link ()
  "Make the current line or selection into a emacs reference link.
For example, if the cursor is any one of the line:
 (elisp) The Mark
 file:///Users/xah/web/ergoemacs_org/emacs_manual/elisp/The-Mark.html#The-Mark
 file:///Users/xah/web/ergoemacs_org/emacs_manual/elisp/The-Mark.html
                http://ergoemacs.org/emacs_manual/elisp/The-Mark.html
                 ~/web/ergoemacs_org/emacs_manual/elisp/The-Mark.html
      c:/Users/xah/web/ergoemacs_org/emacs_manual/elisp/The-Mark.html
                               ../emacs_manual/elisp/The-Mark.html
become:
<span class=\"ref\"><a href=\"…\">(info \"(elisp) The Mark\")</a></span>
Version 2016-12-22 2021-08-27 2021-09-13"
  (interactive)
  (require 'subr-x)
  (let* (($bds (xah-get-bounds-of-thing-or-region 'url))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($url (string-trim (buffer-substring-no-properties $p1 $p2)))
         ($url2 (replace-regexp-in-string "_002d" "-" (replace-regexp-in-string "-" " " $url t t) t t))
         ($node
          (cond
           ((string-match "/elisp/\\([ -A-Za-z0-9]+\\).html" $url2)
            (vector "elisp" (match-string-no-properties 1 $url2)))
           ((string-match "/emacs/\\([ -A-Za-z0-9]+\\).html" $url2)
            (vector "emacs" (match-string-no-properties 1 $url2)))
           ((string-match "(elisp) \\([ -A-Za-z0-9]+\\)$" $url2)
            (vector "elisp" (match-string-no-properties 1 $url2)))
           ((string-match "(emacs) \\([ -A-Za-z0-9]+\\)$" $url2)
            (vector "emacs" (match-string-no-properties 1 $url2)))
           (t (user-error "can't identify the node name in: %s" $url2))))
         ($linkText (format "(info \"(%s) %s\")" (aref $node 0) (aref $node 1)))
         $newPath)
    (if (string-match "xah/web/ergoemacs_org/" $url)
        (let ((x (aref $node 0))
              (y (xah-replace-pairs-in-string (aref $node 1) [ ["-" "_002d"] [" " "-"] ])))
          (setq $newPath (format "c:/Users/xah/web/ergoemacs_org/emacs_manual/%s/%s.html" x y))
          (if (file-exists-p $newPath)
              (progn
                (delete-region $p1 $p2)
                (insert "<span class=\"ref\"><a href=\""
                        (file-relative-name $newPath (file-name-directory (buffer-file-name)))
                        "\">" $linkText "</a></span>"))
            (error "$newPath does not point to a file: %s" $newPath)))
      (progn
        (delete-region $p1 $p2)
        (insert "<span class=\"ref\"><a href=\"" $url "\">" $linkText "</a></span>")))))

(defvar xah-html-any-to-link-pre-hook nil "Hook for `xah-html-any-to-link'. Functions in the hook will be called in order, each given 2 args, the path and current html file path. The first return non-nil, its value is given to `xah-html-any-to-link' as path to be linked. This is useful for transforming certain href/src value before creating a link to it.")

(defun xah-html-any-to-link ()
  "Make the text under cursor into a HTML link.

If region is active, use it as input.
Functions in `xah-html-any-to-link-pre-hook' is called first to transform the link, as user customization.

This command calls one of the following:
`xah-html-url-to-dated-link'
`xah-html-wikipedia-url-to-link'
`xah-html-css-path-to-link'
`xah-html-pdf-path-to-link'
`xah-html-js-path-to-link'
`xah-html-audio-file-embed'
`xah-html-video-file-embed'
`xah-html-youtube-url-embed'
`xah-html-amazon-url-to-link'
`xah-html-wolfram-ref-to-link'
`xah-html-image-path-to-figure-tag'
`xah-html-emacs-ref-to-link'
`xah-html-local-file-to-link'
`xah-html-url-to-link'

Version 2020-08-07 2021-08-13 2021-09-04 2021-10-17"
  (interactive)
  (let* (($bds (xah-get-bounds-of-thing-or-region 'filepath))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($rawInput (buffer-substring-no-properties $p1 $p2))
         ($input (xah-html-local-url-to-file-path
                  (if (> (length xah-html-any-to-link-pre-hook) 0)
                      (let (($x (run-hook-with-args-until-success 'xah-html-any-to-link-pre-hook $rawInput (or (buffer-file-name) default-directory))))
                        (if $x $x $rawInput))
                    $rawInput)))
         ;;
         )
    ;; (if (string-match "%" $input )
    ;;     (decode-coding-string (url-unhex-string "https://mysticsiva.wordpress.com/2016/11/04/%E3%82%AD%E3%83%BC%E3%82%AD%E3%83%A3%E3%83%83%E3%83%97%E4%BA%A4%E6%8F%9B3/") 'utf-8)
    ;;   $input)
    (delete-region $p1 $p2)
    (insert $input)
    (message "$input is %s" $input)
    (cond
     ((or (string-match-p "wikipedia.org/" $input)
          (string-match-p "wiktionary.org/" $input)
          (string-match-p "wikimedia.org/" $input))
      (if (xah-html--image-file-ext-p $input)
          (xah-html-url-to-dated-link)
        (xah-html-wikipedia-url-to-link)))
     ((string-match-p "\\.css\\'" $input) (xah-html-css-path-to-link))
     ((string-match-p "\\.pdf" $input) (xah-html-pdf-path-to-link))
     ((string-match-p "\\.js\\'\\|\\.ts\\'" $input) (xah-html-js-path-to-link))
     ((xah-html-audio-file-suffix-p $input)
      (xah-html-audio-file-embed t))
     ((xah-html-video-file-suffix-p $input)
      (xah-html-video-file-embed t))
     ((or (string-match-p "youtu\.be/" $input) (string-match-p "youtube\.com/" $input))
      (xah-html-youtube-url-embed))
     ((string-match-p "www\.amazon\.com/\\|//amzn\.to/" $input)
      (xah-html-amazon-url-to-link))
     ((string-match-p "reference\.wolfram\.com" $input)
      (xah-html-wolfram-ref-to-link))
     ((string-match-p "/emacs/manual/\\|/emacs_manual/" $input)
      (xah-html-emacs-ref-to-link))
     ((string-match-p "\\`https?://" $input)
      (xah-html-url-to-dated-link))
     ((xah-html--image-file-ext-p $input) (xah-html-image-path-to-figure-tag))
     ((file-exists-p $input)
      (xah-html-local-file-to-link))
     (t (xah-html-url-to-link)))
    ;;
    ))

(defun xah-html-url-to-link ()
  "Make the URL at cursor point into a link.

For example,
http://example.org/t.html
becomes
<a href=\"http://example.org/t.html\">http://example.org/t.html</a>

If text under cursor is a file path, use relative path for href value.

URL `http://ergoemacs.org/emacs/wrap-url.html'
Version 2006-10-30 2021-05-18 2021-08-13"
  (interactive)
  (let ( $p1 $p2 $input $newStr )
    (let (($bds (xah-get-bounds-of-thing-or-region 'filepath))) (setq $p1 (car $bds) $p2 (cdr $bds)))
    (setq $input (buffer-substring-no-properties $p1 $p2))
    (setq $newStr
          (if (file-exists-p (replace-regexp-in-string "^file:///" "/" $input t t))
              (file-relative-name $input)
            $input
            ))
    (delete-region $p1 $p2)
    (insert (format "<a href=\"%s\">%s</a>" $newStr $newStr ))))

(defun xah-html-url-to-dated-link ()
  "Change URL under cursor into a link with data-accessed attribute.
If there is a selection, use the selection as input.
Example:
http://example.com/x.htm
becomes
<a href=\"http://example.com/x.htm\" data-accessed=\"2008-12-25\">http://example.com/x.htm</a>

URL `http://ergoemacs.org/emacs/elisp_html-linkify.html'
Version 2008-12-25 2021-09-11"
  (interactive)
  (let* (($bds (xah-get-bounds-of-thing-or-region 'filepath))
        ($p1 (car $bds))
        ($p2 (cdr $bds))
        ($input (buffer-substring-no-properties $p1 $p2)))
    (delete-region $p1 $p2)
    (insert (format
             "<a href=\"%s\" data-accessed=\"%s\">%s</a>"
             $input (format-time-string "%Y-%m-%d") $input
             ))))

(defun xah-html-blocks-to-paragraph ()
  "Add p tag to current block or selection.
If there is a selection, wrap p around each block.
After this command is called, press space to repeat it.

URL `http://ergoemacs.org/emacs/emacs_html_wrap_tags.html'
Version 2019-06-21 2021-09-11"
  (interactive)
  (let* (($bds (xah-get-bounds-of-thing-or-region 'block))
         ($p1 (car $bds))
         ($p2 (cdr $bds)))
    (save-restriction
      (narrow-to-region $p1 $p2)
      (goto-char (point-min))
      (insert "<p>\n")
      (goto-char (point-min))
      (while (re-search-forward "\n\n+" nil t) (replace-match "</p>\n\n<p>" t t))
      (goto-char (point-max))
      (insert "\n</p>"))
    (skip-chars-forward "\n"))
  (set-transient-map (let (($kmap (make-sparse-keymap))) (define-key $kmap (kbd "SPC") 'xah-html-blocks-to-paragraph) $kmap)))

(defun xah-html-insert-br-tag ()
  "Insert a br tag, or add to end of all lines in selection.
Space before are removed.
Version 2020-11-22 2021-05-15 2021-08-13 2021-09-10"
  (interactive)
  (let ($p1 $p2)
    (if (region-active-p)
        (progn
          (setq $p1 (region-beginning) $p2 (region-end))
          (save-restriction
            (narrow-to-region $p1 $p2)
            (goto-char (point-min))
            (while (re-search-forward " *\n" nil t )
              (replace-match "<br />\n"))))
      (progn
        (delete-char (- (skip-chars-backward " " )))
        (insert "<br />")))))

(defun xah-html-corner-bracket-to-elisp-markup (Begin End)
  "Replace corner bracketed words to HTML markup, in current line or selection.
Example:
 「sort-lines」
    becomes
  <code class=\"elisp_f\">sort-lines</code>

Note: a word is changed only if all of the following are true:
• `fboundp' or `boundp' on the bracketed text returns true.
• symbol string's char contains only alphanumeric or hyphen, even though elisp identifier allows many other chars. e.g. `yas/reload-all', `color-cie-ε'.

This command also makes a report of changed items.

Some issues:
• Some words are common in other lang, e.g. while, print, string, find, grep, kbd, etc. But they are also built-in elisp symbols. This command will tag them, but you may not want that.
• Some function/variable are from 3rd party libs, and some are not bundled with GNU emacs , e.g. 'htmlize. They may or may not be tagged depending whether they've been loaded.
When called in lisp code, Begin End are region begin/end positions.

Version 2017-03-17 2021-06-18 2021-08-30 2021-09-25"
  (interactive
   (if (region-active-p)
       (list (region-beginning) (region-end))
     (list (line-beginning-position) (line-end-position))))
  (let ($name $p1 $p2 $sym)
    (save-excursion
      (save-restriction
        (narrow-to-region Begin End)
        (progn
          (goto-char (point-min))
          (while (re-search-forward "「\\([:-A-Za-z0-9]+\\)」" (point-max) t)
            (setq $name (match-string-no-properties 1)
                  $sym (intern-soft $name)
                  $p1 (match-beginning 0)
                  $p2 (match-end 0))
            (if $sym
                (cond
                 ((fboundp $sym)
                  (progn
                    (overlay-put (make-overlay (1+ $p1) (1- $p2)) 'face 'highlight)
                    (goto-char $p2)
                    (delete-char -1)
                    (insert "</code>")
                    (goto-char $p1)
                    (insert "<code class=\"elisp_f\">")
                    (delete-char 1)))
                 ((boundp $sym)
                  (progn
                    (overlay-put (make-overlay (1+ $p1) (1- $p2)) 'face 'highlight)
                    (goto-char $p2)
                    (delete-char -1)
                    (insert "</var>")
                    (goto-char $p1)
                    (insert "<var class=\"elisp\">")
                    (delete-char 1))))
              nil
              )))))))

(defun xah-html-bracket-to-markup (Begin End)
  "Replace bracketed text to HTML markup in current line or selection.

• 「…」 → <code>…</code> or <code class=\"elisp_f\">...</code> if current file path contains “emacs”.
• 〈…〉 → <cite>…</cite>
• 《…》 → <cite>…</cite>
• 〔…〕 → <code class=\"path_xl\">\\1</code>
•  ‹…› → <var class=\"d\">…</var>
• [<a href=] → [see <a href=]

When called in lisp code, Begin End are region begin/end positions.
Version 2019-09-11 2021-06-18"
  (interactive (let (($bds (xah-get-bounds-of-thing-or-region 'block)))
    (list (car $bds) (cdr $bds))))
  (save-excursion
    (save-restriction
      (narrow-to-region Begin End)
      (when (and (buffer-file-name) (string-match "emacs" (buffer-file-name)))
        (xah-html-corner-bracket-to-elisp-markup Begin End))
      (progn
        (goto-char (point-min))
        (while (re-search-forward "「\\([^」]+?\\)」" nil t)
          (save-restriction
            (narrow-to-region (match-beginning 0) (match-end 0))
            (goto-char (point-min))
            (delete-char 1)
            (goto-char (point-max))
            (delete-char -1)
            (xah-html-encode-ampersand-region (point-min) (point-max))
            (goto-char (point-min))
            (insert "<code>")
            (overlay-put (make-overlay (point) (point-max)) 'face 'highlight)
            (goto-char (point-max))
            (insert "</code>"))))
      (progn
        (goto-char (point-min))
        (while (re-search-forward "〈\\([^〉]+?\\)〉" nil t)
          (overlay-put (make-overlay (match-beginning 1) (match-end 1)) 'face 'highlight)
          (goto-char (match-end 1))
          (delete-char 1)
          (insert "</cite>")
          (goto-char (match-beginning 0))
          (insert "<cite>")
          (delete-char 1)))
      (progn
        (goto-char (point-min))
        (while (re-search-forward "《\\([^》]+?\\)》" nil t)
          (overlay-put (make-overlay (match-beginning 1) (match-end 1)) 'face 'highlight)
          (goto-char (match-end 1))
          (delete-char 1)
          (insert "</cite>")
          (goto-char (match-beginning 0))
          (insert "<cite>")
          (delete-char 1)))
      (progn
        (goto-char (point-min))
        (while (re-search-forward "‹\\([^›]+?\\)›" nil t)
          (overlay-put (make-overlay (match-beginning 1) (match-end 1)) 'face 'highlight)
          (goto-char (match-end 1))
          (delete-char 1)
          (insert "</var>")
          (goto-char (match-beginning 0))
          (insert "<var class=\"d\">")
          (delete-char 1)))
      (progn
        (goto-char (point-min))
        (while (re-search-forward "〔\\([^〕]+?\\)〕" nil t)
          (overlay-put (make-overlay (match-beginning 1) (match-end 1)) 'face 'highlight)
          (goto-char (match-end 1))
          (delete-char 1)
          (insert "</code>")
          (goto-char (match-beginning 0))
          (insert "<code class=\"path_xl\">")
          (delete-char 1)))
      (progn
        (goto-char (point-min))
        (while (re-search-forward "\\(‹…›\\)" nil t)
          (replace-match "<var class=\"d\">\\1</var>" t)
          (let ($p1 $p2)
            (search-backward "</var>")
            (setq $p2 (point))
            (search-backward "<var class=\"d\">")
            (search-forward "<var class=\"d\">")
            (setq $p1 (point))
            (overlay-put (make-overlay $p1 $p2) 'face 'highlight)
            (search-forward "</var>"))))
      (progn
        (goto-char (point-min))
        (while (search-forward "[<a href=" nil t)
          (goto-char (1+ (match-beginning 0)))
          (insert "see ")
          (overlay-put (make-overlay (1+ (match-beginning 0)) (1- (point))) 'face 'highlight))))))

(defun xah-html-emacs-to-windows-kbd-notation (&optional Begin End)
  "Change emacs key notation to Windows's notation on selection or current line.

For example:
 C-h f → Ctrl+h f
 M-a → Alt+a
 <f9> <f8> → F9 F8
And a special W for Window.
 W-a → Win+a

This command will do most emacs syntax correctly, but not 100% correct, especially on notations like <C-M-down>. But works if it's written as C-M-<down>

When called in lisp code, Begin End are region begin/end positions.
Version 2017-09-30 2021-02-03 2021-09-19"
  (interactive)
  (let (($p1 (if Begin Begin (if (region-active-p) (region-beginning) (line-beginning-position))))
        ($p2 (if End End (if (region-active-p) (region-end) (line-end-position)))))
    (xah-replace-pairs-region
     $p1 $p2
     [
      ["<prior>" "PageUp"]
      ["<next>" "PageDown"]
      ["<home>" "Home"]
      ["<end>" "End"]
      ["<f1>" "F1"] ["<f2>" "F2"] ["<f3>" "F3"] ["<f4>" "F4"] ["<f5>" "F5"] ["<f6>" "F6"] ["<f7>" "F7"] ["<f8>" "F8"] ["<f9>" "F9"] ["<f10>" "F10"] ["<f11>" "F11"] ["<f12>" "F12"]
      ["<return>" "Return"]
      ["<tab>" "Tab"]
      ["<escape>" "Escape"]
      ["<right>" "→"]
      ["<left>" "←"]
      ["<up>" "↑"]
      ["<down>" "↓"]
      ["<insert>" "Insert"]
      ["<delete>" "Delete"]
      ["<backspace>" "Backspace"]
      ["<menu>" "Menu"]
      ] nil t)
    (xah-replace-regexp-pairs-region
     $p1 $p2
     [
      ["<C-\\(.\\)>" "C-<\\1>"]
      ["<C-s-\\(.\\)>" "C-s-<\\1>"]
      ["<M-\\(.\\)>" "M-<\\1>"]
      ["<M-s-\\(.\\)>" "M-s-<\\1>"]
      ["\\bC-\\(.\\)" "Ctrl+\\1"]
      ["\\bM-\\(.\\)" "Alt+\\1"]
      ["\\bA-\\(.\\)" "Alt+\\1"]
      ["\\bS-\\(.\\)" "Shift+\\1"]
      ["\\bs-\\(.\\)" "Super+\\1"]
      ["\\bH-\\(.\\)" "Hyper+\\1"]
      ["\\bW-\\(.\\)" "Win+\\1"]
      ["\\bRET\\b" "Enter"]
      ["\\bSPC\\b" "Space"]
      ["\\bTAB\\b" "Tab"]
      ["\\bESC\\b" "Escape"]
      ["\\bDEL\\b" "Delete"]
      ]
     t nil t)))

(defun xah-html-keyboard-shortcut-markup (&optional Begin End)
  "Markup keyboard shortcut notation in HTML tag, on selection or current line.
Example:
 C-w ⇒ <kbd>Ctrl</kbd>+<kbd>w</kbd>
 ctrl+w ⇒ <kbd>Ctrl</kbd>+<kbd>w</kbd>

When called in lisp code, Begin End are region begin/end positions.

Version 2020-12-18 2021-07-22 2021-09-15"
  (interactive)
  (let (($p1 (if Begin Begin (if (region-active-p) (region-beginning) (line-beginning-position))))
        ($p2 (if End End (if (region-active-p) (region-end) (line-end-position))))
        ($replaceList
         [
          ["Ctrl" "<kbd>Ctrl</kbd>"]
          ["Control" "<kbd>Ctrl</kbd>"]
          ["AltGr" "<kbd>AltGraph</kbd>"]
          ["AltGraph" "<kbd>AltGraph</kbd>"]
          ["Compose" "<kbd>Compose</kbd>"]
          ["Alt" "<kbd>Alt</kbd>"]
          ["Shift" "<kbd>Shift</kbd>"]
          ["Cmd" "<kbd>⌘ command</kbd>"]
          ["command" "<kbd>⌘ command</kbd>"]
          ["Option" "<kbd>⌥ option</kbd>"]
          ["Opt" "<kbd>⌥ option</kbd>"]
          ["Win" "<kbd>❖ Window</kbd>"]
          ["Menu" "<kbd>▤ Menu</kbd>"]
          ["Meta" "<kbd>Meta</kbd>"]
          ["Super" "<kbd>Super</kbd>"]
          ["Hyper" "<kbd>Hyper</kbd>"]

          ["Return" "<kbd>Return</kbd>"]
          ["Enter" "<kbd>Enter</kbd>"]
          ["Backspace" "<kbd>Backspace ⌫</kbd>"]
          ["bs" "<kbd>Backspace</kbd>"]
          ["Delete" "<kbd>Delete ⌦</kbd>"]
          ["DEL" "<kbd>Delete ⌦</kbd>"]
          ["Space" "<kbd>Space</kbd>"]
          ["Caps Lock" "<kbd>CapsLock</kbd>"]
          ["capslock" "<kbd>CapsLock</kbd>"]
          ["f lock" "<kbd>🅵 Lock</kbd>"]
          ["numlock" "<kbd>NumLock</kbd>"]
          ["Number Lock" "<kbd>NumLock</kbd>"]

          ["Help" "<kbd>Help</kbd>"]
          ["Power" "<kbd>Power</kbd>"]
          ["Tab" "<kbd>Tab</kbd>"]
          ["Esc" "<kbd>Escape</kbd>"]
          ["escape" "<kbd>Escape</kbd>"]
          ["Home" "<kbd>Home</kbd>"]
          ["End" "<kbd>End</kbd>"]
          ["PgUp" "<kbd>PageUp</kbd>"]
          ["PgDn" "<kbd>PageDown</kbd>"]
          ["Insert" "<kbd>Insert</kbd>"]
          ["INS" "<kbd>Insert</kbd>"]
          ["Pause" "<kbd>Pause</kbd>"]
          ["Break" "<kbd>Break</kbd>"]
          ["PrtScn" "<kbd>PrintScreen</kbd>"]
          ["ps" "<kbd>PrintScreen</kbd>"]
          ["sysrq" "<kbd>SysRq</kbd>"]
          ["scrlk" "<kbd>ScrollLock</kbd>"]
          ["scrolllock" "<kbd>ScrollLock</kbd>"]
          ["Fn" "<kbd>Fn</kbd>"]

          ["Copy" "<kbd>Copy</kbd>"]
          ["Cut" "<kbd>Cut</kbd>"]
          ["Paste" "<kbd>Paste</kbd>"]
          ["Undo" "<kbd>Undo</kbd>"]
          ["Redo" "<kbd>Redo</kbd>"]

          ["F10" "<kbd>F10</kbd>"] ["F11" "<kbd>F11</kbd>"] ["F12" "<kbd>F12</kbd>"] ["F13" "<kbd>F13</kbd>"] ["F14" "<kbd>F14</kbd>"] ["F15" "<kbd>F15</kbd>"] ["F16" "<kbd>F16</kbd>"] ["F17" "<kbd>F17</kbd>"] ["F18" "<kbd>F18</kbd>"] ["F19" "<kbd>F19</kbd>"] ["F20" "<kbd>F20</kbd>"] ["F21" "<kbd>F21</kbd>"] ["F22" "<kbd>F22</kbd>"] ["F23" "<kbd>F23</kbd>"] ["F24" "<kbd>F24</kbd>"]

          ["F1" "<kbd>F1</kbd>"] ["F2" "<kbd>F2</kbd>"] ["F3" "<kbd>F3</kbd>"] ["F4" "<kbd>F4</kbd>"] ["F5" "<kbd>F5</kbd>"] ["F6" "<kbd>F6</kbd>"] ["F7" "<kbd>F7</kbd>"] ["F8" "<kbd>F8</kbd>"] ["F9" "<kbd>F9</kbd>"]

          ["kp0" "<kbd>Keypad 0</kbd>"] ["kp1" "<kbd>Keypad 1</kbd>"] ["kp2" "<kbd>Keypad 2</kbd>"] ["kp3" "<kbd>Keypad 3</kbd>"] ["kp4" "<kbd>Keypad 4</kbd>"] ["kp5" "<kbd>Keypad 5</kbd>"] ["kp6" "<kbd>Keypad 6</kbd>"] ["kp7" "<kbd>Keypad 7</kbd>"] ["kp8" "<kbd>Keypad 8</kbd>"] ["kp9" "<kbd>Keypad 9</kbd>"]

          ["kp+" "<kbd>Keypad +</kbd>"]
          ["kp-" "<kbd>Keypad -</kbd>"]
          ["kp*" "<kbd>Keypad *</kbd>"]
          ["kp/" "<kbd>Keypad /</kbd>"]

          ["Left" "<kbd>←</kbd>"]
          ["Right" "<kbd>→</kbd>"]
          ["Up" "<kbd>↑</kbd>"]
          ["Down" "<kbd>↓</kbd>"]

          ["←" "<kbd>←</kbd>"]
          ["→" "<kbd>→</kbd>"]
          ["↑" "<kbd>↑</kbd>"]
          ["↓" "<kbd>↓</kbd>"]

          ["‹key›" "<kbd>‹key›</kbd>"]

          [" " "+"]
          ]))
    (xah-html-emacs-to-windows-kbd-notation $p1 $p2)
    (xah-replace-pairs-region $p1 $p2 $replaceList nil t)))

(defvar xah-html-html-tag-input-history nil "For input history of `xah-html-insert-tag'")
(setq xah-html-tag-input-history (list))

(defvar xah-html-class-input-history nil "For input history of `xah-html-insert-tag'")
(setq xah-html-class-input-history (list))

(defun xah-html-insert-open-close-tags (Tag P1 P2 &optional Class Id )
  "Add HTML open/close tags around region boundary P1 P2.
Tag is tag name. Class is class value string. Id is id value string.
version 2019-06-29"
  (let (($isSelfClose (xah-html--tag-self-closing-p Tag)))
    (save-restriction
      (narrow-to-region P1 P2)
      (goto-char (point-min))
      (progn
        (insert "<" Tag)
        (when Id (insert " " (format "id=\"%s\"" Id)))
        (when Class (insert " " (format "class=\"%s\"" Class))))
      (if $isSelfClose
          (insert " />" )
        (progn
          (insert ">")
          (goto-char (point-max))
          (insert "</" Tag ">" ))))))

(defun xah-html-insert-tag (Tag &optional Class Id)
  "Insert HTML open/close tags.

If there is selection, wrap around selection.
Else, wrap around current {word, line, block}, depending on the tag.
If cursor is around whitespace, then insert open/end tags and place cursor between.

If `universal-argument' is called first, then also prompt for a “class” attribute and “class”. Empty value means don't add the attribute.

Version 2020-11-11 2021-08-31"
  (interactive
   (list
    (ido-completing-read "HTML tag:" xah-html-tag-list "PREDICATE" "REQUIRE-MATCH" nil xah-html-html-tag-input-history "p")
    (when current-prefix-arg (read-string "class:" "x" xah-html-class-input-history))
    (when current-prefix-arg (read-string "id:" "auto"))))
  (let* (($wType (xah-html--get-tag-type Tag))
         ($bds
          (if (region-active-p)
              (cons (region-beginning) (region-end))
            (cond
             ((string-equal $wType "w") (xah-get-bounds-of-thing 'word))
             ((string-equal $wType "l") (cons (line-beginning-position) (line-end-position)))
             ((string-equal $wType "b") (xah-get-bounds-of-thing 'block))
             ((string-equal $wType "c") (cons (1- (point)) (point)))
             ((string-equal $wType "s") (cons (point) (point)))
             (t (cons (point) (point))))))
         ($id (if (string-equal Id "auto")
                  (format "x%05x" (random (1- (expt 16 5))))
                Id
                ))
         $p1 $p2
         )
    (if $bds
        (setq $p1 (car $bds) $p2 (cdr $bds))
      (setq $p1 (point) $p2 (point)))
    (save-restriction
      (narrow-to-region $p1 $p2)
      (progn
        ;; trim whitespace for some tags
        (when
            (and
             (not (region-active-p))
             (or
              (string-equal $wType "l")
              (string-equal $wType "b"))
             (not (or
                   (string-equal Tag "pre")
                   (string-equal Tag "code"))))
          (progn
            (goto-char (point-min))
            (delete-char (- (skip-chars-forward " \t\n")))
            (goto-char (point-max))
            (delete-char (- (skip-chars-backward " \t\n"))))))
      (progn
        ;; add blank at start/end for some tags
        (when (string-equal $wType "b")
          (progn
            (goto-char (point-min))
            (insert "\n")
            (goto-char (point-max))
            (insert "\n"))))
      (xah-html-insert-open-close-tags Tag (point-min) (point-max) Class $id))
    ;; move cursor inside
    (if (= $p1 $p2)
        (if (xah-html--tag-self-closing-p Tag)
            (skip-chars-forward " \t\n" 100)
          (search-backward "</"))
      (skip-chars-forward " \t\n"))
    (skip-chars-forward " \t\n")))

(defun xah-html-insert-pre-tag (&optional LangCode)
  "Insert/wrap class LangCode pre tag on current block or selection.
Version 2020-10-22 2021-08-06 2021-09-12"
  (interactive
   (list
    (ido-completing-read
     "lang code:" (mapcar (lambda (x) (car x)) xah-html-langcode-map)
     "PREDICATE" "REQUIRE-MATCH" nil xah-html-html-tag-input-history "code")))
  (let* (($bds (xah-get-bounds-of-thing-or-region 'block))
         ($p1 (car $bds))
         ($p2 (cdr $bds)))
    (save-restriction
      (narrow-to-region $p1 $p2)
      (goto-char (point-min))
      (insert (format "<pre class=\"%s\">" LangCode))
      (goto-char (point-max))
      (insert "\n</pre>")
      (backward-char 6))))

(defun xah-html-mark-unicode (&optional Pos)
  "Wrap a special <mark> tag around the character before position Pos.
like this:
 <mark class=\"unicodeXL\" title=\"U+3B1: GREEK SMALL LETTER ALPHA\">α</mark>

If the char is any of & < > , then replace them with &amp; &lt; &gt;.
If the unicode name contains < or >, such as <CJK IDEOGRAPH-7684>, they are removed.

Version 2018-01-12 2021-09-17"
  (interactive)
  (let* (($p0 (if Pos Pos (point)))
         ($codepoint (char-before $p0))
         ($charStr (cond
                    ((eq $codepoint ?&) "&amp;")
                    ((eq $codepoint ?<) "&lt;")
                    ((eq $codepoint ?>) "&gt;")
                    (t (char-to-string $codepoint))))
         ;; (require 'descr-text)
         ;; ($name (if (and (boundp 'describe-char-unicodedata-file) describe-char-unicodedata-file) (car (cdr (car (describe-char-unicode-data $codepoint)))) (get-char-code-property $codepoint 'name)))
         ($name (get-char-code-property $codepoint 'name))
         ($name2 (replace-regexp-in-string "<\\|>" "" $name t t)))
    (goto-char $p0)
    (delete-char -1)
    (insert
     (format "<mark class=\"unicodeXL\" title=\"U+%X: %s\">%s</mark>" $codepoint $name2 $charStr))))

(defun xah-html-markup-ruby (&optional Begin End)
  "Wrap HTML ruby annotation tag on current line or selection.
Chars inside paren are wrapped with “rt” tag.
For example
 abc (xyz)
becomes
 <ruby class=\"ruby88\">abc <rt>xyz</rt></ruby>

When called in lisp code, Begin End are region begin/end positions.

URL `http://ergoemacs.org/emacs/elisp_html-ruby-annotation-markup.html'
Version 2017-01-11"
  (interactive)
  (progn
    (if Begin
        (progn
          (setq Begin (line-beginning-position))
          (setq End (line-end-position)))
      (progn
        (if (region-active-p)
            (progn
              (setq Begin (region-beginning))
              (setq End (region-end)))
          (progn
            (setq Begin (line-beginning-position))
            (setq End (line-end-position))))))
    (save-restriction
      (narrow-to-region Begin End)
      (progn
        (goto-char (point-min))
        (while (search-forward "(" nil 1)
          (replace-match "<rt>")))
      (progn
        (goto-char (point-min))
        (while (search-forward ")" nil 1)
          (replace-match "</rt>")))
      (goto-char (point-min))
      (insert "<ruby class=\"ruby88\">")
      (goto-char (point-max))
      (insert "</ruby>"))))

(defun xah-html-clean-whitespace ()
  "Delete redundant whitespace in buffer or selection.
This is heuristic based, does not remove ALL possible redundant whitespace.
Version 2021-08-08 2021-09-05"
  (interactive)
  (xah-replace-regexp-pairs-region
   (point-min) (point-max)
   '( ["[ \t]+\n" "\n"]
      ["\n\n\n+" "\n\n"]
      [" *<p> *\n*" "<p>"]
      [" *\n*</p>" "</p>"]
      )
   t t ))

(defun xah-html-remove-uri-fragment (HrefVal)
  "remove URL HrefVal fragment, anything after first # char, including the #.
See also `xah-html-split-uri-hashmark'
Version 2017-08-15"
  ;; test
  ;; (xah-html-remove-uri-fragment "a#b") ; "a"
  ;; (xah-html-remove-uri-fragment "#3") ; ""
  ;; (xah-html-remove-uri-fragment "4") ; "4"
  ;; (xah-html-remove-uri-fragment "#") ; ""
  ;; (xah-html-remove-uri-fragment "") ; ""
  ;; (if (string-match "#" x )
  ;;     (substring x 0 (match-beginning 0))
  ;;   x )
  (let (($x (string-match-p "#" HrefVal )))
    (if $x (substring HrefVal 0 $x) HrefVal )))

(defun xah-html-split-uri-hashmark (HrefVal)
  "Split a URL HrefVal by # char, return a vector.
 e.g. \"y.html#z\" → [\"y.html\", \"#z\"]

Examples:
 [a#b] → [a] [#b]
 [#] → [] [#]
 [#3] → [] [#3]
 [3#] → [3] [#]
 [4] →  [4] []
 [] →  [] []

See also: `xah-remove-uri-fragment'
Version 2017-08-15"
  ;; test
  ;; (xah-html-split-uri-hashmark "a#b") ; ["a" "#b"]
  ;; (xah-html-split-uri-hashmark "#3") ; ["" "#3"]
  ;; (xah-html-split-uri-hashmark "#") ; ["" "#"]
  ;; (xah-html-split-uri-hashmark "4") ; ["4" ""]
  ;; (xah-html-split-uri-hashmark "") ; ["" ""]
  (let (($x (string-match-p "#" HrefVal )))
    (if $x
        (vector (substring HrefVal 0 $x) (substring HrefVal $x))
      (vector HrefVal "" ))))

(defun xah-html-url-percent-decode-string (string)
  "Returns string URL percent decoded.
Example:

http://example.org/%28D%C3%BCrer%29
↓
http://example.org/(Dürer)

http://example.org/%E6%96%87%E6%9C%AC%E7%BC%96%E8%BE%91%E5%99%A8
↓
http://example.org/文本编辑器

URL `http://ergoemacs.org/emacs/elisp_decode_uri_percent_encoding.html'
Version 2018-10-26 2021-01-14"
  (require 'url-util)
  (decode-coding-string (url-unhex-string string) 'utf-8))

(defun xah-html-decode-percent-encoded-url ()
  "Decode percent encoded URL of current line or selection.

Example:
 %28D%C3%BCrer%29
becomes
 (Dürer)

Example:
 %E6%96%87%E6%9C%AC%E7%BC%96%E8%BE%91%E5%99%A8
becomes
 文本编辑器

URL `http://ergoemacs.org/emacs/emacs_url_percent_decode.html'
Version 2018-10-26 2021-01-14"
  (interactive)
  (let ($p1 $p2 $inputStr $newStr)
    (if (region-active-p)
        (setq $p1 (region-beginning) $p2 (region-end))
      (setq $p1 (line-beginning-position) $p2 (line-end-position)))
    (setq $inputStr (buffer-substring-no-properties $p1 $p2))
    (require 'url-util)
    (setq $newStr (url-unhex-string $inputStr))
    (if (string-equal $newStr $inputStr)
        (progn (message "percent-decode no change"))
      (progn
        (delete-region $p1 $p2)
        (insert (decode-coding-string $newStr 'utf-8))))))

(defun xah-html-compact-def-list (p1 p2)
  "Reformat definition list to 1 line per item, on current block or selection.
Version 2021-05-15 2021-08-11"
  (interactive
   (let ($p1 $p2)
     (let (($bds (xah-get-bounds-of-thing-or-region 'block))) (setq $p1 (car $bds) $p2 (cdr $bds)))
     (list $p1 $p2)))
  (save-restriction
    (narrow-to-region p1 p2)
    (goto-char (point-min))
    (while (search-forward "</dt>\n<dd>" nil t)
      (replace-match "</dt><dd>" t t))
    (goto-char (point-min))
    (while (search-forward "<dd>\n" nil t)
      (replace-match "<dd>" t t))
    (goto-char (point-min))
    (while (search-forward "\n</dd>" nil t)
      (replace-match "</dd>" t t))))

(defun xah-html-add-parag-tags-buffer ()
  "Add p tags around any text block that does not have any tags,
in current buffer.
Experimental. buggy.
Version 2021-06-24"
  (interactive)
  (let (p1 p2 msgList )
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward "\n\n+" nil t)
        (when (not (looking-at "<"))
          (setq p1 (point))
          (when (re-search-forward "[^>]\n\n+" nil t)
            (skip-chars-backward "\n")
            (setq p2 (point))
            (let ($para)
              (setq $para (buffer-substring-no-properties p1 p2 ))
              (message "Added p tag:[%s]" $para)
              (push $para msgList))
            (insert "\n</p>")
            (overlay-put (make-overlay (point) (- (point) 4))  'face 'highlight)
;; '(:foreground "red")
            (goto-char p1)
            (insert "<p>\n")
            (overlay-put (make-overlay (- (point) 4) (- (point) 1))  'face 'highlight)))))
    (message "%s" (mapconcat 'identity (reverse msgList) "\n"))
    ))

(defvar xah-html-open-in-browser-hook nil
 "Hook for `xah-html-open-in-browser'. Hook functions are called before switching to browser.")
(add-hook 'xah-html-open-in-browser-hook 'xah-html-display-hr-as-line)
(add-hook 'xah-html-open-in-browser-hook 'xah-html-clean-whitespace)
;; (add-hook 'xah-html-open-in-browser-hook 'xah-html-add-parag-tags-buffer)
;; (remove-hook 'xah-html-open-in-browser-hook 'xah-html-add-parag-tags-buffer)

(defun xah-html-open-in-browser ()
  "View current buffer in default browser. Save first.
Hook `xah-html-open-in-browser-hook' is run before saving and before opening in browser.
Version 2020-06-26 2021-08-11"
  (interactive)
  (let (($url (buffer-file-name)))
    (run-hooks 'xah-html-open-in-browser-hook )
    (when (buffer-modified-p ) (save-buffer))
    (browse-url $url )))

(defun xah-html-open-url-in-chrome (Url)
  "Open Url in Google Chrome browser.
Url can be file path.

URL `http://ergoemacs.org/emacs/emacs_dired_open_file_in_ext_apps.html'
Version 2019-11-10 2021-08-11"
  (cond
   ((string-equal system-type "darwin")
    (shell-command (format "open -a Google\\ Chrome.app \"%s\"" Url)))
   ((string-equal system-type "windows-nt")
    (let ((process-connection-type nil))
      (start-process "" nil "powershell" "start-process" "chrome.exe" Url )))
   ((string-equal system-type "gnu/linux")
    (shell-command (format "google-chrome-stable \"%s\"" Url)))))

(defun xah-html-open-buffer-in-chrome ()
  "Open current buffer in Google Chrome browser.
If the file is not saved, save it first.
Version 2021-08-11"
  (interactive)
  (when (buffer-modified-p ) (save-buffer))
  (xah-html-open-url-in-chrome (buffer-file-name)))

(defun xah-html-open-in-chrome ()
  "If cursor is on a link, open it in Google Chrome browser. Else, open current buffer.
If there is a selection, use that as path.
Version 2019-11-10 2021-08-11"
  (interactive)
  (let (($path (xah-get-thing-or-region 'url)))
    (if (and $path (string-match "^http" $path ))
        (progn (xah-html-open-url-in-chrome $path ))
      (progn
        (if (xah-html-local-link-p $path)
            (progn
              (if (file-exists-p $path)
                  (progn (xah-html-open-url-in-chrome (expand-file-name $path )))
                (xah-html-open-buffer-in-chrome)))
          (xah-html-open-buffer-in-chrome))))))

(defun xah-html-open-url-in-brave (Url)
  "Open url in Brave browser.
Version 2019-11-10 2021-08-11"
  (cond
   ((string-equal system-type "darwin")
    (shell-command (format "open -a 'Brave Browser.app' \"%s\"" Url)))
   ((string-equal system-type "windows-nt")
    (let ((process-connection-type nil))
      (start-process "" nil "powershell" "start-process" "brave" Url )))
   ((string-equal system-type "gnu/linux")
    (shell-command (format "brave \"%s\"" Url)))))

(defun xah-html-open-buffer-in-brave ()
  "Open the current file in Brave browser.
If the file is not saved, save it first.
Version 2019-11-10 2021-08-11"
  (interactive)
  (when (buffer-modified-p ) (save-buffer))
  (xah-html-open-url-in-brave (buffer-file-name)))

(defun xah-html-open-in-brave ()
  "If cursor is on a link, open it in Brave browser. Else, open current buffer.
If there is a selection, use that as path.
Version 2021-08-11"
  (interactive)
  (let (($path (xah-get-thing-or-region 'url)))
    (if (and $path (string-match "^http" $path ))
        (progn (xah-html-open-url-in-brave $path ))
      (progn
        (if (xah-html-local-link-p $path)
            (progn
              (if (file-exists-p $path)
                  (progn (xah-html-open-url-in-brave (expand-file-name $path )))
                (xah-html-open-buffer-in-brave)))
          (xah-html-open-buffer-in-brave))))))

(defun xah-html-open-url-in-firefox (Url)
  "Open Url in Firefox browser.
Url can be file path.

URL `http://ergoemacs.org/emacs/emacs_dired_open_file_in_ext_apps.html'
Version 2019-11-10 2021-08-11"
  (cond
   ((string-equal system-type "darwin")
    (shell-command (format "open -a 'Firefox.app' \"%s\"" Url)))
   ((string-equal system-type "windows-nt")
    (let ((process-connection-type nil))
      (start-process "" nil "powershell" "start-process" "firefox" Url )))
   ((string-equal system-type "gnu/linux")
    (shell-command (format "firefox \"%s\"" Url)))))

(defun xah-html-open-buffer-in-firefox ()
  "Open current buffer in Firefox browser.
If the file is not saved, save it first.
Version 2021-08-11"
  (interactive)
  (when (buffer-modified-p ) (save-buffer))
  (xah-html-open-url-in-firefox (buffer-file-name)))

(defun xah-html-open-in-firefox ()
  "If cursor is on a link, open it in Firefox browser. Else, open current buffer.
If there is a selection, use that as path.
Version 2021-08-11"
  (interactive)
  (let (($path (xah-get-thing-or-region 'url)))
    (if (and $path (string-match "^http" $path ))
        (progn (xah-html-open-url-in-firefox $path ))
      (progn
        (if (xah-html-local-link-p $path)
            (progn
              (if (file-exists-p $path)
                  (progn (xah-html-open-url-in-firefox (expand-file-name $path )))
                (xah-html-open-buffer-in-firefox)))
          (xah-html-open-buffer-in-firefox))))))

(defun xah-html-open-url-in-safari (Url)
  "Open Url in Safari browser.
Url can be file path.

URL `http://ergoemacs.org/emacs/emacs_dired_open_file_in_ext_apps.html'
Version 2019-11-10 2021-08-11"
  (cond
   ((string-equal system-type "darwin")
    (shell-command (format "open -a Safari.app \"%s\"" Url)))))

(defun xah-html-open-buffer-in-safari ()
  "Open current buffer in Safari browser.
If the file is not saved, save it first.
Version 2021-08-11"
  (interactive)
  (when (buffer-modified-p ) (save-buffer))
  (xah-html-open-url-in-safari (buffer-file-name)))

(defun xah-html-open-in-safari ()
  "If cursor is on a link, open it in Safari browser. Else, open current buffer.
If there is a selection, use that as path.

URL `http://ergoemacs.org/emacs/emacs_dired_open_file_in_ext_apps.html'
Version 2021-08-11"
  (interactive)
  (let (($path (xah-get-thing-or-region 'url)))
    (if (and $path (string-match "^http" $path ))
        (progn (xah-html-open-url-in-safari $path ))
      (progn
        (if (xah-html-local-link-p $path)
            (progn
              (if (file-exists-p $path)
                  (progn (xah-html-open-url-in-safari (expand-file-name $path )))
                (xah-html-open-buffer-in-safari)))
          (xah-html-open-buffer-in-safari))))))

(defun xah-html-encode-percent-encoded-url (&optional Begin End)
  "Percent encode URL in current line or selection.

Example:
    http://example.org/(Dürer)
becomes
    http://example.org/(D%C3%BCrer)

Example:
    http://example.org/文本编辑器
becomes
    http://example.org/%E6%96%87%E6%9C%AC%E7%BC%96%E8%BE%91%E5%99%A8

URL `http://ergoemacs.org/emacs/emacs_url_percent_decode.html'
Version 2018-10-26"
  (interactive)
  (require 'url-util)
  (let* (($p1 (if Begin Begin (if (region-active-p) (region-beginning) (line-beginning-position))))
         ($p2 (if End End (if (region-active-p) (region-end) (line-end-position))))
         ($input (buffer-substring-no-properties $p1 $p2))
         ($newStr (url-encode-url $input)))
    (if (string-equal $newStr $input)
        (message "no change")
      (progn
        (delete-region $p1 $p2)
        (insert $newStr)))))

;; HHH___________________________________________________________________

(defvar xah-html-move-image-file-from-dirs nil "A list of dir paths used by `xah-html-move-image-file' to search for image files to move from. Each should be full path, and end in a slash.")
(setq xah-html-move-image-file-from-dirs
      '(
        "~/Downloads/"
        "~/Videos/Captures/"
        "~/Pictures/Screenshots/"
        "~/Pictures/"
        "~/Desktop/"
        "~/"
        "/tmp/"
        ))

(defvar xah-html-move-image-file-regex-list nil "A list of regex strings used by `xah-html-move-image-file' to search for temp image files.")
(setq
 xah-html-move-image-file-regex-list
 '(
   "^tt"
   "^IMG_.+?\\.\\(png\\|jpg\\)$"
   "^Screen Shot.+?\\.\\(png\\|jpg\\)$"
   "^Screenshot.+?\\.\\(png\\|jpg\\)$"
   "^screenshot.+?\\.\\(png\\|jpg\\)$"
   " PM\\.\\(png\\|jpg\\)$"
   " AM\\.\\(png\\|jpg\\)$"
   ;; amazon pic
   ;; 718XHsTfXcL.__AC_SX300_SY300_QL70_FMwebp_.webp
   ;; 81IVDfmw4KL._AC_SL1500_.jpg
   "[+0-9A-Za-z]\\{11\\}\._+[A-Z]\\{2\\}.+\.\\(jpg\\|webp\\)"
   ;; "[+0-9A-Za-z]\\{11\\}\._+[A-Z]\\{2\\}_[A-Z].+\.\\(jpg\\|webp\\)"
   ))

(defun xah-html-move-image-file (ToDirName)
  "Move image file to another dir.

Search a list of dirs by a list of regex. If a match is found, move it into a new file path, by prompting user to type it.

The from dirs is defined in `xah-html-move-image-file-from-dirs'
The regex list is defined in `xah-html-move-image-file-regex-list'

A random string attached (as id) is added to file name, and any uppercase file extension name is lowercased, e.g. .JPG becomes .jpg. Space in filename is replaced by the low line char “_”.

Automatically call `xah-dired-remove-all-metadata' and `xah-dired-optimize-png' afterwards.

URL `http://ergoemacs.org/emacs/move_image_file.html'
Version 2019 2021-07-05 2021-07-26 2021-10-03"
  (interactive (list (ido-read-directory-name "Move img to dir:")))
  (let* (($dirs xah-html-move-image-file-from-dirs)
         ($regexes xah-html-move-image-file-regex-list)
         $fromPath $ext $newName $toPath)
    (setq $fromPath
          (catch 'found57804
            (dolist (xdir $dirs)
              (when (file-exists-p xdir)
                (let (($dirFiles (directory-files xdir t (mapconcat 'identity $regexes "\\|"))))
                  (when $dirFiles (throw 'found57804 (car $dirFiles))))))))
    (when (not $fromPath) (error "No file name matched regexes %s at dirs %s" $regexes $dirs))
    (setq $ext
          (let (($x (file-name-extension $fromPath)))
            (if $x
                (if (or (string-equal $x "jpg-large")
                        (string-equal $x "jpg_large")
                        (string-equal $x "jpg_medium")
                        (string-equal $x "jpeg")
                        (string-equal $x "jfif"))
                    "jpg"
                  (downcase $x))
              "")))
    (setq $newName
          (let (($x (list (file-name-nondirectory (file-name-sans-extension $fromPath))))
                ($randStr
                 (let* (($charset "bcdfghjkmnpqrstvwxyz23456789BCDFGHJKMNPQRSTVWXYZ")
                        ($len (length $charset))
                        ($randlist nil))
                   (dotimes (_ 4)
                     (push (char-to-string (elt $charset (random $len))) $randlist))
                   (mapconcat 'identity $randlist ""))))
            (push (replace-regexp-in-string "^tt[0-9]*" "" (car $x)) $x)
            (push (replace-regexp-in-string "Screen Shot" "screenshot" (car $x)) $x)
            ;; Screen Shot 2018-07-25 at 2.46.36 AM.png
            (push (read-string "new name:" (car $x) nil (car $x)) $x)
            (push (replace-regexp-in-string ",\\| \\|\\+\\|(\\|)" "_" (car $x)) $x)
            (push (concat (car $x) "_" $randStr) $x)
            (car $x)))
    (setq $toPath (concat (file-name-as-directory ToDirName) $newName "." $ext))
    (message "xah-html-move-image-file: from path is 「%s」\n to path is 「%s」 " $fromPath $toPath)
    (if (file-exists-p $toPath)
        (error "Target path exist: %s" $toPath)
      (progn
        (rename-file $fromPath $toPath)
        (when (string-equal major-mode "dired-mode")
          (revert-buffer))
        (if (string-equal major-mode "xah-html-mode")
            (progn
              (kill-new $toPath)
              (insert "\n\n"  $toPath "\n\n")
              (backward-word)
              (xah-html-any-to-link))
          (progn
            (insert "\n\n" $toPath "\n\n")))
        (when (fboundp 'xah-dired-remove-all-metadata)
          (xah-dired-remove-all-metadata (list $toPath) t))
        (when (and (string-equal $ext "png") (fboundp 'xah-dired-optimize-png))
          (xah-dired-optimize-png (list $toPath)))))))
;; HHH___________________________________________________________________

(defun xah-html-abbrev-enable-function ()
  "Return t if not in string or comment. Else nil.
This is for abbrev table property `:enable-function'.
Version 2016-10-24"
  (let (($syntaxState (syntax-ppss)))
    (not (or (nth 3 $syntaxState) (nth 4 $syntaxState)))))

;; (defun xah-html-abbrev-enable-function ()
;;   "Return t, always.
;; This is for abbrev table property `:enable-function'.
;; Version 2019-05-29"
;;   t)

(defun xah-html-expand-abbrev ()
  "Expand the symbol before cursor,
if cursor is not in string or comment.
Returns the abbrev symbol if there is a expansion, else nil.
Version 2017-01-13"
  (interactive)
  (when (xah-html-abbrev-enable-function) ; abbrev property :enable-function doesn't seem to work, so check here instead
    (let (($p0 (point)) $p1 $p2 $abrStr $abrSymbol)
      (save-excursion
        (forward-symbol -1)
        (setq $p1 (point))
        (goto-char $p0)
        (setq $p2 $p0))
      (setq $abrStr (buffer-substring-no-properties $p1 $p2))
      (setq $abrSymbol (abbrev-symbol $abrStr))
      (if $abrSymbol
          (progn
            (abbrev-insert $abrSymbol $abrStr $p1 $p2)
            (xah-html--abbrev-position-cursor $p1)
            $abrSymbol)
        nil))))

(defun xah-html--abbrev-position-cursor (&optional Pos)
  "Move cursor back to ▮ if exist, else put at end.
Return true if found, else false.
Version 2016-10-24"
  (interactive)
  (let (($foundQ (search-backward "▮" (if Pos Pos (max (point-min) (- (point) 100))) t )))
    (when $foundQ (delete-char 1))
    $foundQ
    ))

(defun xah-html--ahf ()
  "Abbrev hook function, used for `define-abbrev'.
 Our use is to prevent inserting the char that triggered expansion. Experimental.
 the “ahf” stand for abbrev hook function.
Version 2016-10-24"
  t)

(put 'xah-html--ahf 'no-self-insert t)

(setq xah-html-mode-abbrev-table nil)
(define-abbrev-table 'xah-html-mode-abbrev-table
  '(

    ("cdata" "<![CDATA[▮]]>" xah-html--ahf)

    ("p" "\n<p>\n▮\n</p>\n\n" xah-html--ahf)
    ("br" "<br />" xah-html--ahf)
    ("hr" "<hr />\n\n" xah-html--ahf)

    ("cl" "class=\"▮\"" xah-html--ahf)
    ("idt" "id=\"▮\"" xah-html--ahf)
    ("postert" "poster=\"▮\"" xah-html--ahf)

    ("stylet" "<style type=\"text/css\">\np {line-height:130%}\n</style>")
    ("targett" "target=\"_blank\"")
    ("iframe" "<iframe src=\"some.html\" width=\"200\" height=\"300\"></iframe>")

    ("html4s" "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">" xah-html--ahf)
    ("html4t" "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">" xah-html--ahf)
    ("xhtmlt" "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">" xah-html--ahf)
    ("htmlt" "<!doctype html><html><head><meta charset=\"utf-8\" />
<meta name=viewport content=\"width=device-width, initial-scale=1\">

<title>ttt</title>
</head>
<body>

<h1>ttt</h1>

</body>
</html>" xah-html--ahf))

  "abbrev table for `xah-html-mode'"
  )

(abbrev-table-put xah-html-mode-abbrev-table :case-fixed t)
(abbrev-table-put xah-html-mode-abbrev-table :system t)
(abbrev-table-put xah-html-mode-abbrev-table :enable-function 'xah-html-abbrev-enable-function)

;; HHH___________________________________________________________________
;; keybinding

(defvar xah-html-mode-map nil "Keybinding for `xah-html-mode'")
(progn
  (setq xah-html-mode-map (make-sparse-keymap))
  (define-prefix-command 'xah-html-leader-map)
  (define-key xah-html-mode-map (kbd "RET") 'xah-html-open-local-link)
  (define-key xah-html-mode-map (kbd "TAB") 'xah-html-insert-tag)
  (define-key xah-html-mode-map (kbd "C-r") 'xah-html-open-in-browser)

  (define-key xah-html-mode-map (if (boundp 'xahemacs-major-mode-leader-key) xahemacs-major-mode-leader-key (kbd "<f9>")) xah-html-leader-map)

  (define-key xah-html-leader-map (kbd "<right>") 'xah-html-next-opening-tag)
  (define-key xah-html-leader-map (kbd "<left>") 'xah-html-prev-opening-tag)
  (define-key xah-html-leader-map (kbd "<down>") 'xah-html-goto-matching-tag)

  (define-key xah-html-leader-map (kbd "RET") 'xah-html-insert-br-tag)
  (define-key xah-html-leader-map (kbd "'") 'xah-html-encode-percent-encoded-url)
  (define-key xah-html-leader-map (kbd ",") 'xah-html-decode-percent-encoded-url)
  (define-key xah-html-leader-map (kbd ".") 'xah-html-escape-char-to-entity)
  (define-key xah-html-leader-map (kbd ";") 'xah-html-emacs-to-windows-kbd-notation)
  (define-key xah-html-leader-map (kbd "1") 'xah-html-select-element)
  (define-key xah-html-leader-map (kbd "4") 'xah-html-markup-ruby)
  (define-key xah-html-leader-map (kbd "5") 'xah-html-mark-unicode)

  ;; a
  ;; b
  (define-key xah-html-leader-map (kbd "c") 'xah-html-lines-to-list)
  (define-key xah-html-leader-map (kbd "d") 'xah-html-delete-tag-pair)

  ;; e
  (define-key xah-html-leader-map (kbd "f") 'xah-html-lines-to-def-list)
  (define-key xah-html-leader-map (kbd "g") 'xah-html-bracket-to-markup)
  (define-key xah-html-leader-map (kbd "h") 'xah-html-any-to-link)
  (define-key xah-html-leader-map (kbd "i") 'nil)
  (define-key xah-html-leader-map (kbd "i r") 'xah-html-rename-source-file-path)
  (define-key xah-html-leader-map (kbd "i c") 'xah-html-resize-img)
  (define-key xah-html-leader-map (kbd "i f") 'xah-html-image-path-to-figure-tag)
  (define-key xah-html-leader-map (kbd "i h") 'xah-html-image-to-link)
  (define-key xah-html-leader-map (kbd "i i") 'xah-html-image-to-img-tag)
  (define-key xah-html-leader-map (kbd "i j") 'xah-html-convert-to-jpg)
  (define-key xah-html-leader-map (kbd "i m") 'xah-html-move-image-file)
  (define-key xah-html-leader-map (kbd "j") 'xah-html-join-tags)
  (define-key xah-html-leader-map (kbd "k") 'xah-html-keyboard-shortcut-markup)

  ;; l
  (define-key xah-html-leader-map (kbd "m") 'xah-html-insert-pre-tag)
  (define-key xah-html-leader-map (kbd "n") 'nil)

  (define-key xah-html-leader-map (kbd "n n") 'xah-html-open-in-browser)
  (define-key xah-html-leader-map (kbd "n b") 'xah-html-open-in-brave)
  (define-key xah-html-leader-map (kbd "n c") 'xah-html-open-in-chrome)
  (define-key xah-html-leader-map (kbd "n f") 'xah-html-open-in-firefox)
  (define-key xah-html-leader-map (kbd "n s") 'xah-html-open-in-safari)
  (define-key xah-html-leader-map (kbd "n l") 'xah-html-display-hr-as-line)
  ;; o

  (define-key xah-html-leader-map (kbd "p") 'xah-html-blocks-to-paragraph)
  (define-key xah-html-leader-map (kbd "q") 'xah-html-make-link-defunct)
  (define-key xah-html-leader-map (kbd "r") 'xah-html-extract-url)

  ;; s
  (define-key xah-html-leader-map (kbd "t") 'nil)
  (define-key xah-html-leader-map (kbd "t h") 'xah-html-pre-code-to-new-file)
  (define-key xah-html-leader-map (kbd "t t") 'xah-html-toggle-syntax-color-tags)
  (define-key xah-html-leader-map (kbd "t r") 'xah-html-redo-syntax-coloring-buffer)
  (define-key xah-html-leader-map (kbd "t d") 'xah-html-dehtmlize-pre-code-buffer)
  (define-key xah-html-leader-map (kbd "u") 'nil)
  (define-key xah-html-leader-map (kbd "u f") 'xah-html-compact-def-list)
  (define-key xah-html-leader-map (kbd "u u") 'xah-html-update-title-h1)

  (define-key xah-html-leader-map (kbd "u d") 'xah-html-remove-tags)
  (define-key xah-html-leader-map (kbd "u t") 'xah-html-html-to-text)
  (define-key xah-html-leader-map (kbd "u c") 'xah-html-change-current-tag)

  (define-key xah-html-leader-map (kbd "u l") 'xah-html-remove-list-tags)
  (define-key xah-html-leader-map (kbd "u p") 'xah-html-remove-paragraph-tags)
  (define-key xah-html-leader-map (kbd "u s") 'xah-html-disable-script-tag)
  (define-key xah-html-leader-map (kbd "u v") 'xah-html-remove-table-tags)
  (define-key xah-html-leader-map (kbd "v") 'xah-html-lines-to-table)

  ;; w
  (define-key xah-html-leader-map (kbd "x") 'xah-html-escape-char-to-unicode)
  (define-key xah-html-leader-map (kbd "y") 'xah-html-make-citation)

  ;; z
  (define-key xah-html-leader-map (kbd "SPC") 'nil)
  (define-key xah-html-leader-map (kbd "SPC c") 'xah-html-clone-file-in-link)
  (define-key xah-html-leader-map (kbd "SPC d") 'xah-html-insert-date-section)
  (define-key xah-html-leader-map (kbd "SPC e") 'xah-html-url-to-dated-link)
  (define-key xah-html-leader-map (kbd "SPC h") 'xah-html-local-links-to-relative-path)
  (define-key xah-html-leader-map (kbd "SPC t") 'xah-html-local-links-to-fullpath)
  (define-key xah-html-leader-map (kbd "SPC j") 'xah-html-url-to-link)
  (define-key xah-html-leader-map (kbd "SPC r") 'xah-html-named-entity-to-char)
  (define-key xah-html-leader-map (kbd "SPC w") 'xah-html-wolfram-word-to-link)
  (define-key xah-html-leader-map (kbd "SPC m") 'xah-html-wolfram-ref-to-link)
  (define-key xah-html-leader-map (kbd "SPC p") 'xah-html-pdf-path-to-embed)

  ;;

  )

;; HHH___________________________________________________________________

(defvar xah-html-mode-syntax-table nil "Syntax table for `xah-html-mode'.")

(setq xah-html-mode-syntax-table
      (let ((synTable (make-syntax-table)))
        (modify-syntax-entry ?! "." synTable)
        (modify-syntax-entry ?# "." synTable)

        (modify-syntax-entry ?$ "." synTable)

        (modify-syntax-entry ?% "." synTable)
        (modify-syntax-entry ?& "." synTable)
        (modify-syntax-entry ?' "." synTable)
        (modify-syntax-entry ?* "." synTable)
        (modify-syntax-entry ?+ "." synTable)
        (modify-syntax-entry ?, "." synTable)
        (modify-syntax-entry ?- "_" synTable)
        (modify-syntax-entry ?. "." synTable)
        (modify-syntax-entry ?/ "." synTable)
        (modify-syntax-entry ?: "." synTable)
        (modify-syntax-entry ?\; "." synTable)
        (modify-syntax-entry ?< "." synTable)
        (modify-syntax-entry ?= "." synTable)
        (modify-syntax-entry ?> "." synTable)
        (modify-syntax-entry ?? "." synTable)
        (modify-syntax-entry ?@ "." synTable)

        (modify-syntax-entry ?\" "\"" synTable)
        ;; (modify-syntax-entry ?\" "." synTable)

        (modify-syntax-entry ?\\ "\\" synTable)

        (modify-syntax-entry ?^ "." synTable)
        (modify-syntax-entry ?_ "_" synTable)
        (modify-syntax-entry ?` "." synTable)
        (modify-syntax-entry ?| "." synTable)
        (modify-syntax-entry ?~ "." synTable)

        (modify-syntax-entry ?{ "(}" synTable)
        (modify-syntax-entry ?} "){" synTable)

        (modify-syntax-entry ?\( "()" synTable)
        (modify-syntax-entry ?\) ")(" synTable)

        (modify-syntax-entry ?\[ "(]" synTable)
        (modify-syntax-entry ?\] ")[" synTable)

        (modify-syntax-entry ?‹ "(›" synTable)
        (modify-syntax-entry ?› ")‹" synTable)

        (modify-syntax-entry ?« "(»" synTable)
        (modify-syntax-entry ?» ")«" synTable)

        (modify-syntax-entry ?“ "(”" synTable)
        (modify-syntax-entry ?” ")“" synTable)

        (modify-syntax-entry ?‘ "(’" synTable)
        (modify-syntax-entry ?’ ")‘" synTable)

        synTable)
)

;; HHH___________________________________________________________________

(defface xah-html-double-curly-quote-f
  '((t :foreground "black"
       :background "aquamarine"
       ))
  "Face used for curly quoted text."
  :group 'xah-html-mode )

(face-spec-set
 'xah-html-double-curly-quote-f
 '((t :foreground "black"
      :background "aquamarine"
      ))
 'face-defface-spec
 )

(defface xah-html-single-curly-quote-f
  '((t :foreground "red"
       :background "aquamarine"
       ))
  "Face used for curly quoted text."
  :group 'xah-html-mode )

(face-spec-set
 'xah-html-single-curly-quote-f
 '((t :foreground "red"
      :background "aquamarine"
      ))
 'face-defface-spec
 )

(defface xah-html-french-quote-f
  '((t :foreground "DarkMagenta"
       :background "aquamarine"
       ))
  "Face used for « French quoted » text."
  :group 'xah-html-mode )

(face-spec-set
 'xah-html-french-quote-f
 '((t :foreground "DarkMagenta"
      :background "aquamarine"
      ))
 'face-defface-spec
 )

(defface xah-html-span-f
  '(
    (t :background "pink"))
  "face for span tag content."
  :group 'xah-html-mode )

;; temp for debugging
(face-spec-set
 'xah-html-span-f
 '(
   (t :background "pink"))
 'face-defface-spec
 )

(defface xah-html-mark-f
  '(
    (t :background "yellow"))
  "face for mark tag content."
  :group 'xah-html-mode )

;; temp for debugging
(face-spec-set
 'xah-html-mark-f
 '(
   (t :background "yellow"))
 'face-defface-spec
 )

(setq
 xah-html-font-lock-keywords
 (let (
       ;; ($htmlTags (regexp-opt xah-html-tag-list 'symbols))
       ;; ($svgTags (regexp-opt xah-html-svg-tag-list 'symbols))
       ($allTags (regexp-opt (append xah-html-tag-list xah-html-svg-tag-list nil) 'symbols))
       ($selfclose (regexp-opt xah-html-selfclose-tags 'symbols))
       ($attrs (regexp-opt xah-html-attribute-names 'words))
       ($boolAttrs (regexp-opt xah-html-boolean-attribute-names 'words))
       ($cssProps (regexp-opt xah-css-property-names 'words))
       ($cssVals (regexp-opt xah-css-value-kwds 'words))
       ($cssColors (regexp-opt xah-css-color-names 'words))
       ($cssUnits (regexp-opt xah-css-unit-names))
       ($attrStr " +\\(?:[^<>]*?\\)")
       ($textNode "\\([^<]+?\\)"))
   `(("<!--\\|-->" . 'font-lock-comment-delimiter-face)
     ("<!-- \\(.+\\) -->" . (1 'font-lock-comment-face))

     ;; ("&lt;\\|&gt;\\|&amp;" . 'font-lock-warning-face)
     ;; ("&[A-Za-z]+;" . 'font-lock-warning-face)
     ("&" . 'font-lock-warning-face)
     ("<[^/A-Za-z]" . 'font-lock-warning-face)
     ("[^/A-Za-z0-9]>" . 'font-lock-warning-face)

     ;; todo these multiline regex are very slow when there are long lines.
     (,(format "<h\\([1-6]\\)>%s</h\\1>" $textNode) . (2 'bold))
     (,(format "<title>%s</title>" $textNode) . (1 'bold))
     (,(format "<mark%s>%s</mark>" $attrStr $textNode) . (1 'xah-html-mark-f))
     (,(format "<b%s>%s</b>" $attrStr $textNode) . (1 'bold))
     (,(format "“%s”" $textNode) . 'xah-html-double-curly-quote-f)

     (,(format "<%s */?>" $selfclose) . 'shadow)
     (,(format "<%s>" $allTags) . 'shadow)
     (,(format "<%s" $allTags) . 'shadow)
     (,(format "</%s>" $allTags) . 'shadow)

     ("</[A-Za-z0-9]+ *>" . 'font-lock-warning-face)
     ("<[A-Za-z0-9]+ *>" . 'font-lock-warning-face)

     (,(format " \\(%s\\)=" $attrs) . (1 'font-lock-keyword-face))
     (,(format " \\(%s\\) " $boolAttrs) . (1 'font-lock-constant-face))

     (,(format "\\(%s\\):" $cssProps) . (1 'font-lock-keyword-face))
     (,$cssVals . 'font-lock-keyword-face)
     (,$cssColors . 'font-lock-constant-face)
     (,(format "[0-9]+\\(%s\\)" $cssUnits) . (1 'font-lock-type-face))
     ;;
     )))

;; HHH___________________________________________________________________

;;;###autoload
(define-derived-mode xah-html-mode fundamental-mode "∑html"
  "A advanced major mode for HTML.
URL `http://ergoemacs.org/emacs/xah-html-mode.html'
\\{xah-html-mode-map}"
  (setq font-lock-defaults '((xah-html-font-lock-keywords)))
  (set (make-local-variable 'comment-start) "<!-- ")
  (set (make-local-variable 'comment-end) " -->")
  (make-local-variable 'abbrev-expand-function)
  (setq abbrev-expand-function 'xah-html-expand-abbrev)
  (xah-html-display-hr-as-line)
  (abbrev-mode 1)
  :group 'xah-html-mode
  )

(add-to-list 'auto-mode-alist '("\\.html\\'" . xah-html-mode))
(add-to-list 'auto-mode-alist '("\\.htm\\'" . xah-html-mode))

(provide 'xah-html-mode)

;;; xah-html-mode.el ends here
