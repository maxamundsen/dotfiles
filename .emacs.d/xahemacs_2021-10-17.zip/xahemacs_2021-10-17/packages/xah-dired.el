;;; xah-dired.el --- utility to process images, open in OS, zip dir, etc in dired. -*- coding: utf-8; lexical-binding: t; -*-

;; Copyright © 2021 by Xah Lee

;; Author: Xah Lee ( http://xahlee.info/ )
;; Version: 1.7.20210927111603
;; Created: 14 January 2021
;; Package-Requires: ((emacs "25.1"))
;; Keywords: convenience, extensions, files, tools, unix
;; License: GPL v3
;; Homepage: http://ergoemacs.org/emacs/emacs_dired_convert_images.html

;; This file is not part of GNU Emacs.

;;; Commentary:

;; Like it?
;; Buy Xah Emacs Tutorial
;; http://ergoemacs.org/emacs/buy_xah_emacs_tutorial.html
;; Thank you.

;; HHH___________________________________________________________________
;;; Code:

(require 'dired)

(defun xah-process-image (FileList ArgsStr NewNameSuffix NewFileExt)
  "Wrapper to ImageMagick's “convert” shell command.
FileList is a list of image file paths.
ArgsStr is argument string passed to ImageMagick's “convert” command.
NewNameSuffix is the string appended to file. e.g. “_2” may result “_2.jpg”
NewFileExt is the new file's file extension. e.g. “.png”

URL `http://ergoemacs.org/emacs/emacs_dired_convert_images.html'
Version 2021-01-14"
  (let (($cmdName (if (string-equal system-type "windows-nt") "magick.exe convert" "convert")))
    (mapc
     (lambda ($f)
       (let ($newName $cmdStr)
         (setq $newName
               (concat
                (file-name-sans-extension $f)
                NewNameSuffix
                NewFileExt))
         (while (file-exists-p $newName)
           (setq $newName
                 (concat
                  (file-name-sans-extension $newName)
                  NewNameSuffix
                  (file-name-extension $newName t))))
         ;; relative paths used to get around Windows/Cygwin path remapping problem
         (setq $cmdStr
               (format
                "%s %s %s %s"
                $cmdName
                ArgsStr
                (shell-quote-argument (file-relative-name $f))
                (shell-quote-argument (file-relative-name $newName))))
         (shell-command $cmdStr)
         (message "Ran:「%s」" $cmdStr)))
     FileList)))

;; (defun xah-call-imagemagick-async (&rest Args )
;;   "Wrapper to ImageMagick's “convert” shell command.
;; Args is argument strings.
;; URL `http://ergoemacs.org/emacs/emacs_dired_convert_images.html'
;; Version 2021-03-08"
;;   (let ((process-connection-type nil)
;;         ($outBuf (get-buffer-create "*xah process img output*")))
;;     ;; relative paths used to get around Windows/Cygwin path remapping problem
;;     (with-current-buffer $outBuf
;;       (start-process
;;        "" $outBuf
;;        (if (string-equal system-type "windows-nt") "magick.exe" "convert" )
;;        (when (string-equal system-type "windows-nt") "convert")
;;        (apply 'identity Args)))
;;     (message "Start xah-process-image-async. Output at buffer %s" $outBuf)))

;; (xah-call-imagemagick-async
;;  "c:/Users/xah/web/xahlee_info/kbd/i2/havit_keyboard_20210307_311-s1000.jpg"
;;  "c:/Users/xah/web/xahlee_info/kbd/i2/havit_keyboard_20210307_311-s1000.png"
;;  )

(defun xah-dired-scale-image (FileList ScalePercent Quality SharpenQ)
  "Create a scaled version of marked image files in `dired'.
New file names have “-s‹n›” appended before the file name extension, where ‹n› is the scaling factor in percent, such as 60.

If `universal-argument' is ask for png/jpg and sharpen options.

When called in lisp code,
 FileList is a file fullpath list.
 ScalePercent is a integer.
 Quality is a integer, from 1 to 100. bigger is higher quality.
 SharpenQ is true or false.

Require shell command ImageMagick.
URL `http://ergoemacs.org/emacs/emacs_dired_convert_images.html'
Version 2019-12-30 2021-07-31"
  (interactive
   (list (cond
          ((string-equal major-mode "dired-mode") (dired-get-marked-files))
          ((string-equal major-mode "image-mode") (list (buffer-file-name)))
          (t (list (read-from-minibuffer "file name:"))))
         (read-from-minibuffer "Scale %:")
         (if current-prefix-arg (string-to-number (read-string "quality:" "90")) 90)
         (if current-prefix-arg (y-or-n-p "Sharpen") t)))
  (mapc
   (lambda ($f)
     (let ($ext $argStr )
       (setq $ext (file-name-extension $f))
       (setq $argStr (if (string-equal $ext "png") (format "-scale %s%% " ScalePercent ) (format "-scale %s%% -quality %s%% %s " ScalePercent Quality (if SharpenQ "-sharpen 1" "" ))))
       (xah-process-image (list $f) $argStr (format "-s%s" ScalePercent) (concat "." $ext ))))
   FileList))

(defun xah-dired-image-autocrop ()
  "Create auto-cropped version of image in `dired', current or marked files
The created file has “_crop.” in the name, in the same dir. The image format is same as the original.
Require shell command ImageMagick.
Version 2021-01-14"
  (interactive)
  (if (string-equal major-mode "dired-mode")
      (let (($flist (dired-get-marked-files)))
        (mapc
         (lambda ($f)
           (xah-process-image (list $f) "-trim" "_crop" (file-name-extension $f t)))
         $flist )
        (revert-buffer))
    nil
    ))

(defun xah-dired-image-remove-transparency ()
  "Create opaque version of image in `dired', current or marked files.
Works on png images only. The created file has the name, in the same dir.
Require shell command ImageMagick.
URL `http://ergoemacs.org/emacs/emacs_dired_convert_images.html'
Version 2021-01-14"
  (interactive)
  (if (string-equal major-mode "dired-mode")
      (let (($flist (dired-get-marked-files)) $fExt )
        (mapc
         (lambda ($f)
           (setq $fExt (file-name-extension $f))
           (if (not (string-equal $fExt "png"))
               (message "Skipping %s" $f)
             (xah-process-image (list $f) "-flatten" "_opa" (concat "." $fExt ))))
         $flist ))
    (revert-buffer)))

(defun xah-dired-2jpg (FileList)
  "Create a JPG version of images of marked files in `dired'.
If `universal-argument' is called first, ask for jpeg quality. (default is 90)

Require shell command ImageMagick.
URL `http://ergoemacs.org/emacs/emacs_dired_convert_images.html'
Version 2018-11-28 2021-01-18"
  (interactive
   (let (
         ($fileList
          (cond
           ((string-equal major-mode "dired-mode") (dired-get-marked-files))
           ((string-equal major-mode "image-mode") (list (buffer-file-name)))
           (t (list (read-from-minibuffer "file name:"))))))
     (list $fileList)))
  (let ((quality
         (if current-prefix-arg
             (progn (string-to-number (read-string "quality:" "85")))
           (progn 90))))
    (xah-process-image FileList (format "-quality %s%%" quality ) "-2" ".jpg" )
    (revert-buffer)))

(defun xah-dired-2png (FileList)
  "Create a png version of images of marked files in `dired'.
Require shell command ImageMagick.
URL `http://ergoemacs.org/emacs/emacs_dired_convert_images.html'
Version 2016-07-19 2021-01-18"
  (interactive
   (let (
         ($fileList
          (cond
           ((string-equal major-mode "dired-mode") (dired-get-marked-files))
           ((string-equal major-mode "image-mode") (list (buffer-file-name)))
           (t (list (read-from-minibuffer "file name:"))))))
     (list $fileList)))
  (xah-process-image FileList "" "-2" ".png" )
  (revert-buffer))

(defun xah-dired-optimize-png (FileList)
  "optimize the png file of current file or current/marked files in `dired'.
Require shell command optipng.
Output is in buffer *xah optimize png output*
Version 2021-01-14 2021-02-08"
  (interactive
   (list
    (cond
     ((string-equal major-mode "dired-mode") (dired-get-marked-files))
     ((string-equal major-mode "image-mode") (list (buffer-file-name)))
     (t (list (read-from-minibuffer "file name:"))))))
  (let (
        ($outBuf (get-buffer-create "*xah optimize png output*"))
        (async-shell-command-buffer 'new-buffer))
    (with-current-buffer $outBuf
      (mapc (lambda ($f)
              (async-shell-command
               (format "optipng %s"
                       (shell-quote-argument (file-relative-name $f))))
              ;; (start-process "optipng" $outBuf "optipng" (file-relative-name $f))
              ;; (message "wait for optimizing %s" (file-relative-name $f))
              ;; (call-process "optipng" nil $outBuf nil (file-relative-name $f))
              (insert "\nhh========================================\n"))
            FileList))
    ;; (switch-to-buffer-other-window $outBuf)
    ;; (message "Async optimizing png. Output at buffer %s" $outBuf)
    ))

(defun xah-dired-2drawing (FileList GrayscaleQ MaxColorsCount)
  "Create a png version of (drawing type) images of marked files in `dired'.
Basically, make it grayscale, and reduce colors to any of {2, 4, 16, 256}.
Require shell command ImageMagick.
Version 2017-02-02"
  (interactive
   (let (
         ($fileList
          (cond
           ((string-equal major-mode "dired-mode") (dired-get-marked-files))
           ((string-equal major-mode "image-mode") (list (buffer-file-name)))
           (t (list (read-from-minibuffer "file name:"))))))
     (list $fileList
           (yes-or-no-p "Grayscale?")
           (ido-completing-read "Max number of colors:" '( "2" "4" "16" "256" )))))
  (xah-process-image FileList
                     (format "+dither %s -depth %s"
                             (if GrayscaleQ "-type grayscale" "")
                             ;; image magick “-colors” must be at least 8
                             ;; (if (< (string-to-number MaxColorsCount) 3)
                             ;;     8
                             ;;     (expt 2 (string-to-number MaxColorsCount)))
                             (cond
                              ((equal MaxColorsCount "256") 8)
                              ((equal MaxColorsCount "16") 4)
                              ((equal MaxColorsCount "4") 2)
                              ((equal MaxColorsCount "2") 1)
                              (t (error "logic error 0444533051: impossible condition on MaxColorsCount: %s" MaxColorsCount))))  "-2" ".png" ))

(defun xah-dired-show-metadata (FileList)
  "Display metatata of buffer image file or current/marked files in `dired'.
 (typically image files)
Output in buffer *xah metadata output*

This command require the shell command exiftool.
URL `http://xahlee.info/img/metadata_in_image_files.html'

URL `http://ergoemacs.org/emacs/emacs_dired_convert_images.html'
Version 2019-12-04 2021-03-07"
  (interactive
   (list
    (cond
     ((string-equal major-mode "dired-mode") (dired-get-marked-files))
     ((string-equal major-mode "image-mode") (list (buffer-file-name)))
     (t (list (read-from-minibuffer "file name:"))))))
  (let ( ($outBuf (get-buffer-create "*xah metadata output*")))
    (switch-to-buffer $outBuf )
    (mapc (lambda (f)
            (call-process
             "exiftool"
             nil $outBuf nil
             (file-relative-name f))
            (insert "\nhh========================================\n"))
          FileList)))

(defun xah-dired-remove-all-metadata (FileList &optional WaitForIt)
  "Remove all metatata of buffer image file or marked files in `dired'.
 (typically image files)
Output in buffer *xah metadata output*

This command require the shell command exiftool.
URL `http://xahlee.info/img/metadata_in_image_files.html'
URL `http://ergoemacs.org/emacs/emacs_dired_convert_images.html'
Version 2016-07-19 2021-07-26"
  (interactive
   (list
    (cond
     ((string-equal major-mode "dired-mode") (dired-get-marked-files))
     ((string-equal major-mode "image-mode") (list (buffer-file-name)))
     (t (list (read-from-minibuffer "file name:"))))))
  (let ( (process-connection-type nil)
         ($outBuf (get-buffer-create "*xah metadata output*")))
    (with-current-buffer $outBuf
      (mapc (lambda (x)
              (if WaitForIt
                  (call-process "exiftool" nil $outBuf nil "-all=" "-overwrite_original" (file-relative-name x))
                (start-process "" $outBuf "exiftool" "-all="
                               "-overwrite_original"
                               (file-relative-name x)))
              (insert "\nhh========================================\n"))
            FileList))
    (message "Done remove metadata. Output at buffer %s" $outBuf)))

(defun xah-dired-sort ()
  "Sort dired dir listing in different ways.
Prompt for a choice.
URL `http://ergoemacs.org/emacs/dired_sort.html'
Version 2018-12-23"
  (interactive)
  (let ($sortBy $arg)
    (setq $sortBy (ido-completing-read "Sort by:" '( "date" "size" "name" )))
    (cond
     ((equal $sortBy "name") (setq $arg "-Al "))
     ((equal $sortBy "date") (setq $arg "-Al -t"))
     ((equal $sortBy "size") (setq $arg "-Al -S"))
     ((equal $sortBy "dir") (setq $arg "-Al --group-directories-first"))
     (t (error "logic error 09535" )))
    (dired-sort-other $arg )))

(defun xah-dired-open-marked ()
  "Open marked files in `dired'.
URL `http://ergoemacs.org/emacs/emacs_dired_open_marked.html'
Version 2019-10-22"
  (interactive)
  (mapc 'find-file (dired-get-marked-files)))

(defun xah-dired-to-zip ()
  "Zip the current file in `dired'.
If multiple files are marked, only zip the first one.
Require unix zip command line tool.
URL `http://ergoemacs.org/emacs/emacs_dired_zip_dir.html'
Version 2021-01-14 2021-02-08"
  (interactive)
  (let ( (fName (elt (dired-get-marked-files) 0)))
    (async-shell-command
     (format
      "zip -r %s %s"
      (shell-quote-argument (concat (file-relative-name fName) ".zip"))
      (shell-quote-argument (file-relative-name fName))))))

(defvar xah-dired-open-in-gimp-path nil "Microsoft Windows Gimp executable path used by `xah-dired-open-in-gimp'.")
(setq xah-dired-open-in-gimp-path "C:\\Program Files\\GIMP 2\\bin\\gimp-2.10.exe")

(defun xah-dired-open-in-gimp ()
  "Open the current file or `dired' marked files in image editor gimp.
Works in linux and Mac.
On Microsoft Windows, it uses `xah-dired-open-in-gimp-path' to locate gimp program.

URL `http://ergoemacs.org/emacs/emacs_dired_convert_images.html'
Version 2017-11-02 2021-07-29"
  (interactive)
  (let ( (async-shell-command-buffer 'new-buffer) $fileList $doIt)
    (setq $fileList (if (string-equal major-mode "dired-mode") (dired-get-marked-files) (list (buffer-file-name))))
    (setq $doIt (if (<= (length $fileList) 20) t (y-or-n-p "Open more than 20 files? ")))
    (when $doIt
      (cond
       ((string-equal system-type "windows-nt")
        (mapc
         (lambda ($fpath)
           ;; (start-process "" nil xah-dired-open-in-gimp-path  (shell-quote-argument (file-relative-name $fpath)))
           (start-process "" nil xah-dired-open-in-gimp-path  (file-relative-name $fpath))
           )
         $fileList))
       ((string-equal system-type "darwin")
        (mapc
         (lambda ($fpath)
           (async-shell-command
            (format "open -a /Applications/GIMP.app \"%s\"" $fpath))) $fileList))
       ((string-equal system-type "gnu/linux")
        (mapc
         (lambda ($fpath) (let ((process-connection-type nil)) (start-process "" nil "gimp" $fpath))) $fileList))))))

(defvar xah-dired-irfanview-path nil "Microsoft Windows IrfanView executable path used by `xah-dired-open-in-irfanview'.")
(setq xah-dired-irfanview-path "C:\\Program Files\\IrfanView\\i_view64.exe")

(defun xah-dired-open-in-irfanview ()
  "Open the current file or `dired' marked files in Windows's IrfanView.
This uses `xah-dired-irfanview-path' to locate IrfanView program.
Version 2021-02-07 2021-02-08"
  (interactive)
  (when (not (string-equal system-type "windows-nt"))
    (user-error "Error 84752: this command only runs in Windows"))
  (let* (
         (async-shell-command-buffer 'new-buffer)
         (shell-command-dont-erase-buffer t)
         ($fileList (if (string-equal major-mode "dired-mode") (dired-get-marked-files) (list (buffer-file-name))))
         ($doIt (if (<= (length $fileList) 5) t (y-or-n-p "Open more than 5 files? "))))
    (when $doIt
      (mapc
       (lambda ($f)
         (async-shell-command
          (format "%s %s"
                  (shell-quote-argument xah-dired-irfanview-path)
                  (shell-quote-argument (file-relative-name $f)))
          "*xah open in irfanview output*"
          )) $fileList))))

(defvar xah-dired-krita-path nil "Paint app Krita executable path used by `xah-dired-open-in-krita'.")

(setq xah-dired-krita-path "C:/Program Files/Krita (x64)/bin/krita.exe" )

(defun xah-dired-open-in-krita ()
  "Open the current file or `dired' marked files in the paint app Krita.
This uses `xah-dired-krita-path' to locate Krita program.
Version 2021-06-08"
  (interactive)
  (when (not (string-equal system-type "windows-nt"))
    (user-error "Error 84752: this command only runs in Windows"))
  (let* (
         (async-shell-command-buffer 'new-buffer)
         (shell-command-dont-erase-buffer t)
         ($fileList (if (string-equal major-mode "dired-mode") (dired-get-marked-files) (list (buffer-file-name))))
         ($doIt (if (<= (length $fileList) 5) t (y-or-n-p "Open more than 5 files? "))))
    (when $doIt
      (mapc
       (lambda ($f)
         (async-shell-command
          (format "%s %s"
                  (shell-quote-argument xah-dired-krita-path)
                  (shell-quote-argument (file-relative-name $f)))
          "*xah open in krita output*"
          )) $fileList))))

(defvar xah-dired-msPaint-path nil "Microsoft Paint executable path used by `xah-dired-open-in-msPaint'.")

(setq xah-dired-msPaint-path "C:/Windows/System32/mspaint.exe" )

(defun xah-dired-open-in-msPaint ()
  "Open the current file or `dired' marked files in the paint app MsPaint.
This uses `xah-dired-msPaint-path' to locate MsPaint program.
Version 2021-06-08"
  (interactive)
  (when (not (string-equal system-type "windows-nt"))
    (user-error "Error 84752: this command only runs in Windows"))
  (let* (
         (async-shell-command-buffer 'new-buffer)
         (shell-command-dont-erase-buffer t)
         ($fileList (if (string-equal major-mode "dired-mode") (dired-get-marked-files) (list (buffer-file-name))))
         ($doIt (if (<= (length $fileList) 5) t (y-or-n-p "Open more than 5 files? "))))
    (when $doIt
      (mapc
       (lambda ($f)
         (async-shell-command
          (format "%s %s"
                  (shell-quote-argument xah-dired-msPaint-path)
                  (shell-quote-argument (file-relative-name $f)))
          "*xah open in msPaint output*"
          )) $fileList))))

(defun xah-dired-open-in-textedit ()
  "Open the current file or `dired' marked files in Mac's TextEdit.
This command is for macOS only.

URL `http://ergoemacs.org/emacs/emacs_dired_open_file_in_ext_apps.html'
Version 2017-11-21 2021-02-07"
  (interactive)
  (when (not (string-equal system-type "darwin"))
    (user-error "Error 84752: this command only runs in Mac"))
  (let* (
         ($fileList (if (string-equal major-mode "dired-mode") (dired-get-marked-files) (list (buffer-file-name))))
         ($doIt (if (<= (length $fileList) 5) t (y-or-n-p "Open more than 5 files? "))))
    (when $doIt
      (mapc
       (lambda ($fpath)
         (shell-command
          (format "open -a TextEdit.app \"%s\"" $fpath))) $fileList))))

;; HHH___________________________________________________________________

(progn
  (define-prefix-command 'xah-dired-leader-map)
  (define-key dired-mode-map (if (boundp 'xahemacs-major-mode-leader-key) xahemacs-major-mode-leader-key (kbd "<f9>")) xah-dired-leader-map)
  (define-key dired-mode-map (kbd "-") 'xah-dired-rename-space-to-underscore)
  (define-key dired-mode-map (kbd "s") 'xah-dired-sort)
  (define-key xah-dired-leader-map (kbd ".") 'xah-dired-optimize-png)
  (define-key xah-dired-leader-map (kbd "1") 'xah-dired-open-in-msPaint)
  (define-key xah-dired-leader-map (kbd "3") 'xah-dired-open-in-textedit)
  (define-key xah-dired-leader-map (kbd "d") 'xah-dired-image-autocrop)
  (define-key xah-dired-leader-map (kbd "e") 'xah-dired-show-metadata)
  (define-key xah-dired-leader-map (kbd "g") 'xah-dired-2drawing)
  (define-key xah-dired-leader-map (kbd "h") 'xah-dired-scale-image)
  (define-key xah-dired-leader-map (kbd "k") 'xah-dired-open-in-krita)
  (define-key xah-dired-leader-map (kbd "n") 'xah-dired-2png)
  (define-key xah-dired-leader-map (kbd "o") 'xah-dired-open-marked)
  (define-key xah-dired-leader-map (kbd "p") 'xah-dired-open-in-gimp)
  (define-key xah-dired-leader-map (kbd "r") 'xah-dired-image-remove-transparency)
  (define-key xah-dired-leader-map (kbd "t") 'xah-dired-2jpg)
  (define-key xah-dired-leader-map (kbd "u") 'xah-dired-remove-all-metadata)
  (define-key xah-dired-leader-map (kbd "v") 'xah-dired-open-in-irfanview)
  (define-key xah-dired-leader-map (kbd "z") 'xah-dired-to-zip))

(provide 'xah-dired)

;;; xah-dired.el ends here
