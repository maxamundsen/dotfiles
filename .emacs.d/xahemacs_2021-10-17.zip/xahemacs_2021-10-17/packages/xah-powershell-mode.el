;;; xah-powershell-mode.el --- Major mode for editing PowerShell. -*- coding: utf-8; lexical-binding: t; -*-

;; Copyright © 2013-2021 by Xah Lee

;; Author: Xah Lee ( http://xahlee.info/ )
;; Version: 1.1.20211002185331
;; Created: 2021-09-12
;; Package-Requires: ((emacs "25.1"))
;; Keywords: languages, PowerShell
;; License:
;; URL: http://ergoemacs.org/emacs/xah-powershell-mode.html

;; This file is not part of GNU Emacs.

;;; Commentary:
;; Major mode for editing PowerShell code.

;; 2021-09-13 temp. lots PowerShell  source code for testing at https://github.com/jdhitsolutions

;; 2021-09-14 todo
;; need get all builtin param names, better if coupled with the cmdlet
;; color builtin param names. then, color any -word differently
;; add abbrev for all builtin alias, expand to the full name 
;; add abbrev+templates for top 50 or so most used pattern

;; HHH___________________________________________________________________
;;; Code:

(provide 'thingatpt)
(require 'newcomment)
(require 'ido)

;; HHH___________________________________________________________________
(defvar xah-powershell-mode-hook nil "Standard hook for `xah-powershell-mode'")

;; HHH___________________________________________________________________

(defvar xah-pwsh-keywords nil "List of pwsh language words, such as: if else for.")

(setq
 xah-pwsh-keywords
 '(
   "assembly"
   "base"
   "begin"
   "break"
   "catch"
   "class"
   "command"
   "configuration"
   "continue"
   "data"
   "define" ; future
   "do"
   "dynamicparam"
   "else"
   "elseif"
   "end"
   "enum"
   "exit"
   "filter"
   "finally"
   "for"
   "foreach"
   "from" ; future
   "function"
   "hidden"
   "if"
   "in"
   "inlinescript"
   "interface"
   "module"
   "namespace"
   "parallel"
   "param"
   "private"
   "process"
   "public"
   "return"
   "sequence"
   "static"
   "switch"
   "throw"
   "trap"
   "try"
   "type"
   "until"
   "using"
   "var" ; future
   "while"
   "workflow"

   "InlineScript"
   "Parallel"
   "Sequence"
   "Workflow"

   ))

(defvar xah-pwsh-operators nil "List of pwsh operators that are letter sequences, such as -and -or -eq -gt -lt.")
(setq
 xah-pwsh-operators
 '(
   "-eq"
   "-ieq"
   "-ceq"
   "-ne"
   "-ine"
   "-cne"
   "-gt"
   "-ge"
   "-lt"
   "-le"
   "-igt"
   "-ige"
   "-ilt"
   "-ile"
   "-cgt"
   "-cge"
   "-clt"
   "-cle"
   "-contains"
   "-icontains"
   "-ccontains"
   "-notcontains"
   "-inotcontains"
   "-cnotcontains"
   "-in"
   "-notin"
   "-iin"
   "-inotin"
   "-cin"
   "-cnotin"
   "-is"
   "-isnot"
   "-as"
   "-band"
   "-bor"
   "-bxor"
   "-bnot"
   "-shl"
   "-shr"
   "-and"
   "-or"
   "-xor"
   "-not"
   "-split"
   "-join"
   "-f"
   ))

(defvar xah-pwsh-cmdlets nil "List of PowerShell core cmdlets.")
(setq
 xah-pwsh-cmdlets
 '(
"Add-History"
"Clear-History"
"Debug-Job"
"Disable-PSRemoting"
"Enable-PSRemoting"
"Disable-PSSessionConfiguration"
"Enable-PSSessionConfiguration"
"Get-PSSessionCapability"
"Get-PSSessionConfiguration"
"New-PSSessionConfigurationFile"
"Receive-PSSession"
"Register-PSSessionConfiguration"
"Unregister-PSSessionConfiguration"
"Set-PSSessionConfiguration"
"Test-PSSessionConfigurationFile"
"Connect-PSSession"
"Disconnect-PSSession"
"Disable-ExperimentalFeature"
"Enable-ExperimentalFeature"
"Enter-PSHostProcess"
"Enter-PSSession"
"Exit-PSHostProcess"
"Exit-PSSession"
"Export-ModuleMember"
"ForEach-Object"
"Get-Command"
"Get-ExperimentalFeature"
"Get-Help"
"Get-History"
"Get-Job"
"Get-Module"
"Get-PSHostProcessInfo"
"Get-PSSession"
"Import-Module"
"Invoke-Command"
"Invoke-History"
"New-Module"
"New-ModuleManifest"
"New-PSRoleCapabilityFile"
"New-PSSession"
"New-PSSessionOption"
"New-PSTransportOption"
"Out-Default"
"Out-Host"
"Out-Null"
"Receive-Job"
"Register-ArgumentCompleter"
"Remove-Job"
"Remove-Module"
"Remove-PSSession"
"Save-Help"
"Set-PSDebug"
"Set-StrictMode"
"Start-Job"
"Stop-Job"
"Test-ModuleManifest"
"Update-Help"
"Wait-Job"
"Where-Object"
"Get-PSReadLineKeyHandler"
"Get-PSReadLineOption"
"Remove-PSReadLineKeyHandler"
"Set-PSReadLineKeyHandler"
"Set-PSReadLineOption"
"Add-Member"
"Add-Type"
"Clear-Variable"
"Compare-Object"
"ConvertFrom-Csv"
"ConvertFrom-Json"
"ConvertFrom-Markdown"
"ConvertFrom-SddlString"
"ConvertFrom-StringData"
"ConvertTo-Csv"
"ConvertTo-Html"
"ConvertTo-Json"
"ConvertTo-Xml"
"Debug-Runspace"
"Disable-PSBreakpoint"
"Disable-RunspaceDebug"
"Enable-PSBreakpoint"
"Enable-RunspaceDebug"
"Export-Clixml"
"Export-Csv"
"Export-FormatData"
"Export-PSSession"
"Format-Custom"
"Format-Hex"
"Format-List"
"Format-Table"
"Format-Wide"
"Get-Culture"
"Get-Date"
"Get-Error"
"Get-Event"
"Get-EventSubscriber"
"Get-FileHash"
"Get-FormatData"
"Get-Host"
"Get-MarkdownOption"
"Get-Member"
"Get-PSBreakpoint"
"Get-PSCallStack"
"Get-Random"
"Get-Runspace"
"Get-RunspaceDebug"
"Get-TraceSource"
"Get-TypeData"
"Get-UICulture"
"Get-Unique"
"Get-Uptime"
"Get-Variable"
"Get-Verb"
"Group-Object"
"Import-Clixml"
"Import-Csv"
"Import-LocalizedData"
"Import-PowerShellDataFile"
"Import-PSSession"
"Invoke-Expression"
"Invoke-RestMethod"
"Invoke-WebRequest"
"Join-String"
"Measure-Command"
"Measure-Object"
"New-Event"
"New-Guid"
"New-Object"
"New-TemporaryFile"
"New-TimeSpan"
"New-Variable"
"Out-File"
"Out-GridView"
"Out-Printer"
"Out-String"
"Read-Host"
"Register-EngineEvent"
"Register-ObjectEvent"
"Remove-Event"
"Remove-PSBreakpoint"
"Remove-TypeData"
"Remove-Variable"
"Select-Object"
"Select-String"
"Select-Xml"
"Send-MailMessage"
"Set-Date"
"Set-MarkdownOption"
"Set-PSBreakpoint"
"Set-TraceSource"
"Set-Variable"
"Show-Command"
"Show-Markdown"
"Sort-Object"
"Start-Sleep"
"Tee-Object"
"Test-Json"
"Trace-Command"
"Unblock-File"
"Unregister-Event"
"Update-FormatData"
"Update-List"
"Update-TypeData"
"Wait-Debugger"
"Wait-Event"
"Write-Debug"
"Write-Error"
"Write-Host"
"Write-Information"
"Write-Output"
"Write-Progress"
"Write-Verbose"
"Write-Warning"
"Get-ComputerInfo"
"Remove-PSDrive"
"Set-Location"
"Set-Item"
"Get-PSDrive"
"New-Service"
"Rename-Item"
"Get-Item"
"Clear-Item"
"New-Item"
"Resolve-Path"
"Set-TimeZone"
"Get-ItemProperty"
"Rename-Computer"
"Get-ChildItem"
"Test-Connection"
"Get-Content"
"Wait-Process"
"Get-Process"
"Pop-Location"
"Get-HotFix"
"Remove-Service"
"Remove-ItemProperty"
"Set-ItemProperty"
"Set-Content"
"Stop-Service"
"Restart-Computer"
"Get-Clipboard"
"Remove-Item"
"Resume-Service"
"Rename-ItemProperty"
"Copy-ItemProperty"
"Clear-Content"
"Get-Location"
"Set-Service"
"New-PSDrive"
"Clear-RecycleBin"
"Move-Item"
"Get-PSProvider"
"Get-TimeZone"
"Push-Location"
"Clear-ItemProperty"
"New-ItemProperty"
"Convert-Path"
"Debug-Process"
"Invoke-Item"
"Stop-Process"
"Add-Content"
"Split-Path"
"Suspend-Service"
"Copy-Item"
"Join-Path"
"Start-Service"
"Get-ItemPropertyValue"
"Get-Service"
"Test-Path"
"Move-ItemProperty"
"Set-Clipboard"
"Stop-Computer"
"Restart-Service"
"Start-Process"
"Export-BinaryMiLog"
"Get-CimSession"
"Remove-CimInstance"
"Get-CimInstance"
"Invoke-CimMethod"
"New-CimInstance"
"Set-CimInstance"
"New-CimSessionOption"
"New-CimSession"
"Get-CimClass"
"Register-CimIndicationEvent"
"Get-CimAssociatedInstance"
"Remove-CimSession"
"Import-BinaryMiLog"
"New-WinEvent"
"Get-Counter"
"Get-WinEvent"
"Start-Transcript"
"Stop-Transcript"
"Unprotect-CmsMessage"
"Get-Credential"
"Get-CmsMessage"
"New-FileCatalog"
"Test-FileCatalog"
"ConvertTo-SecureString"
"Get-Acl"
"Set-ExecutionPolicy"
"Set-AuthenticodeSignature"
"Get-PfxCertificate"
"Set-Acl"
"Get-ExecutionPolicy"
"ConvertFrom-SecureString"
"Protect-CmsMessage"
"Get-AuthenticodeSignature"
"Remove-WSManInstance"
"Enable-WSManCredSSP"
"Disconnect-WSMan"
"Get-WSManInstance"
"New-WSManSessionOption"
"Set-WSManQuickConfig"
"Get-WSManCredSSP"
"New-WSManInstance"
"Test-WSMan"
"Set-WSManInstance"
"Connect-WSMan"
"Disable-WSManCredSSP"
"Invoke-WSManAction"
"Register-PackageSource"
"Install-Package"
"Uninstall-Package"
"Unregister-PackageSource"
"Get-Package"
"Set-PackageSource"
"Get-PackageSource"
"Find-PackageProvider"
"Import-PackageProvider"
"Get-PackageProvider"
"Save-Package"
"Install-PackageProvider"
"Find-Package"
"Start-ThreadJob"
"Add-Computer"
"Complete-Transaction"
"Start-Transaction"
"Remove-EventLog"
"Remove-WmiObject"
"Get-Transaction"
"Get-ComputerRestorePoint"
"Use-Transaction"
"Register-WmiEvent"
"Show-ControlPanelItem"
"Show-EventLog"
"Set-WmiInstance"
"Checkpoint-Computer"
"Invoke-WmiMethod"
"New-WebServiceProxy"
"Undo-Transaction"
"Clear-EventLog"
"Disable-ComputerRestore"
"Enable-ComputerRestore"
"Remove-Computer"
"Limit-EventLog"
"Test-ComputerSecureChannel"
"Get-EventLog"
"Write-EventLog"
"Reset-ComputerMachinePassword"
"Restore-Computer"
"Get-WmiObject"
"Get-ControlPanelItem"
"New-EventLog"
"Disable-AppBackgroundTaskDiagnos…"
"Enable-AppBackgroundTaskDiagnost…"
"Set-AppBackgroundTaskResourcePol…"
"Mount-AppxVolume"
"Remove-AppxVolume"
"Invoke-CommandInDesktopPackage"
"Get-AppxPackageManifest"
"Set-AppxDefaultVolume"
"Move-AppxPackage"
"Get-AppxVolume"
"Dismount-AppxVolume"
"Remove-AppxPackage"
"Get-AppxPackage"
"Get-AppxDefaultVolume"
"Add-AppxVolume"
"Add-AppxPackage"
"Start-BitsTransfer"
"Suspend-BitsTransfer"
"Complete-BitsTransfer"
"Set-BitsTransfer"
"Remove-BitsTransfer"
"Resume-BitsTransfer"
"Get-BitsTransfer"
"Add-BitsFile"
"Set-DOPercentageMaxForegroundBan…"
"Set-DOPercentageMaxBackgroundBan…"
"Set-DeliveryOptimizationStatus"
"Delete-DeliveryOptimizationCache"
"Get-DeliveryOptimizationLogAnaly…"
"Set-DODownloadMode"
"Get-DeliveryOptimizationLog"
"Remove-WindowsCapability"
"Set-WindowsReservedStorageState"
"Enable-WindowsOptionalFeature"
"Optimize-AppxProvisionedPackages"
"Get-NonRemovableAppsPolicy"
"Remove-WindowsImage"
"Add-WindowsDriver"
"Optimize-WindowsImage"
"New-WindowsImage"
"Remove-WindowsPackage"
"Repair-WindowsImage"
"Set-AppXProvisionedDataFile"
"Get-WindowsEdition"
"Dismount-WindowsImage"
"Set-WindowsEdition"
"Start-OSUninstall"
"New-WindowsCustomImage"
"Remove-WindowsDriver"
"Get-WindowsImageContent"
"Get-WindowsPackage"
"Disable-WindowsOptionalFeature"
"Mount-WindowsImage"
"Expand-WindowsImage"
"Add-WindowsCapability"
"Export-WindowsImage"
"Set-WindowsProductKey"
"Clear-WindowsCorruptMountPoint"
"Split-WindowsImage"
"Get-AppxProvisionedPackage"
"Get-WindowsDriver"
"Expand-WindowsCustomDataImage"
"Add-AppxProvisionedPackage"
"Use-WindowsUnattend"
"Export-WindowsCapabilitySource"
"Save-WindowsImage"
"Get-WindowsImage"
"Get-WindowsReservedStorageState"
"Export-WindowsDriver"
"Remove-AppxProvisionedPackage"
"Add-WindowsPackage"
"Get-WIMBootEntry"
"Update-WIMBootEntry"
"Set-NonRemovableAppsPolicy"
"Add-WindowsImage"
"Get-WindowsCapability"
"Get-WindowsOptionalFeature"
"Resolve-DnsName"
"Get-WinUserLanguageList"
"Get-WinLanguageBarOption"
"Get-WinSystemLocale"
"Get-WinDefaultInputMethodOverride"
"New-WinUserLanguageList"
"Set-WinUILanguageOverride"
"Set-WinCultureFromLanguageListOp…"
"Get-WinHomeLocation"
"Get-WinCultureFromLanguageListOp…"
"Get-WinUILanguageOverride"
"Set-Culture"
"Set-WinHomeLocation"
"Set-WinUserLanguageList"
"Set-WinDefaultInputMethodOverride"
"Set-WinSystemLocale"
"Get-WinAcceptLanguageFromLanguag…"
"Set-WinAcceptLanguageFromLanguag…"
"Set-WinLanguageBarOption"
"Get-KdsRootKey"
"Add-KdsRootKey"
"Get-KdsConfiguration"
"Set-KdsConfiguration"
"Test-KdsRootKey"
"Clear-KdsCache"
"Import-Counter"
"Export-Counter"
"Add-LocalGroupMember"
"Remove-LocalUser"
"Remove-LocalGroup"
"Get-LocalUser"
"Get-LocalGroupMember"
"Remove-LocalGroupMember"
"New-LocalUser"
"Get-LocalGroup"
"Rename-LocalUser"
"Set-LocalGroup"
"New-LocalGroup"
"Enable-LocalUser"
"Set-LocalUser"
"Rename-LocalGroup"
"Disable-LocalUser"
"Undo-DtcDiagnosticTransaction"
"New-DtcDiagnosticTransaction"
"Complete-DtcDiagnosticTransaction"
"Start-DtcDiagnosticResourceManag…"
"Stop-DtcDiagnosticResourceManager"
"Receive-DtcDiagnosticTransaction"
"Send-DtcDiagnosticTransaction"
"Join-DtcDiagnosticResourceManager"
"Get-DAPolicyChange"
"New-NetIPsecAuthProposal"
"New-NetIPsecMainModeCryptoPropos…"
"New-NetIPsecQuickModeCryptoPropo…"
"Get-PmemDisk"
"Get-PmemUnusedRegion"
"New-PmemDisk"
"Get-PmemPhysicalDevice"
"Initialize-PmemPhysicalDevice"
"Remove-PmemDisk"
"Set-CertificateAutoEnrollmentPol…"
"Get-CertificateAutoEnrollmentPol…"
"Test-Certificate"
"Get-CertificateNotificationTask"
"Export-Certificate"
"Switch-Certificate"
"Get-Certificate"
"Remove-CertificateEnrollmentPoli…"
"Export-PfxCertificate"
"Get-PfxData"
"Import-Certificate"
"Remove-CertificateNotificationTa…"
"New-CertificateNotificationTask"
"Add-CertificateEnrollmentPolicyS…"
"Get-CertificateEnrollmentPolicyS…"
"New-SelfSignedCertificate"
"Import-PfxCertificate"
"Set-ProcessMitigation"
"Get-ProcessMitigation"
"ConvertTo-ProcessMitigationPolicy"
"Get-TrustedProvisioningCertifica…"
"Uninstall-TrustedProvisioningCer…"
"Uninstall-ProvisioningPackage"
"Resume-ProvisioningSession"
"Export-Trace"
"Install-TrustedProvisioningCerti…"
"Install-ProvisioningPackage"
"Get-ProvisioningPackage"
"New-ProvisioningRepro"
"Export-ProvisioningPackage"
"Start-DscConfiguration"
"Invoke-DscResource"
"Set-DscLocalConfigurationManager"
"Publish-DscConfiguration"
"Test-DscConfiguration"
"Get-ScheduledJobOption"
"Set-JobTrigger"
"Add-JobTrigger"
"New-JobTrigger"
"Get-JobTrigger"
"Set-ScheduledJob"
"Remove-JobTrigger"
"Enable-JobTrigger"
"New-ScheduledJobOption"
"Get-ScheduledJob"
"Unregister-ScheduledJob"
"Register-ScheduledJob"
"Disable-ScheduledJob"
"Set-ScheduledJobOption"
"Enable-ScheduledJob"
"Disable-JobTrigger"
"New-PSWorkflowExecutionOption"
"Get-SecureBootPolicy"
"Get-SecureBootUEFI"
"Format-SecureBootUEFI"
"Set-SecureBootUEFI"
"Confirm-SecureBootUEFI"
"Export-StartLayout"
"Export-StartLayoutEdgeAssets"
"Import-StartLayout"
"Enable-TlsCipherSuite"
"Export-TlsSessionTicketKey"
"Disable-TlsEccCurve"
"Enable-TlsSessionTicketKey"
"Disable-TlsSessionTicketKey"
"Enable-TlsEccCurve"
"Disable-TlsCipherSuite"
"New-TlsSessionTicketKey"
"Get-TlsCipherSuite"
"Get-TlsEccCurve"
"Invoke-TroubleshootingPack"
"Get-TroubleshootingPack"
"Get-TpmSupportedFeature"
"Initialize-Tpm"
"ConvertTo-TpmOwnerAuth"
"Clear-Tpm"
"Get-Tpm"
"Set-TpmOwnerAuth"
"Unblock-Tpm"
"Enable-TpmAutoProvisioning"
"Import-TpmOwnerAuth"
"Get-TpmEndorsementKeyInfo"
"Disable-TpmAutoProvisioning"
"Set-WheaMemoryPolicy"
"Get-WheaMemoryPolicy"
"Unregister-WindowsDeveloperLicen…"
"Get-WindowsDeveloperLicense"
"Show-WindowsDeveloperLicenseRegi…"
"Enable-WindowsErrorReporting"
"Get-WindowsErrorReporting"
"Disable-WindowsErrorReporting"
"Set-WindowsSearchSetting"
"Get-WindowsSearchSetting"
"Export-Alias"
"Get-Alias"
"Import-Alias"
"New-Alias"
"Remove-Alias"
"Set-Alias"

))

(defvar xah-pwsh-auto-vars nil "List of PowerShell automatic variable names.")
(setq xah-pwsh-auto-vars '( "$$" "$?" "$^" "$_" "$args" "$ConsoleFileName" "$Error" "$ErrorView" "$Event" "$EventArgs" "$EventSubscriber" "$ExecutionContext" "$false" "$foreach" "$HOME" "$Host" "$input" "$IsCoreCLR" "$IsLinux" "$IsMacOS" "$IsWindows" "$LastExitCode" "$Matches" "$MyInvocation" "$NestedPromptLevel" "$null" "$PID" "$PROFILE" "$PSBoundParameters" "$PSCmdlet" "$PSCommandPath" "$PSCulture" "$PSDebugContext" "$PSHOME" "$PSItem" "$PSScriptRoot" "$PSSenderInfo" "$PSUICulture" "$PSVersionTable" "$PWD" "$Sender" "$ShellId" "$StackTrace" "$switch" "$this" "$true" ))

(defvar xah-pwsh-alias-map nil "A alist of PowerShell builtin aliases. Each is a cons pair, alias . full-name.")
(setq
 xah-pwsh-alias-map
 '(("?" . "Where-Object")
   ("%" . "ForEach-Object")
   ("ac" . "Add-Content")
   ("cat" . "Get-Content")
   ("cd" . "Set-Location")
   ("chdir" . "Set-Location")
   ("clc" . "Clear-Content")
   ("clear" . "Clear-Host")
   ("clhy" . "Clear-History")
   ("cli" . "Clear-Item")
   ("clp" . "Clear-ItemProperty")
   ("cls" . "Clear-Host")
   ("clv" . "Clear-Variable")
   ("cnsn" . "Connect-PSSession")
   ("compare" . "Compare-Object")
   ("copy" . "Copy-Item")
   ("cp" . "Copy-Item")
   ("cpi" . "Copy-Item")
   ("cpp" . "Copy-ItemProperty")
   ("cvpa" . "Convert-Path")
   ("dbp" . "Disable-PSBreakpoint")
   ("del" . "Remove-Item")
   ("diff" . "Compare-Object")
   ("dir" . "Get-ChildItem")
   ("dnsn" . "Disconnect-PSSession")
   ("ebp" . "Enable-PSBreakpoint")
   ("echo" . "Write-Output")
   ("epal" . "Export-Alias")
   ("epcsv" . "Export-Csv")
   ("erase" . "Remove-Item")
   ("etsn" . "Enter-PSSession")
   ("exsn" . "Exit-PSSession")
   ("fc" . "Format-Custom")
   ("fhx" . "Format-Hex")
   ("fl" . "Format-List")
   ("foreach" . "ForEach-Object")
   ("ft" . "Format-Table")
   ("fw" . "Format-Wide")
   ("gal" . "Get-Alias")
   ("gbp" . "Get-PSBreakpoint")
   ("gc" . "Get-Content")
   ("gci" . "Get-ChildItem")
   ("gcm" . "Get-Command")
   ("gcs" . "Get-PSCallStack")
   ("gdr" . "Get-PSDrive")
   ("gerr" . "Get-Error")
   ("ghy" . "Get-History")
   ("gi" . "Get-Item")
   ("gjb" . "Get-Job")
   ("gl" . "Get-Location")
   ("gm" . "Get-Member")
   ("gmo" . "Get-Module")
   ("gp" . "Get-ItemProperty")
   ("gps" . "Get-Process")
   ("gpv" . "Get-ItemPropertyValue")
   ("group" . "Group-Object")
   ("gsn" . "Get-PSSession")
   ("gsv" . "Get-Service")
   ("gu" . "Get-Unique")
   ("gv" . "Get-Variable")
   ("h" . "Get-History")
   ("history" . "Get-History")
   ("icm" . "Invoke-Command")
   ("iex" . "Invoke-Expression")
   ("ihy" . "Invoke-History")
   ("ii" . "Invoke-Item")
   ("ipal" . "Import-Alias")
   ("ipcsv" . "Import-Csv")
   ("ipmo" . "Import-Module")
   ("irm" . "Invoke-RestMethod")
   ("iwr" . "Invoke-WebRequest")
   ("kill" . "Stop-Process")
   ("ls" . "Get-ChildItem")
   ("man" . "help")
   ("md" . "mkdir")
   ("measure" . "Measure-Object")
   ("mi" . "Move-Item")
   ("mount" . "New-PSDrive")
   ("move" . "Move-Item")
   ("mp" . "Move-ItemProperty")
   ("mv" . "Move-Item")
   ("nal" . "New-Alias")
   ("ndr" . "New-PSDrive")
   ("ni" . "New-Item")
   ("nmo" . "New-Module")
   ("nsn" . "New-PSSession")
   ("nv" . "New-Variable")
   ("ogv" . "Out-GridView")
   ("oh" . "Out-Host")
   ("popd" . "Pop-Location")
   ("ps" . "Get-Process")
   ("pushd" . "Push-Location")
   ("pwd" . "Get-Location")
   ("r" . "Invoke-History")
   ("rbp" . "Remove-PSBreakpoint")
   ("rcjb" . "Receive-Job")
   ("rcsn" . "Receive-PSSession")
   ("rd" . "Remove-Item")
   ("rdr" . "Remove-PSDrive")
   ("ren" . "Rename-Item")
   ("ri" . "Remove-Item")
   ("rjb" . "Remove-Job")
   ("rm" . "Remove-Item")
   ("rmdir" . "Remove-Item")
   ("rmo" . "Remove-Module")
   ("rni" . "Rename-Item")
   ("rnp" . "Rename-ItemProperty")
   ("rp" . "Remove-ItemProperty")
   ("rsn" . "Remove-PSSession")
   ("rv" . "Remove-Variable")
   ("rvpa" . "Resolve-Path")
   ("sajb" . "Start-Job")
   ("sal" . "Set-Alias")
   ("saps" . "Start-Process")
   ("sasv" . "Start-Service")
   ("sbp" . "Set-PSBreakpoint")
   ("select" . "Select-Object")
   ("set" . "Set-Variable")
   ("shcm" . "Show-Command")
   ("si" . "Set-Item")
   ("sl" . "Set-Location")
   ("sleep" . "Start-Sleep")
   ("sls" . "Select-String")
   ("sort" . "Sort-Object")
   ("sp" . "Set-ItemProperty")
   ("spjb" . "Stop-Job")
   ("spps" . "Stop-Process")
   ("spsv" . "Stop-Service")
   ("start" . "Start-Process")
   ("sv" . "Set-Variable")
   ("tee" . "Tee-Object")
   ("type" . "Get-Content")
   ("where" . "Where-Object")
   ("wjb" . "Wait-Job")
   ("write" . "Write-Output")))

(defvar xah-pwsh-aliases nil "A list of PowerShell builtin aliases.")
(setq
 xah-pwsh-aliases
 (mapcar
  (lambda (x) (car x))
  xah-pwsh-alias-map))

(defvar xah-pwsh-functions nil "List of PowerShell builtin functions.")
(setq xah-pwsh-functions '(

"cd.."
"cd\\"
"Pause"
"help"
"prompt"
"Clear-Host"
"TabExpansion2"
"oss"
"mkdir"
"A:"
"B:"
"C:"
"D:"
"E:"
"F:"
"G:"
"H:"
"I:"
"J:"
"K:"
"L:"
"M:"
"N:"
"O:"
"P:"
"Q:"
"R:"
"S:"
"T:"
"U:"
"V:"
"W:"
"X:"
"Y:"
"Z:"
"PSConsoleHostReadLine"
"Expand-Archive"
"Compress-Archive"
"Update-Script"
"Publish-Script"
"Find-DSCResource"
"Update-ModuleManifest"
"Find-Script"
"Save-Module"
"Update-ScriptFileInfo"
"Get-CredsFromCredentialProvider"
"Get-PSRepository"
"Set-PSRepository"
"Get-InstalledScript"
"Unregister-PSRepository"
"Install-Script"
"Test-ScriptFileInfo"
"Get-InstalledModule"
"Update-Module"
"New-ScriptFileInfo"
"Find-RoleCapability"
"Save-Script"
"Uninstall-Script"
"Find-Module"
"Publish-Module"
"Uninstall-Module"
"Register-PSRepository"
"Find-Command"
"Install-Module"
"Configuration"
"New-DscChecksum"
"Get-DscResource"
"Invoke-DscResource"
"Enable-WSManTrace"
"Disable-WSManTrace"
"Set-LogProperties"
"Enable-PSWSManCombinedTrace"
"Stop-Trace"
"Start-Trace"
"Disable-PSWSManCombinedTrace"
"Disable-PSTrace"
"Get-LogProperties"
"Enable-PSTrace"
"Get-OperationValidation"
"Invoke-OperationValidation"
"Set-TestInconclusive"
"Should"
"AfterEach"
"SafeGetCommand"
"New-Fixture"
"New-PesterOption"
"Set-DynamicParameterVariables"
"Setup"
"BeforeAll"
"AfterAll"
"In"
"Get-TestDriveItem"
"Assert-MockCalled"
"Assert-VerifiableMocks"
"Get-MockDynamicParameters"
"Context"
"It"
"BeforeEach"
"Invoke-Mock"
"Describe"
"Mock"
"InModuleScope"
"Invoke-Pester"
"Unregister-AppBackgroundTask"
"Start-AppBackgroundTask"
"Get-AppBackgroundTask"
"Get-AppxLastError"
"Get-AppxLog"
"Enable-BitLocker"
"Backup-BitLockerKeyProtector"
"Add-BitLockerKeyProtector"
"Clear-BitLockerAutoUnlock"
"Lock-BitLocker"
"Get-BitLockerVolume"
"Disable-BitLockerAutoUnlock"
"Resume-BitLocker"
"Disable-BitLocker"
"Suspend-BitLocker"
"Unlock-BitLocker"
"Remove-BitLockerKeyProtector"
"BackupToAAD-BitLockerKeyProtector"
"Enable-BitLockerAutoUnlock"
"Set-MpPreference"
"Get-MpThreat"
"Get-MpThreatCatalog"
"Get-MpPreference"
"Start-MpWDOScan"
"Get-MpPerformanceReport"
"Get-MpThreatDetection"
"Start-MpScan"
"Update-MpSignature"
"Remove-MpThreat"
"New-MpPerformanceRecording"
"Get-MpComputerStatus"
"Remove-MpPreference"
"Add-MpPreference"
"Get-DODownloadMode"
"Get-DeliveryOptimizationPerfSnap"
"Get-DOConfig"
"Disable-DeliveryOptimizationVerb…"
"Get-DOPercentageMaxBackgroundBan…"
"Enable-DeliveryOptimizationVerbo…"
"Get-DOPercentageMaxForegroundBan…"
"Get-DeliveryOptimizationStatus"
"Get-DeliveryOptimizationPerfSnap…"
"Set-DAEntryPointTableItem"
"Remove-DAEntryPointTableItem"
"Rename-DAEntryPointTableItem"
"Reset-DAClientExperienceConfigur…"
"Disable-DAManualEntryPointSelect…"
"Set-DAClientExperienceConfigurat…"
"Reset-DAEntryPointTableItem"
"Get-DAEntryPointTableItem"
"New-DAEntryPointTableItem"
"Enable-DAManualEntryPointSelecti…"
"Get-DAClientExperienceConfigurat…"
"Get-DnsClientGlobalSetting"
"Get-DnsClientNrptPolicy"
"Set-DnsClientNrptGlobal"
"Clear-DnsClientCache"
"Get-DnsClientCache"
"Register-DnsClient"
"Set-DnsClientGlobalSetting"
"Get-DnsClientNrptRule"
"Set-DnsClientNrptRule"
"Get-DnsClient"
"Set-DnsClientServerAddress"
"Remove-DnsClientNrptRule"
"Get-DnsClientNrptGlobal"
"Get-DnsClientServerAddress"
"Set-DnsClient"
"Add-DnsClientNrptRule"
"Set-EtwTraceProvider"
"New-EtwTraceSession"
"Flush-EtwTraceSession"
"New-AutologgerConfig"
"Send-EtwTraceSession"
"Remove-EtwTraceProvider"
"Add-EtwTraceProvider"
"Start-AutologgerConfig"
"Update-AutologgerConfig"
"Get-EtwTraceProvider"
"Update-EtwTraceSession"
"Remove-AutologgerConfig"
"Start-EtwTraceSession"
"Save-EtwTraceSession"
"Get-AutologgerConfig"
"Stop-EtwTraceSession"
"Get-EtwTraceSession"
"Set-IscsiChapSecret"
"Remove-IscsiTargetPortal"
"Update-IscsiTargetPortal"
"Get-IscsiSession"
"Unregister-IscsiSession"
"Get-IscsiConnection"
"Register-IscsiSession"
"Disconnect-IscsiTarget"
"Update-IscsiTarget"
"Connect-IscsiTarget"
"Get-IscsiTarget"
"New-IscsiTargetPortal"
"Get-IscsiTargetPortal"
"Import-IseSnippet"
"Get-IseSnippet"
"New-IseSnippet"
"Export-ODataEndpointProxy"
"Debug-MMAppPrelaunch"
"Get-MMAgent"
"Disable-MMAgent"
"Set-MMAgent"
"Enable-MMAgent"
"Install-Dtc"
"Set-DtcClusterDefault"
"Get-DtcAdvancedHostSetting"
"Get-DtcLog"
"Add-DtcClusterTMMapping"
"Get-DtcTransaction"
"Get-DtcAdvancedSetting"
"Get-Dtc"
"Write-DtcTransactionsTraceSession"
"Start-Dtc"
"Set-DtcTransactionsTraceSession"
"Stop-Dtc"
"Set-DtcDefault"
"Uninstall-Dtc"
"Set-DtcClusterTMMapping"
"Get-DtcTransactionsTraceSetting"
"Remove-DtcClusterTMMapping"
"Get-DtcNetworkSetting"
"Set-DtcAdvancedSetting"
"Get-DtcClusterDefault"
"Reset-DtcLog"
"Get-DtcTransactionsTraceSession"
"Get-DtcDefault"
"Set-DtcAdvancedHostSetting"
"Stop-DtcTransactionsTraceSession"
"Set-DtcTransaction"
"Set-DtcTransactionsTraceSetting"
"Start-DtcTransactionsTraceSession"
"Set-DtcNetworkSetting"
"Set-DtcLog"
"Test-Dtc"
"Get-DtcTransactionsStatistics"
"Get-DtcClusterTMMapping"
"Enable-NetAdapterRdma"
"Set-NetAdapterPacketDirect"
"Set-NetAdapterSriov"
"Set-NetAdapterRsc"
"Get-NetAdapterRss"
"Enable-NetAdapterBinding"
"Get-NetAdapterPacketDirect"
"Set-NetAdapterRss"
"Disable-NetAdapterEncapsulatedPa…"
"Enable-NetAdapterRsc"
"Enable-NetAdapterChecksumOffload"
"New-NetAdapterAdvancedProperty"
"Disable-NetAdapterRsc"
"Get-NetAdapterQos"
"Set-NetAdapterChecksumOffload"
"Enable-NetAdapter"
"Get-NetAdapterLso"
"Get-NetAdapterBinding"
"Restart-NetAdapter"
"Get-NetAdapter"
"Disable-NetAdapterUso"
"Get-NetAdapterSriovVf"
"Disable-NetAdapterRdma"
"Get-NetAdapterRdma"
"Set-NetAdapterEncapsulatedPacket…"
"Enable-NetAdapterPacketDirect"
"Remove-NetAdapterAdvancedProperty"
"Disable-NetAdapterChecksumOffload"
"Disable-NetAdapterSriov"
"Get-NetAdapterEncapsulatedPacket…"
"Get-NetAdapterAdvancedProperty"
"Disable-NetAdapterLso"
"Enable-NetAdapterUso"
"Get-NetAdapterRsc"
"Get-NetAdapterHardwareInfo"
"Enable-NetAdapterVmq"
"Get-NetAdapterChecksumOffload"
"Set-NetAdapterVmq"
"Disable-NetAdapter"
"Set-NetAdapterIPsecOffload"
"Reset-NetAdapterAdvancedProperty"
"Disable-NetAdapterIPsecOffload"
"Set-NetAdapterRdma"
"Enable-NetAdapterPowerManagement"
"Get-NetAdapterVmq"
"Get-NetAdapterVPort"
"Enable-NetAdapterEncapsulatedPac…"
"Enable-NetAdapterSriov"
"Disable-NetAdapterQos"
"Enable-NetAdapterIPsecOffload"
"Disable-NetAdapterBinding"
"Get-NetAdapterSriov"
"Disable-NetAdapterRss"
"Rename-NetAdapter"
"Disable-NetAdapterVmq"
"Set-NetAdapter"
"Set-NetAdapterUso"
"Set-NetAdapterBinding"
"Enable-NetAdapterQos"
"Get-NetAdapterVMQQueue"
"Enable-NetAdapterLso"
"Set-NetAdapterAdvancedProperty"
"Get-NetAdapterIPsecOffload"
"Disable-NetAdapterPowerManagement"
"Disable-NetAdapterPacketDirect"
"Enable-NetAdapterRss"
"Set-NetAdapterQos"
"Get-NetAdapterStatistics"
"Set-NetAdapterPowerManagement"
"Set-NetAdapterLso"
"Get-NetAdapterUso"
"Get-NetAdapterPowerManagement"
"Get-NetConnectionProfile"
"Set-NetConnectionProfile"
"Remove-NetEventWFPCaptureProvider"
"Get-NetEventVmSwitchProvider"
"New-NetEventSession"
"Get-NetEventVFPProvider"
"Get-NetEventVmNetworkAdapter"
"Remove-NetEventVmSwitch"
"Remove-NetEventPacketCaptureProv…"
"Add-NetEventProvider"
"Remove-NetEventVmSwitchProvider"
"Get-NetEventSession"
"Set-NetEventProvider"
"Get-NetEventNetworkAdapter"
"Remove-NetEventVFPProvider"
"Remove-NetEventProvider"
"Get-NetEventWFPCaptureProvider"
"Get-NetEventPacketCaptureProvider"
"Add-NetEventVFPProvider"
"Set-NetEventPacketCaptureProvider"
"Remove-NetEventSession"
"Add-NetEventVmSwitch"
"Stop-NetEventSession"
"Get-NetEventVmSwitch"
"Set-NetEventSession"
"Add-NetEventVmSwitchProvider"
"Set-NetEventWFPCaptureProvider"
"Add-NetEventWFPCaptureProvider"
"Set-NetEventVmSwitchProvider"
"Get-NetEventProvider"
"Start-NetEventSession"
"Remove-NetEventVmNetworkAdapter"
"Add-NetEventPacketCaptureProvider"
"Add-NetEventNetworkAdapter"
"Remove-NetEventNetworkAdapter"
"Add-NetEventVmNetworkAdapter"
"Set-NetEventVFPProvider"
"New-NetLbfoTeam"
"Set-NetLbfoTeam"
"Add-NetLbfoTeamMember"
"Get-NetLbfoTeamNic"
"Set-NetLbfoTeamNic"
"Remove-NetLbfoTeam"
"Remove-NetLbfoTeamNic"
"Rename-NetLbfoTeam"
"Get-NetLbfoTeamMember"
"Set-NetLbfoTeamMember"
"Add-NetLbfoTeamNic"
"Get-NetLbfoTeam"
"Remove-NetLbfoTeamMember"
"Add-NetNatExternalAddress"
"Get-NetNatStaticMapping"
"Add-NetNatStaticMapping"
"Set-NetNatGlobal"
"Get-NetNatGlobal"
"Get-NetNatExternalAddress"
"Get-NetNatSession"
"Get-NetNat"
"Set-NetNat"
"Remove-NetNat"
"Remove-NetNatStaticMapping"
"Remove-NetNatExternalAddress"
"New-NetNat"
"Set-NetQosPolicy"
"Remove-NetQosPolicy"
"Get-NetQosPolicy"
"New-NetQosPolicy"
"Set-NetIPsecQuickModeCryptoSet"
"Disable-NetIPsecMainModeRule"
"New-NetFirewallRule"
"Remove-NetIPsecMainModeRule"
"Get-NetFirewallApplicationFilter"
"Remove-NetIPsecDospSetting"
"Copy-NetIPsecRule"
"Get-NetIPsecRule"
"Get-NetFirewallSecurityFilter"
"Get-NetIPsecMainModeSA"
"Copy-NetIPsecQuickModeCryptoSet"
"Remove-NetIPsecMainModeSA"
"Get-NetFirewallRule"
"Remove-NetIPsecPhase1AuthSet"
"Set-NetFirewallInterfaceTypeFilt…"
"Get-NetFirewallSetting"
"Copy-NetIPsecPhase1AuthSet"
"Update-NetIPsecRule"
"Rename-NetIPsecRule"
"Rename-NetFirewallRule"
"Enable-NetIPsecMainModeRule"
"New-NetIPsecQuickModeCryptoSet"
"Rename-NetIPsecQuickModeCryptoSet"
"Remove-NetIPsecQuickModeSA"
"Copy-NetIPsecMainModeCryptoSet"
"Get-NetIPsecQuickModeCryptoSet"
"Get-NetIPsecMainModeCryptoSet"
"Enable-NetFirewallRule"
"Set-NetFirewallAddressFilter"
"Set-NetIPsecPhase2AuthSet"
"Set-NetFirewallRule"
"Rename-NetIPsecMainModeRule"
"Set-NetFirewallProfile"
"Show-NetIPsecRule"
"Set-NetIPsecMainModeCryptoSet"
"Save-NetGPO"
"Remove-NetIPsecPhase2AuthSet"
"New-NetIPsecRule"
"Remove-NetIPsecQuickModeCryptoSet"
"Get-NetIPsecDospSetting"
"Get-NetFirewallServiceFilter"
"Remove-NetIPsecMainModeCryptoSet"
"Set-NetFirewallPortFilter"
"Copy-NetFirewallRule"
"Set-NetIPsecPhase1AuthSet"
"Set-NetIPsecDospSetting"
"New-NetIPsecPhase1AuthSet"
"Set-NetIPsecRule"
"Set-NetFirewallServiceFilter"
"New-NetIPsecMainModeCryptoSet"
"Set-NetFirewallApplicationFilter"
"New-NetIPsecDospSetting"
"Get-NetIPsecPhase1AuthSet"
"Get-NetIPsecPhase2AuthSet"
"Get-NetFirewallInterfaceTypeFilt…"
"Set-NetFirewallInterfaceFilter"
"Get-NetFirewallProfile"
"Rename-NetIPsecMainModeCryptoSet"
"Disable-NetFirewallRule"
"Set-NetFirewallSecurityFilter"
"Find-NetIPsecRule"
"Get-NetFirewallPortFilter"
"Remove-NetIPsecRule"
"Show-NetFirewallRule"
"Get-NetFirewallAddressFilter"
"Set-NetIPsecMainModeRule"
"Rename-NetIPsecPhase1AuthSet"
"Copy-NetIPsecMainModeRule"
"Get-NetFirewallInterfaceFilter"
"Enable-NetIPsecRule"
"Copy-NetIPsecPhase2AuthSet"
"Remove-NetFirewallRule"
"Set-NetFirewallSetting"
"Get-NetIPsecQuickModeSA"
"New-NetIPsecPhase2AuthSet"
"Disable-NetIPsecRule"
"New-NetIPsecMainModeRule"
"Get-NetIPsecMainModeRule"
"Rename-NetIPsecPhase2AuthSet"
"Open-NetGPO"
"Sync-NetIPsecRule"
"New-NetSwitchTeam"
"Rename-NetSwitchTeam"
"Get-NetSwitchTeam"
"Add-NetSwitchTeamMember"
"Remove-NetSwitchTeamMember"
"Remove-NetSwitchTeam"
"Get-NetSwitchTeamMember"
"New-NetIPAddress"
"Get-NetCompartment"
"Get-NetTCPConnection"
"Get-NetOffloadGlobalSetting"
"Get-NetTransportFilter"
"Get-NetUDPEndpoint"
"Set-NetOffloadGlobalSetting"
"Test-NetConnection"
"New-NetRoute"
"Get-NetIPAddress"
"New-NetTransportFilter"
"Get-NetPrefixPolicy"
"Set-NetTCPSetting"
"Set-NetIPv4Protocol"
"Set-NetUDPSetting"
"Remove-NetTransportFilter"
"Get-NetIPv4Protocol"
"Find-NetRoute"
"Get-NetRoute"
"Set-NetRoute"
"Set-NetIPv6Protocol"
"Remove-NetRoute"
"New-NetNeighbor"
"Set-NetIPInterface"
"Get-NetIPInterface"
"Get-NetTCPSetting"
"Get-NetUDPSetting"
"Set-NetNeighbor"
"Set-NetIPAddress"
"Remove-NetIPAddress"
"Get-NetNeighbor"
"Remove-NetNeighbor"
"Get-NetIPConfiguration"
"Get-NetIPv6Protocol"
"Set-NCSIPolicyConfiguration"
"Get-DAConnectionStatus"
"Reset-NCSIPolicyConfiguration"
"Get-NCSIPolicyConfiguration"
"Remove-NetworkSwitchEthernetPort…"
"Get-NetworkSwitchVlan"
"Disable-NetworkSwitchVlan"
"New-NetworkSwitchVlan"
"Enable-NetworkSwitchFeature"
"Set-NetworkSwitchPortProperty"
"Enable-NetworkSwitchEthernetPort"
"Get-NetworkSwitchGlobalData"
"Set-NetworkSwitchVlanProperty"
"Set-NetworkSwitchEthernetPortIPA…"
"Get-NetworkSwitchEthernetPort"
"Set-NetworkSwitchPortMode"
"Get-NetworkSwitchFeature"
"Remove-NetworkSwitchVlan"
"Save-NetworkSwitchConfiguration"
"Disable-NetworkSwitchEthernetPort"
"Restore-NetworkSwitchConfigurati…"
"Enable-NetworkSwitchVlan"
"Disable-NetworkSwitchFeature"
"New-NetIPHttpsConfiguration"
"Get-NetIsatapConfiguration"
"Get-NetIPHttpsConfiguration"
"Disable-NetNatTransitionConfigur…"
"Reset-NetIsatapConfiguration"
"Remove-NetNatTransitionConfigura…"
"Rename-NetIPHttpsConfiguration"
"Set-NetTeredoConfiguration"
"Enable-NetNatTransitionConfigura…"
"Get-NetNatTransitionMonitoring"
"Reset-NetIPHttpsConfiguration"
"Enable-NetIPHttpsProfile"
"Set-NetIPHttpsConfiguration"
"Get-NetNatTransitionConfiguration"
"Remove-NetIPHttpsCertBinding"
"Add-NetIPHttpsCertBinding"
"Get-Net6to4Configuration"
"Get-NetTeredoState"
"Reset-NetTeredoConfiguration"
"Get-NetDnsTransitionMonitoring"
"Disable-NetIPHttpsProfile"
"Set-NetDnsTransitionConfiguration"
"Disable-NetDnsTransitionConfigur…"
"New-NetNatTransitionConfiguration"
"Reset-NetDnsTransitionConfigurat…"
"Get-NetTeredoConfiguration"
"Enable-NetDnsTransitionConfigura…"
"Get-NetIPHttpsState"
"Set-NetIsatapConfiguration"
"Remove-NetIPHttpsConfiguration"
"Set-NetNatTransitionConfiguration"
"Reset-Net6to4Configuration"
"Set-Net6to4Configuration"
"Get-NetDnsTransitionConfiguration"
"Set-PcsvDeviceNetworkConfigurati…"
"Clear-PcsvDeviceLog"
"Restart-PcsvDevice"
"Set-PcsvDeviceBootConfiguration"
"Stop-PcsvDevice"
"Get-PcsvDevice"
"Get-PcsvDeviceLog"
"Set-PcsvDeviceUserPassword"
"Start-PcsvDevice"
"Get-PnpDeviceProperty"
"Enable-PnpDevice"
"Get-PnpDevice"
"Disable-PnpDevice"
"Get-PrinterPort"
"Add-PrinterPort"
"Remove-Printer"
"Get-PrintConfiguration"
"Get-PrintJob"
"Remove-PrinterDriver"
"Write-PrinterNfcTag"
"Set-PrintConfiguration"
"Set-Printer"
"Add-Printer"
"Read-PrinterNfcTag"
"Set-PrinterProperty"
"Get-PrinterDriver"
"Resume-PrintJob"
"Suspend-PrintJob"
"Rename-Printer"
"Get-Printer"
"Remove-PrinterPort"
"Restart-PrintJob"
"Add-PrinterDriver"
"Remove-PrintJob"
"Get-PrinterProperty"
"Restore-DscConfiguration"
"Get-DscConfiguration"
"Disable-DscDebug"
"Get-DscConfigurationStatus"
"Stop-DscConfiguration"
"Remove-DscConfigurationDocument"
"Get-DscLocalConfigurationManager"
"Enable-DscDebug"
"Update-DscConfiguration"
"New-PSWorkflowSession"
"Invoke-AsWorkflow"
"New-ScheduledTask"
"Set-ClusteredScheduledTask"
"Get-ClusteredScheduledTask"
"New-ScheduledTaskPrincipal"
"New-ScheduledTaskAction"
"Get-ScheduledTaskInfo"
"Stop-ScheduledTask"
"New-ScheduledTaskTrigger"
"Disable-ScheduledTask"
"Unregister-ClusteredScheduledTask"
"Register-ClusteredScheduledTask"
"New-ScheduledTaskSettingsSet"
"Get-ScheduledTask"
"Export-ScheduledTask"
"Unregister-ScheduledTask"
"Set-ScheduledTask"
"Start-ScheduledTask"
"Register-ScheduledTask"
"Enable-ScheduledTask"
"Unblock-SmbShareAccess"
"New-SmbGlobalMapping"
"New-SmbServerCertificateMapping"
"Remove-SmbMultichannelConstraint"
"Set-SmbPathAcl"
"Set-SmbServerConfiguration"
"Update-SmbMultichannelConnection"
"Get-SmbServerConfiguration"
"Remove-SmbShare"
"Get-SmbShare"
"Get-SmbClientConfiguration"
"Close-SmbOpenFile"
"Set-SmbShare"
"New-SmbShare"
"Set-SmbBandwidthLimit"
"Get-SmbGlobalMapping"
"Remove-SMBComponent"
"Remove-SmbMapping"
"Get-SmbMapping"
"Get-SmbOpenFile"
"Get-SmbServerCertificateMapping"
"Get-SmbMultichannelConnection"
"Block-SmbShareAccess"
"Remove-SmbServerCertificateMappi…"
"Get-SmbBandWidthLimit"
"Get-SmbSession"
"Get-SmbMultichannelConstraint"
"Get-SmbServerNetworkInterface"
"Get-SmbConnection"
"Disable-SmbDelegation"
"Revoke-SmbShareAccess"
"Set-SmbClientConfiguration"
"New-SmbMapping"
"Remove-SmbBandwidthLimit"
"Get-SmbClientNetworkInterface"
"Remove-SmbGlobalMapping"
"Close-SmbSession"
"Get-SmbShareAccess"
"Grant-SmbShareAccess"
"New-SmbMultichannelConstraint"
"Get-SmbDelegation"
"Enable-SmbDelegation"
"Move-SmbWitnessClient"
"Get-SmbWitnessClient"
"Get-StartApps"
"Resize-Partition"
"Remove-PhysicalDisk"
"Update-HostStorageCache"
"Get-StorageHealthAction"
"Get-PhysicalDisk"
"New-MaskingSet"
"Get-StorageHealthSetting"
"Set-StorageFileServer"
"Get-DiskImage"
"Get-FileShare"
"Get-StorageEnclosureVendorData"
"Get-Partition"
"Optimize-StoragePool"
"Resize-VirtualDisk"
"Add-VirtualDiskToMaskingSet"
"Get-FileStorageTier"
"Format-Volume"
"Disable-StorageEnclosurePower"
"Get-StoragePool"
"Remove-StorageTier"
"Set-StorageProvider"
"Remove-StorageFaultDomain"
"Repair-FileIntegrity"
"Enable-StorageEnclosureIdentific…"
"Enable-StorageHighAvailability"
"Remove-VirtualDiskFromMaskingSet"
"Disable-StorageHighAvailability"
"Get-StorageProvider"
"Get-StorageFirmwareInformation"
"Get-DiskStorageNodeView"
"Block-FileShareAccess"
"Remove-VirtualDisk"
"Get-VirtualDiskSupportedSize"
"New-StorageTier"
"Get-InitiatorId"
"Get-OffloadDataTransferSetting"
"Get-FileShareAccessControlEntry"
"Get-TargetPort"
"Remove-StorageHealthIntent"
"Add-PhysicalDisk"
"Write-VolumeCache"
"New-VirtualDisk"
"Start-StorageDiagnosticLog"
"Update-StorageFirmware"
"Remove-FileShare"
"Reset-StorageReliabilityCounter"
"Debug-FileShare"
"Set-VirtualDisk"
"Remove-InitiatorIdFromMaskingSet"
"Get-ResiliencySetting"
"Get-DedupProperties"
"Clear-StorageDiagnosticInfo"
"Set-Volume"
"Get-MaskingSet"
"Get-StorageSetting"
"Remove-TargetPortFromMaskingSet"
"Get-PhysicalDiskStorageNodeView"
"Get-StorageChassis"
"Get-PhysicalExtent"
"Disable-StorageEnclosureIdentifi…"
"Set-FileShare"
"Get-StorageEnclosure"
"Debug-StorageSubSystem"
"Remove-InitiatorId"
"Get-VirtualDisk"
"Get-SupportedClusterSizes"
"Disable-PhysicalDiskIdentificati…"
"Get-PartitionSupportedSize"
"Add-InitiatorIdToMaskingSet"
"Get-VolumeCorruptionCount"
"Enable-PhysicalDiskIdentification"
"Update-StorageProviderCache"
"Get-InitiatorPort"
"Reset-PhysicalDisk"
"Dismount-DiskImage"
"Set-InitiatorPort"
"Remove-StorageFileServer"
"New-StorageFileServer"
"Update-Disk"
"Get-VolumeScrubPolicy"
"New-VirtualDiskClone"
"Remove-StoragePool"
"Enable-StorageMaintenanceMode"
"New-Volume"
"Get-StorageRack"
"Set-Partition"
"Get-PhysicalExtentAssociation"
"Set-VolumeScrubPolicy"
"Get-StorageAdvancedProperty"
"New-StorageSubsystemVirtualDisk"
"Optimize-Volume"
"Set-StorageSetting"
"Set-PhysicalDisk"
"Show-VirtualDisk"
"Disconnect-VirtualDisk"
"Get-SupportedFileSystems"
"Get-TargetPortal"
"Unregister-StorageSubsystem"
"Get-Volume"
"Get-StorageNode"
"New-Partition"
"Get-StorageSite"
"New-VirtualDiskSnapshot"
"Grant-FileShareAccess"
"Enable-StorageEnclosurePower"
"Set-ResiliencySetting"
"Remove-PartitionAccessPath"
"Stop-StorageDiagnosticLog"
"New-FileShare"
"Update-StoragePool"
"Get-StorageExtendedStatus"
"Add-PartitionAccessPath"
"Disable-StorageMaintenanceMode"
"Resize-StorageTier"
"Mount-DiskImage"
"Register-StorageSubsystem"
"Set-StorageHealthSetting"
"Debug-Volume"
"Unblock-FileShareAccess"
"Get-StorageHistory"
"Connect-VirtualDisk"
"Revoke-FileShareAccess"
"Hide-VirtualDisk"
"Set-StorageTier"
"Rename-MaskingSet"
"Get-StorageSubSystem"
"Get-StorageEnclosureStorageNodeV…"
"Remove-Partition"
"Get-StorageTier"
"Remove-MaskingSet"
"Add-TargetPortToMaskingSet"
"Set-StoragePool"
"Add-StorageFaultDomain"
"Get-FileIntegrity"
"Get-StorageFaultDomain"
"Set-Disk"
"Get-StorageDiagnosticInfo"
"Set-FileIntegrity"
"Show-StorageHistory"
"Get-StorageReliabilityCounter"
"Repair-VirtualDisk"
"Repair-Volume"
"Clear-FileStorageTier"
"Stop-StorageJob"
"Clear-Disk"
"Remove-StorageHealthSetting"
"New-StoragePool"
"Set-FileStorageTier"
"Get-StorageJob"
"Get-StorageScaleUnit"
"Get-StorageFileServer"
"Get-StorageTierSupportedSize"
"Set-StorageSubSystem"
"Initialize-Disk"
"Get-StorageHealthReport"
"Get-Disk"
"New-StorageBusBinding"
"Disable-StorageBusCache"
"Remove-StorageBusBinding"
"Get-StorageBusDisk"
"Enable-StorageBusDisk"
"Clear-StorageBusDisk"
"Set-StorageBusProfile"
"Get-StorageBusBinding"
"New-StorageBusCacheStore"
"Suspend-StorageBusDisk"
"Disable-StorageBusDisk"
"Resume-StorageBusDisk"
"Enable-StorageBusCache"
"New-EapConfiguration"
"Add-VpnConnectionRoute"
"New-VpnServerAddress"
"Add-VpnConnectionTriggerApplicat…"
"Get-VpnConnectionTrigger"
"Add-VpnConnectionTriggerTrustedN…"
"Set-VpnConnectionTriggerDnsConfi…"
"Set-VpnConnectionIPsecConfigurat…"
"Get-VpnConnection"
"Add-VpnConnection"
"Set-VpnConnectionProxy"
"Remove-VpnConnectionTriggerAppli…"
"Remove-VpnConnectionTriggerDnsCo…"
"Remove-VpnConnectionTriggerTrust…"
"Remove-VpnConnection"
"Remove-VpnConnectionRoute"
"Add-VpnConnectionTriggerDnsConfi…"
"Set-VpnConnectionTriggerTrustedN…"
"Set-VpnConnection"
"Set-OdbcDriver"
"Enable-OdbcPerfCounter"
"Get-OdbcDriver"
"Get-OdbcPerfCounter"
"Disable-OdbcPerfCounter"
"Get-OdbcDsn"
"Enable-WdacBidTrace"
"Get-WdacBidTrace"
"Disable-WdacBidTrace"
"Remove-OdbcDsn"
"Add-OdbcDsn"
"Set-OdbcDsn"
"Get-WindowsUpdateLog"
"Get-WUIsPendingReboot"
"Get-WULastScanSuccessDate"
"Install-WUUpdates"
"Get-WUAVersion"
"Start-WUScan"
"Get-WULastInstallationDate"
))

;; 2021-09-12 todo. need DOS cmd.exe keywords, such as cmd, explorer
;; 2021-09-12 todo. need color for -params

(defvar xah-pwsh-all-words nil "List all pwsh words.")
(setq xah-pwsh-all-words
      (append
       xah-pwsh-keywords
       xah-pwsh-operators
       xah-pwsh-cmdlets
       xah-pwsh-auto-vars
       xah-pwsh-aliases
       xah-pwsh-functions
))

;; HHH___________________________________________________________________
;; syntax coloring related

;; (defface xah-pwsh-dollar-name
;;   '((t :foreground "purple" :weight bold ))
;;   "face for user variables."
;;   :group 'xah-powershell-mode )

;; (face-spec-set
;;  'xah-pwsh-dollar-name
;;  '((t :foreground "black" :weight bold )))

;; (face-spec-set
;;  'font-lock-variable-name-face
;;  '((t :foreground "black" :weight bold )))

;; (defface xah-pwsh-func-param
;;   '((t :foreground "red" :weight bold))
;;   "face for function parameters."
;;   :group 'xah-powershell-mode )

;; (face-spec-set
;;  'xah-pwsh-func-param
;;  '((t :foreground "red" :weight bold)))

(defvar xah-pwsh-font-lock-keywords nil "gist for `font-lock-defaults'")
(setq
 xah-pwsh-font-lock-keywords
 (progn
   `((,(regexp-opt xah-pwsh-cmdlets 'symbols) . 'font-lock-function-name-face)
     (,(regexp-opt xah-pwsh-functions 'symbols) . 'font-lock-function-name-face)
     (,(regexp-opt xah-pwsh-keywords 'symbols) . 'font-lock-keyword-face)
     (,(regexp-opt xah-pwsh-operators 'symbols) . 'font-lock-keyword-face)
     (,(regexp-opt xah-pwsh-auto-vars 'symbols) . 'font-lock-variable-name-face)
     (,(regexp-opt xah-pwsh-aliases 'symbols) . 'font-lock-function-name-face)

     ;; font-lock-variable-name-face
     ("\\_<$[$_0-9A-Za-z]+" . 'bold))))

;; HHH___________________________________________________________________
;; keybinding

(defvar xah-powershell-mode-map nil "Keybinding for `xah-powershell-mode'")
(progn
  (setq xah-powershell-mode-map (make-sparse-keymap))
  (define-prefix-command 'xah-pwsh-leader-map)
  (define-key xah-powershell-mode-map (kbd "TAB") 'xah-pwsh-complete-or-indent)
  (define-key xah-powershell-mode-map (if (boundp 'xahemacs-major-mode-leader-key) xahemacs-major-mode-leader-key (kbd "<f9>")) xah-pwsh-leader-map)
  (define-key xah-pwsh-leader-map (kbd "f") 'xah-pwsh-format-code)
  (define-key xah-pwsh-leader-map (kbd "TAB") 'xah-pwsh-complete-symbol))

;; HHH___________________________________________________________________
;; syntax table

(defvar xah-powershell-mode-syntax-table nil "Syntax table for `xah-powershell-mode'.")

(setq xah-powershell-mode-syntax-table
      (let ((synTable (make-syntax-table)))

        (modify-syntax-entry ?\_ "_" synTable)
        (modify-syntax-entry ?\$ "_" synTable)
        (modify-syntax-entry ?\- "_" synTable)


        (modify-syntax-entry ?\\ "." synTable)
        (modify-syntax-entry ?\" "\"" synTable)
        (modify-syntax-entry ?\' "\"" synTable)

        (modify-syntax-entry ?\("()" synTable)
        (modify-syntax-entry ?\) ")(" synTable)
        (modify-syntax-entry ?\[ "(]" synTable)
        (modify-syntax-entry ?\] ")[" synTable)
        (modify-syntax-entry ?\{ "(}" synTable)
        (modify-syntax-entry ?\} "){" synTable)

        (modify-syntax-entry ?\. "." synTable)
        (modify-syntax-entry ?\! "." synTable)

        (modify-syntax-entry ?\% "." synTable)
        (modify-syntax-entry ?\& "." synTable)
        (modify-syntax-entry ?\+ "." synTable)
        (modify-syntax-entry ?\, "." synTable)
        (modify-syntax-entry ?\: "." synTable)
        (modify-syntax-entry ?\; "." synTable)
        (modify-syntax-entry ?\< "." synTable)
        (modify-syntax-entry ?\= "." synTable)
        (modify-syntax-entry ?\> "." synTable)
        (modify-syntax-entry ?\? "." synTable)
        (modify-syntax-entry ?\@ "." synTable)
        (modify-syntax-entry ?^ "." synTable) ; can't use blackslash, because it became control
        (modify-syntax-entry ?\| "." synTable)
        (modify-syntax-entry ?\~ "." synTable)

        (modify-syntax-entry ?\` "\\" synTable)

        (modify-syntax-entry ?# "<" synTable)
        (modify-syntax-entry ?\n ">" synTable)

        synTable))

;; HHH___________________________________________________________________
;; indent

(defun xah-pwsh-goto-outer-bracket (&optional pos)
  "Move cursor to the beginning of left {}, starting at pos.
Version 2016-10-18"
  (interactive)
  (let* (
        ($p0 (if (number-or-marker-p pos) pos (point)))
        ($p1 $p0))
    (goto-char $p1)
    (search-backward "{" nil t)
    ;; (while
    ;;     ;; (setq $p1 (point))
    ;;     )
    ))

(defun xah-pwsh-indent-root-block ()
  "Prettify format current root sexp group.
Root sexp group is the outmost sexp unit."
  (interactive)
  (save-excursion
    (let ($p1 )
      (xah-pwsh-goto-outer-bracket)
      (setq $p1 (point))
      (forward-sexp 1)
      (progn
        (goto-char $p1)
        (message "todo xah-pwsh-indent-root-block called " )
        ;; (indent-region $p1 $p2)
        ))))

(defun xah-pwsh-complete-symbol ()
  "Perform keyword completion on current word.
This uses `ido-mode' user interface for completion.
Version 2021-09-13"
  (interactive)
  (let* (($bds (bounds-of-thing-at-point 'symbol))
         ($p1 (car $bds))
         ($p2 (cdr $bds))
         ($thisSym
          (if (or (null $p1) (null $p2) (equal $p1 $p2))
              ""
            (buffer-substring-no-properties $p1 $p2)))
         $resultSym)
    (when (not $thisSym) (setq $thisSym ""))
    (setq $resultSym
          (ido-completing-read "" xah-pwsh-all-words nil nil $thisSym))
    (delete-region $p1 $p2)
    (insert $resultSym)))

(defun xah-pwsh-complete-or-indent ()
  "Do keyword completion or indent/prettify-format.

If char before point is letters and char after point is whitespace or punctuation, then do completion, except when in string or comment. In these cases, do `xah-pwsh-indent-root-block'.
Version 2016-10-24"
  (interactive)
  (let (($syntaxState (syntax-ppss)))
    (if (or (nth 3 $syntaxState) (nth 4 $syntaxState))
        (progn
          (message "todo. tried indent")
          ;; (xah-pwsh-indent-root-block)
          )
      (if
          (and (looking-back "[[:graph:]]" 1)
               ;; (or (eobp) (looking-at "[\n[:blank:][:punct:]]"))
               )
          (progn
            (xah-pwsh-complete-symbol))
        (progn
          (message "tried indent"))))))

;; HHH___________________________________________________________________

(defun xah-pwsh-format-code ()
  "Format PowerShell code in current buffer.
Version 2021-09-13"
  (interactive)
  (message "currently do nothing"))

;; HHH___________________________________________________________________
;; abbrev

(defun xah-pwsh-abbrev-enable-function ()
  "Return t if not in string or comment. Else nil.
This is for abbrev table property `:enable-function'.
Version 2017-02-05"
  (let (($syntaxState (syntax-ppss)))
    (if (or (nth 3 $syntaxState) (nth 4 $syntaxState))
        nil
      t)))

;; (if (or (looking-at " \\|\n\\|\t") (eobp)) t nil)

(defun xah-pwsh-expand-abbrev ()
  "Expand the symbol before cursor, if cursor is not in string or comment.
Returns the abbrev symbol if there's a expansion, else nil.
Version 2018-07-17 2021-07-31"
  (interactive)
  (when
    (xah-pwsh-abbrev-enable-function)
    (let (
          ($p0 (point))
          $p1 $p2
          $inputStr
          $abrSymbol
          )
      (progn
        ;; first try expansion with char sequence including the dot
        (skip-chars-backward "[._0-9A-Za-z]+" (min (- (point) 100) (point-min)))
        (setq $p1 (point) $p2 $p0)
        (goto-char $p0))
      (setq $inputStr (buffer-substring-no-properties $p1 $p2))
      ;; (message "first $inputStr is %s" $inputStr)
      (setq $abrSymbol (abbrev-symbol $inputStr))
      (if $abrSymbol
          (progn
            (abbrev-insert $abrSymbol $inputStr $p1 $p2 )
            (xah-pwsh--abbrev-position-cursor $p1)
            $abrSymbol)
        (progn
          ;; if expansion with char sequence including the dot come out no result, try without the dot
          (progn
            (goto-char $p0)
            (skip-chars-backward "[_0-9A-Za-z]+" (min (- (point) 100) (point-min)))
            (setq $p1 (point) $p2 $p0)
            (goto-char $p0))
          (setq $inputStr (buffer-substring-no-properties $p1 $p2))
          ;; (message "2nd $inputStr is %s" $inputStr)
          (setq $abrSymbol (abbrev-symbol $inputStr))
          (if $abrSymbol
              (progn
                (abbrev-insert $abrSymbol $inputStr $p1 $p2 )
                (xah-pwsh--abbrev-position-cursor $p1)
                $abrSymbol)
            nil
            ))))))

(defun xah-pwsh--abbrev-position-cursor (&optional Pos)
  "Move cursor back to ▮ if exist, else put at end.
Return true if found, else false.
Version 2018-06-10"
  (interactive)
  (let (($foundQ (search-backward "▮" (if Pos Pos (max (point-min) (- (point) 100))) t )))
    (when $foundQ (delete-char 1))
    $foundQ
    ))

(defun xah-pwsh--abbrev-hook-f ()
  "Abbrev hook function, used for `define-abbrev'.
 Our use is to prevent inserting the char that triggered expansion. Experimental.
 the “ahf” stand for abbrev hook function.
Version 2016-10-24"
  t)

(put 'xah-pwsh--abbrev-hook-f 'no-self-insert t)

(setq xah-powershell-mode-abbrev-table nil)

(define-abbrev-table 'xah-powershell-mode-abbrev-table
  '(
    ;;
    ("wh" "Write-Host")
    ("fo" "ForEach-Object")
    ("of" "Out-File")
    ("feo" "ForEach-Object")
    ("gci" "Get-ChildItem")
    ("gc" "Get-Content")

    ("%" "% { $_▮ }")

    ("if" "if (3▮ -gt 2) { 3 }")
    ("else" "else { 4▮ }")
    ("ife" "( $x -gt 5 ? 3 : 4)")
    ("foreach" "foreach ($e in $arr) { $e }")

    ("ForEach-Object" "ForEach-Object { $_▮ }")
    ("ForEach" "ForEach(property_name_str, new_val)")
    ("while" "$i=5; while($i -lt 10) { $a[$i] }")
    ("for" "for ($i=0; $i -le $arr.length; $i=$i+1) { $arr[$i] }"))

  "abbrev table for `xah-powershell-mode'"
  )

;; (abbrev-table-put xah-powershell-mode-abbrev-table :regexp "\\([._0-9A-Za-z]+\\)") ; override by xah-pwsh-expand-abbrev
(abbrev-table-put xah-powershell-mode-abbrev-table :case-fixed t)
(abbrev-table-put xah-powershell-mode-abbrev-table :system t)
;; (abbrev-table-put xah-powershell-mode-abbrev-table :enable-function 'xah-pwsh-abbrev-enable-function) ; override by xah-pwsh-expand-abbrev

;; HHH___________________________________________________________________

;;;###autoload
(define-derived-mode xah-powershell-mode fundamental-mode "∑pwsh"
  "A major mode for PowerShell.

URL `http://ergoemacs.org/emacs/xah-powershell-mode.html'

\\{xah-powershell-mode-map}"

  (setq font-lock-defaults '((xah-pwsh-font-lock-keywords) nil t))

  (setq-local comment-start "# ")
  (setq-local comment-end "")
  (setq-local comment-column 2)

  (make-local-variable 'abbrev-expand-function)
  (setq abbrev-expand-function 'xah-pwsh-expand-abbrev)
  (abbrev-mode 1)

  ;; (setq-local tab-always-indent t)
  ;; (add-hook 'completion-at-point-functions 'xah-pwsh-complete-symbol nil 'local)

  (setq indent-tabs-mode nil) ; don't mix space and tab

  :group 'xah-powershell-mode

  )

(add-to-list 'auto-mode-alist '("\\.ps1\\'" . xah-powershell-mode))

(provide 'xah-powershell-mode)

;;; xah-powershell-mode.el ends here
